import json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
AB = json.load(open("/home/claude/zstp/out/ablation.json")); RS = AB["meta"]["r_star"]
BLUE, ORANGE, INK, INK2, GRID = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e6e5e1"
g = lambda k: AB[k]
rows = [("A1 recognition-blind (G1)", g("A1 recognition-blind (G1)")),
        ("A2 identity-blind (G2)", g("A2 identity-blind (G2)")),
        ("   A2 after repair", g("A2 identity-blind (G2)")["repaired"]),
        ("A3 per-slot re-solve (G3)", g("A3 per-slot re-solve, no inter-slot rules (G3)")),
        ("   A3 after repair", g("A3 per-slot re-solve, no inter-slot rules (G3)")["repaired"]),
        ("A3h no inter-slot rules (G3, suppl.)", g("A3h full horizon, no inter-slot rules (G3, supplementary)")),
        ("   A3h after repair", g("A3h full horizon, no inter-slot rules (G3, supplementary)")["repaired"]),
        ("A4 expected payoff, uniform (G4)", g("A4 expected payoff, uniform prior (G4)"))] + \
       [(f"A4 prior 0.7 on θ_{t} (G4)", g(f"A4-{t} expected payoff, prior 0.7 on theta_{t} (G4)")) for t in ("low", "med", "high", "burst")]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": GRID, "xtick.color": INK2, "ytick.color": INK,
                     "axes.titlesize": 9, "axes.titleweight": "bold", "axes.titlecolor": INK, "axes.labelcolor": INK2})
fig, (a, b) = plt.subplots(1, 2, figsize=(7.16, 4.1), sharey=True, gridspec_kw={"width_ratios": [1, 1.15]})
ys = list(range(len(rows)))[::-1]
for y, (name, r) in zip(ys, rows):
    pct = 100 * r["worst_case"] / RS
    feas = r["feasible"]
    a.plot([0, pct], [y, y], color=ORANGE, lw=1.6, alpha=0.35, solid_capstyle="round")
    a.plot(pct, y, "o", ms=7, mfc=ORANGE if feas else "white", mec=ORANGE, mew=1.8, zorder=3)
    p = r["paired_vs_maxmin"]; lo, hi = p["ci95"]
    b.plot([lo, hi], [y, y], color=ORANGE, lw=2, solid_capstyle="round")
    b.plot(p["diff"], y, "o", ms=7, mfc=ORANGE if feas else "white", mec=ORANGE, mew=1.8, zorder=3)
a.axvline(100, color=BLUE, lw=2); a.text(99, len(rows) - 0.35, "ZSTP r* ", color=INK, fontsize=7.5, va="bottom", ha="right")
b.axvline(0, color=INK2, lw=1, ls="--"); b.text(0, len(rows) - 0.35, "no difference ", color=INK2, fontsize=7.5, va="bottom", ha="right")
a.set_yticks(ys, [n for n, _ in rows])
a.set_xlim(0, 120); a.set_xlabel("Worst case on the full model (% of r*)")
b.set_xlabel("ZSTP minus ablation, emulated worst-profile mean\n(95% interval; > 0 means ZSTP better)")
a.set_title("(a) Model worst case", loc="left"); b.set_title("(b) L2 emulation, paired", loc="left")
for ax in (a, b):
    for s in ("top", "right", "left"): ax.spines[s].set_visible(False)
    ax.grid(axis="x", color=GRID, lw=0.8); ax.set_axisbelow(True); ax.tick_params(length=0)
    ax.set_ylim(-0.7, len(rows) + 0.3)
fig.legend(handles=[Line2D([], [], marker="o", ls="", mfc=ORANGE, mec=ORANGE, ms=7, label="Follows every hard rule"),
                    Line2D([], [], marker="o", ls="", mfc="white", mec=ORANGE, mew=1.8, ms=7, label="Breaks a hard rule (as produced)"),
                    Line2D([], [], color=BLUE, lw=2, label="ZSTP max–min")],
           loc="lower center", ncol=3, frameon=False, fontsize=7.5)
fig.tight_layout(rect=(0, 0.06, 1, 1)); fig.savefig("fig_ablation.png", dpi=220)
