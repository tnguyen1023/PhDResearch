"""Fill zstp13.tpl.tex with tables and numbers computed from the result files -> zstp_ieee13.tex."""
import json, re

R = json.load(open("/home/claude/zstp/out/results.json"))
M = {m["method"]: m for m in R["methods"]}
PG = json.load(open("/home/claude/zstp/out/per_gap.json"))
P = PG["schedules"]
L2P = {r["B"]: r for r in json.load(open("/home/claude/zstp/out/l2_paired.json"))}
AB = json.load(open("/home/claude/zstp/out/ablation.json"))
T = json.load(open("/home/claude/zstp/out/tables.json"))
RS = M["RC2 max-min (r*)"]["r_min"]

A = "RC2 max-min (r*)"
ORDER = ["RC2 max-min (r*)", "RC2 tier-lex Q-med", "RC2 burst-first (V3 §5.2)", "Greedy-Diverse", "Random", "Greedy-BiDir", "Static-Best",
         "LP-Relaxation", "Max-PathCov", "Round-Robin", "Single-Zone", "ThreatIntel-Only", "Greedy-HighRho"]
BASES = ORDER[3:]
LAB = {"RC2 max-min (r*)": "\\textbf{ZSTP max--min ($r^\\star$)}", "RC2 tier-lex Q-med": "RC2 medium profile", "RC2 burst-first (V3 §5.2)": "RC2 burst-first"}
lab = lambda n: LAB.get(n, n)


def num(x, d=0, sign=False):
    s = f"{x:+,.{d}f}" if sign else f"{x:,.{d}f}"
    return s.replace("-", "$-$")


def ci(p, d=0):
    return f"{num(p['diff'], d, True)} [{num(p['ci95'][0], d, True)}, {num(p['ci95'][1], d, True)}]"


def row(cells, bold=False):
    if bold:
        cells = [c if c.startswith("\\textbf") else f"\\textbf{{{c}}}" for c in cells]
    return " & ".join(cells) + " \\\\"


V = {}
# ---------------- G1 table
rows = []
for n in ORDER:
    g = P[n]["G1"]
    rows.append(row([lab(n), num(g["burn_burst_pct"], 1), num(g["credit_lost_burst_pct"], 1), num(g["FM_avg_burst"], 2),
                     num(g["emu_rec_any_burst_pct"], 1), "---" if n == A else ci(g["paired_rec_any_burst"], 1)], n == A))
    if n == A:
        rows.append("\\midrule")
V["TAB_G1"] = "\n".join(rows)
# ---------------- G2 table
rows = []
for n in ORDER:
    g = P[n]["G2"]
    rows.append(row([lab(n), str(g["C12"]), str(g["C14"]), str(g["C14_leaks"]), num(g["pburn_burst_pct"], 1),
                     num(g["emu_rec_fp_burst_pct"], 1), "---" if n == A else ci(g["paired_rec_fp_burst"], 1)], n == A))
    if n == A:
        rows.append("\\midrule")
V["TAB_G2"] = "\n".join(rows)
# ---------------- G3 table
rows = []
for n in ORDER:
    g = P[n]["G3"]
    rows.append(row([lab(n), str(g["C8"]), str(g["C10a"]), str(g["C10b"]), str(g["longest_uncovered_slots"]), num(g["path_persistence_pct"], 0),
                     num(g["early_intercept_med_pct"], 1), num(g["emu_crit_rate_pct"], 1), "---" if n == A else ci(g["paired_crit_rate"], 1)], n == A))
    if n == A:
        rows.append("\\midrule")
V["TAB_G3"] = "\n".join(rows)
# ---------------- G4 table (raw and repaired)
rows = [row([lab(A), num(RS, 2), "feasible", "1.00", "---", "---"], True), "\\midrule"]
for n in ORDER[1:]:
    raw = M[n]; rep = M.get(n + " (repaired)")
    if rep is None:
        rows.append(row([lab(n), num(raw["r_min"], 2), "feasible", f"{RS / raw['r_min']:.2f}", ci(L2P[n]), "---"]))
    else:
        rows.append(row([lab(n), num(raw["r_min"], 2), f"{num(rep['r_min'], 2)} ({rep['repair']['changes']})", f"{RS / rep['r_min']:.2f}",
                         ci(L2P[n]), ci(L2P[n + ' (repaired)'])]))
V["TAB_G4"] = "\n".join(rows)
# ---------------- main table
rows = []
for n in ORDER:
    m = M[n]
    v = ", ".join(f"{k}$\\times${len(x)}" for k, x in sorted(m["violations"].items())) or "none"
    rows.append(row([lab(n), f"{num(m['r_min'], 2)} ({m['worst_profile']})", v] + [num(m["scores"][t]["Q"], 0) for t in ("low", "med", "high", "burst")], n == A))
    if n == A:
        rows.append("\\midrule")
V["TAB_MAIN"] = "\n".join(rows)
# ---------------- ablation table
g = AB.__getitem__
def arow(gap, name, r, bold=False):
    v = ", ".join(f"{k}$\\times${x}" for k, x in sorted(r["violations"].items())) or "none"
    return row([gap, name, v, num(r["worst_case"], 2), f"{100 * r['worst_case'] / RS:.1f}", f"{r['burn_burst_pct']:.1f}",
                num(r["emulated_worst_mean"]), "---" if r["paired_vs_maxmin"] is None else ci(r["paired_vs_maxmin"])], bold)
A2, A3, A3h = g("A2 identity-blind (G2)"), g("A3 per-slot re-solve, no inter-slot rules (G3)"), g("A3h full horizon, no inter-slot rules (G3, supplementary)")
rows = [arow("---", "ZSTP max--min (full model)", g("ZSTP max-min"), True), "\\midrule",
        arow("G1", "A1 recognition-blind planner", g("A1 recognition-blind (G1)")),
        arow("G2", "A2 identity-blind planner", A2),
        arow("G2", f"\\quad after repair ({A2['repaired']['repair_changes']} changes)", A2["repaired"]),
        arow("G3", "A3 per-slot re-solve, no inter-slot rules", A3),
        arow("G3", f"\\quad after repair ({A3['repaired']['repair_changes']} changes)", A3["repaired"]),
        arow("G3", "A3h full horizon, no inter-slot rules$^\\dagger$", A3h),
        arow("G3", f"\\quad after repair ({A3h['repaired']['repair_changes']} changes)", A3h["repaired"]),
        arow("G4", "A4 expected payoff, uniform prior", g("A4 expected payoff, uniform prior (G4)"))]
for t in ("low", "med", "high", "burst"):
    rows.append(arow("G4", f"\\quad prior 0.7 on $\\theta_{{\\mathrm{{{t}}}}}$", g(f"A4-{t} expected payoff, prior 0.7 on theta_{t} (G4)")))
V["TAB_ABL"] = "\n".join(rows)


# ---------------- emulation by profile
TH = ["low", "med", "high", "burst"]
rows = []
for n in ORDER:
    st = M[n]["L2_stochastic"]; worst = min(TH, key=lambda t: st[t]["Q_mean"])
    rows.append(row([lab(n) if n != A else "\\textbf{ZSTP max--min}"] + [num(st[t]["Q_mean"]) + ("$^*$" if t == worst else "") for t in TH], n == A))
    if n == A:
        rows.append("\\midrule")
V["TAB_EMU"] = "\n".join(rows)
others = [n for n in M if n not in (A, "RC2 max-min + Q-med tie-break")]
assert len(others) == 22
za = M[A]["L2_stochastic"]
for t in TH:
    V["EMU_" + t.upper()] = str(sum(1 for n in others if M[n]["L2_stochastic"][t]["Q_mean"] > za[t]["Q_mean"]))


# ---------------- appendix: instance tables (from instance.py)
import sys
sys.path.insert(0, "/home/claude/zstp")
import instance as _inst
I = _inst.build_xlarge()
assert I["hash"] == "5cb2c5f369c5"
esc = lambda x: x.replace("_", "\\_")
rows = []
for pn, p in I["paths"].items():
    hops = ", ".join(f"({z}, {j}, {iv:g})" + ("$^\\ast$" if k == p["critical"] else "") for k, (z, j, iv) in enumerate(p["hops"]))
    rows.append(f"$\\pi_{{{len(rows)+1}}}$ {esc(pn)} & {hops} & {p['rho']:.2f} \\\\")
V["TAB_PATHS"] = "\n".join(rows)
rows = []
for i in I["K"]:
    zs = [z for z in I["Z"] if i in I["type_zone_ok"][z] and not (z in I["air_gapped"] and i in I["air_gap_crossing_types"])]
    rows.append(f"{esc(i)} & {', '.join(I['trap_techniques'][i])} & {', '.join(zs)} \\\\")
V["TAB_TRAPS"] = "\n".join(rows)
pnames = list(I["paths"])
V["PATH_HDR"] = " & ".join(f"$\\omega_{{\\pi_{k+1}}}$" for k in range(len(pnames)))
rows = []
for th, pr in I["profiles"].items():
    tds = sorted(set(I["tau_d"][th].values()))
    rows.append(f"$\\theta_{{\\mathrm{{{th}}}}}$ & {pr['rho']:.2f} & {'/'.join(map(str, tds))} & {I['tau_dp'][th]} & " +
                " & ".join(f"{pr['omega'][pn]:g}" for pn in pnames) + " \\\\")
V["TAB_PROFILES"] = "\n".join(rows)


# ---------------- fairness table (repaired baselines)
rows = []
for n in BASES:
    rn = n + " (repaired)"
    e = P[rn]
    rows.append(row([f"{n} ({M[rn]['repair']['changes']})", num(e["G1"]["emu_rec_any_burst_pct"], 1), ci(e["G1"]["paired_rec_any_burst"], 1),
                     num(e["G2"]["emu_rec_fp_burst_pct"], 1), ci(e["G2"]["paired_rec_fp_burst"], 1),
                     num(e["G3"]["emu_crit_rate_pct"], 1), ci(e["G3"]["paired_crit_rate"], 1), ci(L2P[rn])]))
V["TAB_FAIR"] = "\n".join(rows)
g4r = [L2P[n + " (repaired)"] for n in BASES]
assert all(p["ci95"][0] > 0 for p in g4r)
V["R_DG4"] = f"{num(min(p['diff'] for p in g4r))}--{num(max(p['diff'] for p in g4r))}"

# ---------------- summary numbers
def rng(vals, d=1):
    return f"{num(min(vals), d)}--{num(max(vals), d)}"
z = P[A]
bas = [P[n] for n in BASES]
reps = [P[n + " (repaired)"] for n in BASES if n + " (repaired)" in P]
assert all(b["G1"]["paired_rec_any_burst"]["ci95"][0] > 0 for b in bas + reps)
assert all(b["G2"]["paired_rec_fp_burst"]["ci95"][0] > 0 for b in bas + reps)
assert all(b["G3"]["paired_crit_rate"]["ci95"][0] > 0 for b in bas + reps)
V["Z_BURN"] = num(z["G1"]["burn_burst_pct"], 1); V["Z_LOST"] = num(z["G1"]["credit_lost_burst_pct"], 1)
V["Z_EREC"] = num(z["G1"]["emu_rec_any_burst_pct"], 1); V["Z_EFP"] = num(z["G2"]["emu_rec_fp_burst_pct"], 1)
V["Z_CRIT"] = num(z["G3"]["emu_crit_rate_pct"], 1)
V["B_BURN"] = rng([b["G1"]["burn_burst_pct"] for b in bas]); V["B_LOST"] = rng([b["G1"]["credit_lost_burst_pct"] for b in bas])
V["B_EREC"] = rng([b["G1"]["emu_rec_any_burst_pct"] for b in bas]); V["B_DREC"] = rng([b["G1"]["paired_rec_any_burst"]["diff"] for b in bas])
V["R_DREC"] = rng([b["G1"]["paired_rec_any_burst"]["diff"] for b in reps])
V["B_EFP"] = rng([b["G2"]["emu_rec_fp_burst_pct"] for b in bas]); V["B_DFP"] = rng([b["G2"]["paired_rec_fp_burst"]["diff"] for b in bas])
V["R_DFP"] = rng([b["G2"]["paired_rec_fp_burst"]["diff"] for b in reps])
V["B_CRIT"] = rng([b["G3"]["emu_crit_rate_pct"] for b in bas]); V["B_DCRIT"] = rng([b["G3"]["paired_crit_rate"]["diff"] for b in bas])
V["R_DCRIT"] = rng([b["G3"]["paired_crit_rate"]["diff"] for b in reps])
viol_g3 = [n for n in BASES if P[n]["G3"]["C10a"] + P[n]["G3"]["C10b"] + P[n]["G3"]["C8"] > 0]
V["N_G3VIOL"] = str(len(viol_g3))
V["G3VIOL_GAP"] = rng([P[n]["G3"]["longest_uncovered_slots"] for n in viol_g3 if P[n]["G3"]["C10b"] > 0], 0)
V["G3VIOL_CRIT"] = rng([P[n]["G3"]["emu_crit_rate_pct"] for n in viol_g3])
V["G3OK_CRIT"] = rng([P[n]["G3"]["emu_crit_rate_pct"] for n in BASES if n not in viol_g3])
idb = [n for n in BASES if P[n]["G2"]["C12"] + P[n]["G2"]["C14"] > 0]
V["N_IDVIOL"] = str(len(idb))
V["QMED_DREC"] = ci(P["RC2 tier-lex Q-med"]["G1"]["paired_rec_any_burst"], 1)
V["QMED_DCRIT"] = ci(P["RC2 tier-lex Q-med"]["G3"]["paired_crit_rate"], 1)
V["BF_DCRIT"] = ci(P["RC2 burst-first (V3 §5.2)"]["G3"]["paired_crit_rate"], 1)
V["EPISODES"] = f"{PG['meta']['episodes_replayed']:,}"
zb = R["zero_burn"]
assert zb["all_profiles"] == "INFEASIBLE"
V["ZB_C3"] = num(zb["churn3_all_profiles_r_int"] / 100, 2); V["ZB_C3U"] = num(zb["churn3_unconstrained_r_int"] / 100, 2)
V["ZB_LM"] = num(zb["low_med_only_r_int"] / 100, 2)
# ablation summary
core = [AB["A1 recognition-blind (G1)"], A2, A2["repaired"], A3, A3["repaired"]]
loss = lambda r: 100 * (1 - r["worst_case"] / RS)
V["ABL_LO"] = f"{100 - max(loss(r) for r in core):.1f}"; V["ABL_HI"] = f"{100 - min(loss(r) for r in core):.1f}"
ds = [r["paired_vs_maxmin"]["diff"] for r in core]
V["ABL_DLO"] = f"{min(ds):,.0f}"; V["ABL_DHI"] = f"{max(ds):,.0f}"
A4p = {t: AB[f"A4-{t} expected payoff, prior 0.7 on theta_{t} (G4)"] for t in ("low", "med", "high", "burst")}
V["A4_LOW"] = f"{loss(A4p['low']):.1f}"; V["A4_MED"] = f"{loss(A4p['med']):.1f}"; V["A4_BURST"] = f"{loss(A4p['burst']):.1f}"
V["A4_MAX"] = f"{max(loss(r) for r in A4p.values()):.1f}"
V["A1_N"] = str(AB["A1 recognition-blind (G1)"]["deployments"]); V["Z_N"] = str(AB["ZSTP max-min"]["deployments"])
V["A1_BURN"] = f"{AB['A1 recognition-blind (G1)']['burn_burst_pct']:.1f}"; V["A1_EREC"] = f"{AB['A1 recognition-blind (G1)']['emulated_recognized_pct']['burst']:.1f}"
V["A2_BURN"] = f"{A2['burn_burst_pct']:.1f}"; V["A2_C14"] = str(A2["violations"]["C14"])
V["A3_PERS"] = f"{A3['path_persistence_pct']:.0f}"; V["A3_C10B"] = str(A3["violations"]["C10b"])
V["A3H_PCT"] = f"{100 * A3h['worst_case'] / RS:.1f}"; V["A3H_REP"] = f"{100 * A3h['repaired']['worst_case'] / RS:.1f}"
V["A3H_CI"] = ci(A3h["paired_vs_maxmin"]); V["A3H_RCI"] = ci(A3h["repaired"]["paired_vs_maxmin"])
V["A4_CI"] = ci(AB["A4 expected payoff, uniform prior (G4)"]["paired_vs_maxmin"]); V["A4B_CI"] = ci(A4p["burst"]["paired_vs_maxmin"])
V["HC"] = f"{AB['meta']['hard_clauses']:,}"

tpl = open("zstp13.tpl.tex", encoding="utf8").read()
keys = set(re.findall(r"@@([A-Z0-9_]+)@@", tpl))
missing = keys - set(V)
assert not missing, missing
for k in keys:
    tpl = tpl.replace(f"@@{k}@@", V[k])
open("zstp_ieee13.tex", "w", encoding="utf8").write(tpl)
json.dump(V, open("gen13_values.json", "w"), indent=1, ensure_ascii=False)
print("filled", len(keys), "placeholders")
for k in sorted(V):
    if not k.startswith("TAB"):
        print(k, V[k])
