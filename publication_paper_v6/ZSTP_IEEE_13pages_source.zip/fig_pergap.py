import json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
P = json.load(open("per_gap.json"))["schedules"]
BLUE, ORANGE, INK, INK2, GRID = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e6e5e1"
order = ["RC2 tier-lex Q-med", "RC2 burst-first (V3 §5.2)", "Greedy-Diverse", "Random", "Greedy-BiDir", "Static-Best", "LP-Relaxation",
         "Max-PathCov", "Round-Robin", "Single-Zone", "ThreatIntel-Only", "Greedy-HighRho"]
lab = {"RC2 tier-lex Q-med": "RC2 medium profile", "RC2 burst-first (V3 §5.2)": "RC2 burst-first"}
panels = [("G1", "paired_rec_any_burst", "(a) G1 recognition\nunder θ_burst\nbaseline − ZSTP (pp)"),
          ("G2", "paired_rec_fp_burst", "(b) G2 fingerprint\nrecognition, θ_burst\nbaseline − ZSTP (pp)"),
          ("G3", "paired_crit_rate", "(c) G3 critical-hop\ninterception\nZSTP − baseline (pp)"),
          ("G4", "paired_worst_mean", "(d) G4 worst-profile\nemulated score\nZSTP − baseline")]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7.5, "axes.edgecolor": GRID, "xtick.color": INK2, "ytick.color": INK,
                     "axes.titlesize": 7.8, "axes.titleweight": "bold", "axes.titlecolor": INK})
fig, axs = plt.subplots(1, 4, figsize=(7.16, 3.9), sharey=True)
ys = list(range(len(order)))[::-1]
for ax, (g, key, title) in zip(axs, panels):
    for y, n in zip(ys, order):
        e = P[n]; p = e[g][key]; feas = e["feasible"]
        col = BLUE if n.startswith("RC2") else ORANGE
        ax.plot(p["ci95"], [y, y], color=col, lw=1.8, solid_capstyle="round")
        ax.plot(p["diff"], y, "o", ms=5.5, mfc=col if feas else "white", mec=col, mew=1.5, zorder=3)
    ax.axvline(0, color=INK2, lw=0.9, ls="--")
    ax.set_title(title, loc="left")
    for s in ("top", "right", "left"): ax.spines[s].set_visible(False)
    ax.grid(axis="x", color=GRID, lw=0.7); ax.set_axisbelow(True); ax.tick_params(length=0)
axs[0].set_yticks(ys, [lab.get(n, n) for n in order])
fig.legend(handles=[Line2D([], [], marker="o", ls="", mfc="white", mec=ORANGE, mew=1.5, ms=6, label="Baseline (breaks a hard rule as produced)"),
                    Line2D([], [], marker="o", ls="", mfc=BLUE, mec=BLUE, ms=6, label="Other RC2 procedure"),
                    Line2D([], [], color=INK2, lw=0.9, ls="--", label="no difference (right of line favours ZSTP)")],
           loc="lower center", ncol=3, frameon=False, fontsize=6.8)
fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig("fig_pergap.png", dpi=220)
