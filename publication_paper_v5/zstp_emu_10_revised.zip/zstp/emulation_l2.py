"""L2 process emulation: real TCP honeypot sockets, Bernoulli attacker agents, STIX 2.1 bundles.

Each deployment (i, z, t, r) is an asyncio TCP server on 127.0.0.1 that returns a banner carrying
its type, zone and fingerprint and logs every connection. An attacker agent (one per episode)
walks the H slots:
  * start of slot t: it decides which honeypots it recognizes as burned, using ONLY its own
    observation history (banners it actually received): (type, zone) seen in each of the previous
    tau_d slots, or fingerprint seen in each of the previous tau_dp slots.
  * recon: each zone is scanned with probability p_probe; a scan connects to every honeypot in that
    zone (banner grab -> observation). Burned honeypots are recognized and yield no credit.
  * attack: each path is traversed with probability p_path; at each hop it connects to the live
    honeypot (if any) that detects the hop's technique.
Credit is computed from the server-side connection logs only (never from the evaluator):
cov/e from attack hits, technique/family from any hit on a live honeypot, L1 per live honeypot hit.

deterministic mode (p_probe = p_path = 1): the attacker sees everything, so the log-derived score
must equal the evaluator's Q exactly -- a check of the model semantics over real sockets.
stochastic mode (p_probe = rho_theta, p_path = min(1, rho_pi * omega_theta_pi)): reports the
empirical mean and spread of the score and burn over N episodes.
"""
import asyncio, json, random, uuid, hashlib, statistics
from collections import defaultdict

NS = uuid.UUID("6f1c2d3e-0000-4000-8000-00000000a11c")


class Honeypot:
    def __init__(self, dep, fp, log):
        self.dep, self.fp, self.log = dep, fp, log
        self.server, self.port = None, None

    async def handle(self, reader, writer):
        line = await reader.readline()
        msg = json.loads(line.decode())
        i, z, t, r = self.dep
        writer.write((json.dumps({"banner": f"ZSTP-{i}", "zone": z, "fingerprint": self.fp}) + "\n").encode())
        await writer.drain()
        writer.close()
        self.log.append({"dep": self.dep, **msg})

    async def start(self):
        self.server = await asyncio.start_server(self.handle, "127.0.0.1", 0)
        self.port = self.server.sockets[0].getsockname()[1]


async def _connect(hp, msg):
    reader, writer = await asyncio.open_connection("127.0.0.1", hp.port)
    writer.write((json.dumps(msg) + "\n").encode())
    await writer.drain()
    banner = json.loads((await reader.readline()).decode())
    writer.close()
    return banner


async def _episode(inst, th, hps, rnd, ep, deterministic):
    H = inst["H"]
    seen_tz, seen_fp = defaultdict(set), defaultdict(set)  # attacker's observation history
    prof = inst["profiles"][th]
    for t in range(H):
        slot = [hp for hp in hps if hp.dep[2] == t]
        def burned(hp):
            i, z, _, r = hp.dep
            td, tp = inst["tau_d"][th][z], inst["tau_dp"][th]
            ub = t >= td and all(s in seen_tz[(i, z)] for s in range(t - td, t))
            vb = t >= tp and all(s in seen_fp[hp.fp] for s in range(t - tp, t))
            return ub or vb
        state = {hp: burned(hp) for hp in slot}
        # recon
        for z in inst["Z"]:
            if deterministic or rnd.random() < prof["rho"]:
                for hp in slot:
                    if hp.dep[1] == z:
                        b = await _connect(hp, {"ep": ep, "t": t, "purpose": "recon", "recognized": state[hp]})
                        seen_tz[(hp.dep[0], z)].add(t); seen_fp[b["fingerprint"]].add(t)
        # attack traversal
        for pn, p in inst["paths"].items():
            pa = 1.0 if deterministic else min(1.0, p["rho"] * prof["omega"][pn])
            if rnd.random() >= pa and not deterministic:
                continue
            for hi, (hz, hj, _) in enumerate(p["hops"]):
                for hp in slot:
                    i, z, _, r = hp.dep
                    if z == hz and hj in inst["trap_techniques"][i] and not state[hp]:
                        await _connect(hp, {"ep": ep, "t": t, "purpose": "attack", "path": pn, "hop": hi,
                                            "technique": hj, "recognized": False})


def score_from_logs(inst, th, log_ep):
    c = inst["coef"][th]
    live_hit = {tuple(e["dep"]) for e in log_ep if not e["recognized"]}
    cov = {(e["path"], e["hop"], e["t"]) for e in log_ep if e["purpose"] == "attack"}
    Q = 0
    for pn, p in inst["paths"].items():
        n = len(p["hops"])
        for t in range(inst["H"]):
            if any((pn, h, t) in cov for h in range(n - 1)):
                Q += c["L4"][f"{pn}|{t}"]
            for h in range(n):
                if (pn, h, t) in cov:
                    Q += c["L3"][f"{pn}|{h}|{t}"]
    techs = {j for (i, z, t, r) in live_hit for j in inst["trap_techniques"][i] if j in inst["techniques"]}
    fams = {inst["techniques"][j]["family"] for j in techs}
    Q += sum(c["L2_tech"][j] for j in techs) + sum(c["L2_fam"][f] for f in fams)
    Q += sum(c["L1"][f"{i}|{r}"] for (i, z, t, r) in live_hit)
    recognized = {tuple(e["dep"]) for e in log_ep if e["recognized"]}
    return Q, len(recognized)


async def _run(inst, schedule, th, episodes, deterministic, seed_key):
    log = []
    fp = inst["fingerprint"]
    hps = [Honeypot(tuple(d), fp[d[3]], log) for d in sorted(set(map(tuple, schedule)))]
    for hp in hps:
        await hp.start()
    results = []
    try:
        for ep in range(episodes):
            seed = int(hashlib.sha256(f"{seed_key}|{th}|{ep}".encode()).hexdigest()[:12], 16)
            rnd = random.Random(seed)
            start = len(log)
            await _episode(inst, th, hps, rnd, ep, deterministic)
            q, nrec = score_from_logs(inst, th, log[start:])
            results.append((q, nrec))
    finally:
        for hp in hps:
            hp.server.close()
            await hp.server.wait_closed()
    return results, log


def emulate(inst, schedule, th, episodes=1, deterministic=True, seed_key="x"):
    res, log = asyncio.run(_run(inst, schedule, th, episodes, deterministic, seed_key))
    S = inst["scale"]
    qs = [q / S for q, _ in res]
    n = max(1, len(set(map(tuple, schedule))))
    burn = [100.0 * k / n for _, k in res]
    return {"episodes": episodes, "connections": len(log),
            "Q_mean": statistics.mean(qs), "Q_sd": statistics.pstdev(qs) if len(qs) > 1 else 0.0,
            "Q_min": min(qs), "Q_list": qs, "recognized_pct_mean": statistics.mean(burn), "log": log}


def stix_bundle(inst, name, th, log):
    """STIX 2.1 bundle built from observed honeypot connections (one sighting per honeypot hit)."""
    def sid(kind, key):
        return f"{kind}--{uuid.uuid5(NS, key)}"
    ident = {"type": "identity", "spec_version": "2.1", "id": sid("identity", "zstp-emulator"),
             "created": "2026-09-26T00:00:00.000Z", "modified": "2026-09-26T00:00:00.000Z",
             "name": "ZSTP L2 emulator", "identity_class": "system"}
    objs = [ident]
    hits = defaultdict(list)
    for e in log:
        if not e["recognized"]:
            hits[tuple(e["dep"])].append(e)
    for dep, evs in sorted(hits.items()):
        i, z, t, r = dep
        key = f"{name}|{th}|{dep}"
        ind = {"type": "indicator", "spec_version": "2.1", "id": sid("indicator", key),
               "created": "2026-09-26T00:00:00.000Z", "modified": "2026-09-26T00:00:00.000Z",
               "name": f"Honeypot contact {i}@{z} slot {t}", "pattern_type": "stix",
               "pattern": f"[x-zstp-honeypot:type = '{i}' AND x-zstp-honeypot:zone = '{z}']",
               "valid_from": "2026-09-26T00:00:00.000Z", "created_by_ref": ident["id"]}
        techs = sorted({e.get("technique") for e in evs if e.get("technique")})
        sig = {"type": "sighting", "spec_version": "2.1", "id": sid("sighting", key),
               "created": "2026-09-26T00:00:00.000Z", "modified": "2026-09-26T00:00:00.000Z",
               "sighting_of_ref": ind["id"], "count": len(evs), "created_by_ref": ident["id"],
               "x_zstp_profile": th, "x_zstp_techniques": techs,
               "x_zstp_purposes": sorted({e["purpose"] for e in evs})}
        objs += [ind, sig]
    return {"type": "bundle", "id": sid("bundle", f"{name}|{th}"), "objects": objs}
