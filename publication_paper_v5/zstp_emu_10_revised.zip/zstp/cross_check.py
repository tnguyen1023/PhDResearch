"""Independent cross-check with OR-tools CP-SAT.

The model is written again from the definitions (not from the CNF), using CP-SAT's native
linear constraints. It is used to confirm (a) the exact max-min value r*, (b) the tier values
of the lexicographic Q-med optimum via four explicit passes with hard floors, and (c) the
weighted-pass Q-med optimum.
"""
import math
from ortools.sat.python import cp_model


def build(inst):
    m = cp_model.CpModel()
    K, Z, H, P = inst["K"], inst["Z"], inst["H"], inst["P"]
    fp = inst["fingerprint"]
    fps = sorted(set(fp.values()))
    x = {(i, z, t, r): m.NewBoolVar(f"x_{i}_{z}_{t}_{r}") for i in K for z in Z for t in range(H) for r in P}
    for (i, z, t, r), v in x.items():
        bad = (not inst["slot_valid"][t]) or (z in inst["air_gapped"] and i in inst["air_gap_crossing_types"]) or \
              not (i in inst["type_zone_ok"].get(z, []) and i in inst["role_types"][r] and z in inst["role_zones"][r])
        if bad:
            m.Add(v == 0)
    for t in range(H):
        m.Add(sum(x[(i, z, t, r)] for i in K for z in Z for r in P) <= inst["B_t"])
        for z in Z:
            m.Add(sum(x[(i, z, t, r)] for i in K for r in P) <= inst["B_z"])
        for f in fps:
            m.Add(sum(x[(i, z, t, r)] for i in K for z in Z for r in P if fp[r] == f) <= 1)
    pres = {}
    for i in K:
        for z in Z:
            for t in range(H):
                b = m.NewBoolVar("")
                m.AddMaxEquality(b, [x[(i, z, t, r)] for r in P])
                pres[(i, z, t)] = b
    used = {}
    for f in fps:
        for t in range(H):
            b = m.NewBoolVar("")
            m.AddMaxEquality(b, [x[(i, z, t, r)] for i in K for z in Z for r in P if fp[r] == f])
            used[(f, t)] = b
    for a, bb in inst["conflicts"]:
        for z in Z:
            for t in range(H):
                m.Add(pres[(a, z, t)] + pres[(bb, z, t)] <= 1)
    for i in K:
        for z in Z:
            for r in P:
                chs = []
                for t in range(1, H):
                    c = m.NewBoolVar("")
                    m.AddBoolXOr([x[(i, z, t, r)], x[(i, z, t - 1, r)], c.Not()])
                    chs.append(c)
                m.Add(sum(chs) <= inst["churn_max"])
    for pn, p in inst["paths"].items():
        hz, hj, _ = p["hops"][p["critical"]]
        ys = []
        for t in range(H):
            y = m.NewBoolVar("")
            m.AddMaxEquality(y, [x[(i, hz, t, r)] for i in K for r in P if hj in inst["trap_techniques"][i]])
            ys.append(y)
        m.Add(sum(ys) >= math.ceil(p["rho"] * H))
        W = inst["W_gap"]
        for t in range(H - W + 1):
            m.AddBoolOr(ys[t:t + W])
    Q, tiers = {}, {}
    for th in inst["profiles"]:
        c = inst["coef"][th]
        d = {}
        for (i, z, t, r), xv in x.items():
            td = inst["tau_d"][th][z]; tp = inst["tau_dp"][th]
            u = None
            if t >= td:
                u = m.NewBoolVar(""); m.AddMinEquality(u, [pres[(i, z, s)] for s in range(t - td, t)])
            v = None
            if t >= tp:
                v = m.NewBoolVar(""); m.AddMinEquality(v, [used[(fp[r], s)] for s in range(t - tp, t)])
            dv = m.NewBoolVar("")
            lits = [xv] + ([u.Not()] if u is not None else []) + ([v.Not()] if v is not None else [])
            m.AddMinEquality(dv, lits)
            d[(i, z, t, r)] = dv
        L = {"L4": [], "L3": [], "L2": [], "L1": []}
        for pn, p in inst["paths"].items():
            n = len(p["hops"])
            for t in range(H):
                covs = []
                for hi, (hz, hj, _) in enumerate(p["hops"]):
                    src = [d[(i, hz, t, r)] for i in K for r in P if hj in inst["trap_techniques"][i]]
                    cv = m.NewBoolVar("")
                    m.AddMaxEquality(cv, src) if src else m.Add(cv == 0)
                    covs.append(cv)
                    L["L3"].append(c["L3"][f"{pn}|{hi}|{t}"] * cv)
                e = m.NewBoolVar(""); m.AddMaxEquality(e, covs[:n - 1])
                L["L4"].append(c["L4"][f"{pn}|{t}"] * e)
        g = {}
        for j in inst["techniques"]:
            src = [d[k] for k in x if j in inst["trap_techniques"][k[0]]]
            gv = m.NewBoolVar(""); m.AddMaxEquality(gv, src) if src else m.Add(gv == 0)
            g[j] = gv
            L["L2"].append(c["L2_tech"][j] * gv)
        for fam in inst["families"]:
            fv = m.NewBoolVar(""); m.AddMaxEquality(fv, [g[j] for j in inst["techniques"] if inst["techniques"][j]["family"] == fam])
            L["L2"].append(c["L2_fam"][fam] * fv)
        for k, dv in d.items():
            L["L1"].append(c["L1"][f"{k[0]}|{k[3]}"] * dv)
        tiers[th] = {k: sum(v) for k, v in L.items()}
        Q[th] = sum(tiers[th].values())
    return m, x, Q, tiers


def _solve(m, secs=300):
    s = cp_model.CpSolver()
    s.parameters.max_time_in_seconds = secs
    s.parameters.num_workers = 2
    s.parameters.random_seed = 0
    st = s.Solve(m)
    return s, s.StatusName(st)


def maxmin(inst, secs=600):
    m, x, Q, _ = build(inst)
    T = m.NewIntVar(0, 10 ** 9, "T")
    for th in Q:
        m.Add(Q[th] >= T)
    m.Maximize(T)
    s, st = _solve(m, secs)
    return {"status": st, "r_star_int": int(s.Value(T)), "bound": int(s.BestObjectiveBound())}


def lex(inst, th="med", secs=300):
    m, x, Q, tiers = build(inst)
    vals, statuses = {}, []
    for k in ["L4", "L3", "L2", "L1"]:
        m.ClearObjective() if hasattr(m, "ClearObjective") else None
        m.Maximize(tiers[th][k])
        s, st = _solve(m, secs)
        statuses.append(st)
        vals[k] = int(s.Value(tiers[th][k]))
        m.Add(tiers[th][k] >= vals[k])  # hard floor for the next pass
    return {"status": statuses, "tiers_int": vals}


def weighted(inst, th="med", secs=300):
    m, x, Q, _ = build(inst)
    m.Maximize(Q[th])
    s, st = _solve(m, secs)
    return {"status": st, "objective_int": int(s.Value(Q[th]))}


def zero_burn_maxmin(inst, profiles=("low", "med", "high", "burst"), secs=600):
    """Is there a feasible schedule with no burned deployment under the given profiles, and what is
    its best worst-case score? Implemented by requiring d == x for every deployment."""
    m, x, Q, _ = build(inst)
    fp = inst["fingerprint"]; K, Z, H, P = inst["K"], inst["Z"], inst["H"], inst["P"]
    # Presence / usage indicators (exact equivalences), then: x -> not burned.
    # Equivalent to the earlier clause-product expansion (which produced ~10.8M clauses and
    # exhausted 8 GB of memory on XLarge) but linear in size.
    pres, used = {}, {}
    for i in K:
        for z in Z:
            for t in range(H):
                b = m.NewBoolVar(""); m.AddMaxEquality(b, [x[(i, z, t, r)] for r in P]); pres[(i, z, t)] = b
    for f in sorted(set(fp.values())):
        for t in range(H):
            b = m.NewBoolVar(""); m.AddMaxEquality(b, [x[(i, z, t, r)] for i in K for z in Z for r in P if fp[r] == f])
            used[(f, t)] = b
    for th in profiles:
        for (i, z, t, r), xv in x.items():
            td, tp = inst["tau_d"][th][z], inst["tau_dp"][th]
            if t >= td:  # (i,z) present in every slot t-td..t-1 and x -> forbidden
                m.AddBoolOr([xv.Not()] + [pres[(i, z, s)].Not() for s in range(t - td, t)])
            if t >= tp:  # fingerprint used in every slot t-tp..t-1 and x -> forbidden
                m.AddBoolOr([xv.Not()] + [used[(fp[r], s)].Not() for s in range(t - tp, t)])
    T = m.NewIntVar(0, 10 ** 9, "T")
    for th in Q:
        m.Add(Q[th] >= T)
    m.Maximize(T)
    s, st = _solve(m, secs)
    if st not in ("OPTIMAL", "FEASIBLE"):
        return {"status": st}
    sched = sorted(k for k, v in x.items() if s.Value(v))
    return {"status": st, "r_star_int": int(s.Value(T)), "schedule": sched}


def _product_choices(i, z, t, td, P):
    import itertools
    return itertools.product(*[[(s, rr) for rr in P] for s in range(t - td, t)])


def _product_fp(inst, f, t, tp):
    import itertools
    fp = inst["fingerprint"]
    per_slot = [[(i, z, s, r) for i in inst["K"] for z in inst["Z"] for r in inst["P"] if fp[r] == f] for s in range(t - tp, t)]
    return itertools.product(*per_slot)
