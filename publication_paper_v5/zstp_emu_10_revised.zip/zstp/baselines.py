"""Ten baseline heuristics.

Each baseline returns a raw schedule. Baselines respect the per-slot budget B_t and the obvious
type-zone placement table, but not the other hard constraints unless the heuristic's own rule
happens to. Where a heuristic optimizes a score, it uses a burn-blind Q_med (burn thresholds set
beyond the horizon), which is how single-scenario heuristics are normally scored.
All schedules are then checked and scored by the common checker/evaluator.

repair(): nearest feasible schedule = minimum number of deployment changes (RC2 over the same
hard layer, one unit soft clause per x preferring the raw value).
"""
import copy, random
import numpy as np
from scipy.optimize import linprog
import evaluator
from encoder import Enc
from pysat.examples.rc2 import RC2
from pysat.formula import WCNF


def burn_blind(inst):
    b = copy.deepcopy(inst)
    for th in b["tau_d"]:
        b["tau_d"][th] = {z: 99 for z in b["Z"]}
        b["tau_dp"][th] = 99
    return b


def plausible(inst, i, z, r):
    return i in inst["type_zone_ok"].get(z, []) and i in inst["role_types"][r] and z in inst["role_zones"][r] \
        and not (z in inst["air_gapped"] and i in inst["air_gap_crossing_types"])


def candidates(inst):
    """Static plausibility (C5, C5b) is a lookup table every baseline is given."""
    return [(i, z, r) for z in inst["Z"] for i in inst["type_zone_ok"][z] if i in inst["K"] for r in inst["P"]
            if plausible(inst, i, z, r)]


def first_role(inst, i, z, k=0):
    rs = [r for r in inst["P"] if plausible(inst, i, z, r)]
    return rs[k % len(rs)] if rs else None


def score(bb, sched):
    return evaluator.evaluate(bb, sched, "med")["Q_int"]


def _greedy(inst, gain_fn, cand=None, per_slot=None):
    cand = cand or candidates(inst)
    sched = []
    load = {t: 0 for t in range(inst["H"])}
    cap = per_slot or inst["B_t"]
    while True:
        best, bestg = None, 0
        for t in range(inst["H"]):
            if load[t] >= cap:
                continue
            for (i, z, r) in cand:
                d = (i, z, t, r)
                if d in sched:
                    continue
                g = gain_fn(sched + [d]) - gain_fn(sched)
                if g > bestg:
                    best, bestg = d, g
        if best is None:
            return sched
        sched.append(best); load[best[2]] += 1


def b_random(inst, seed=1):
    rnd = random.Random(seed)
    cand = candidates(inst)
    return [(lambda c: (c[0], c[1], t, c[2]))(rnd.choice(cand)) for t in range(inst["H"]) for _ in range(inst["B_t"])]


def b_static_best(inst):
    bb = burn_blind(inst)
    one = _greedy({**inst, "H": 1}, lambda s: score(bb, s))
    return [(i, z, t, r) for t in range(inst["H"]) for (i, z, _, r) in one]


def b_greedy_highrho(inst):
    out = []
    order = sorted(inst["paths"].items(), key=lambda kv: -kv[1]["rho"])
    for t in range(inst["H"]):
        n = 0
        for pn, p in order:
            for hz, hj, _ in p["hops"][:-1]:
                if n >= inst["B_t"]:
                    break
                for i in inst["type_zone_ok"][hz]:
                    if hj in inst["trap_techniques"][i]:
                        r = first_role(inst, i, hz)
                        if r is None:
                            continue
                        d = (i, hz, t, r)
                        if d not in out:
                            out.append(d); n += 1
                        break
    return out


def b_greedy_bidir(inst):
    bb = burn_blind(inst)
    f = lambda s: score(bb, s)
    sched = _greedy(inst, f)
    improved = True
    while improved:  # backward pass: drop deployments whose removal does not lower the score
        improved = False
        for d in list(sched):
            rest = [e for e in sched if e != d]
            if f(rest) >= f(sched):
                sched = rest; improved = True
    return sched


def b_greedy_diverse(inst):
    bb = burn_blind(inst)
    def f(s):
        ev = evaluator.evaluate(bb, s, "med")
        return ev["techniques"] * 10 ** 7 + ev["Q_int"]
    return _greedy(inst, f)


def b_round_robin(inst):
    out = []
    K = inst["K"]; k = 0
    for t in range(inst["H"]):
        n = 0; tries = 0
        while n < inst["B_t"] and tries < 50:
            i = K[k % len(K)]; k += 1; tries += 1
            zs = [z for z in inst["Z"] if any(plausible(inst, i, z, r) for r in inst["P"])]
            if not zs:
                continue
            z = zs[(t + n) % len(zs)]
            r = first_role(inst, i, z, t + n)
            out.append((i, z, t, r)); n += 1
    return out


def b_lp_relaxation(inst):
    """LP over x with a linear burn-blind surrogate (L1 + L3 of every hop the deployment covers);
    constraints: B_t, B_z, fingerprint <= 1 per slot. C4, C5b, C8, C10 are not in the LP."""
    c_med = inst["coef"]["med"]
    cand = [(i, z, t, r) for t in range(inst["H"]) for (i, z, r) in candidates(inst)]
    val = []
    for (i, z, t, r) in cand:
        v = c_med["L1"][f"{i}|{r}"]
        for pn, p in inst["paths"].items():
            for hi, (hz, hj, _) in enumerate(p["hops"]):
                if hz == z and hj in inst["trap_techniques"][i]:
                    v += c_med["L3"][f"{pn}|{hi}|{t}"]
        val.append(v)
    A, b = [], []
    fp = inst["fingerprint"]
    for t in range(inst["H"]):
        A.append([1 if d[2] == t else 0 for d in cand]); b.append(inst["B_t"])
        for z in inst["Z"]:
            A.append([1 if d[2] == t and d[1] == z else 0 for d in cand]); b.append(inst["B_z"])
        for f in set(fp.values()):
            A.append([1 if d[2] == t and fp[d[3]] == f else 0 for d in cand]); b.append(1)
    res = linprog(-np.array(val, float), A_ub=np.array(A, float), b_ub=np.array(b, float), bounds=(0, 1), method="highs")
    xs = res.x
    out = []
    for t in range(inst["H"]):
        idx = sorted([k for k, d in enumerate(cand) if d[2] == t], key=lambda k: -xs[k])[:inst["B_t"]]
        out += [cand[k] for k in idx if xs[k] > 1e-6]
    return out


def b_single_zone(inst, zone="Internal"):
    bb = burn_blind(inst)
    cand = [c for c in candidates(inst) if c[1] == zone]
    return _greedy(inst, lambda s: score(bb, s), cand=cand)


def b_threatintel_only(inst):
    """Rank role-type pairs by persona prior x technique weight; ignores paths and zones
    (places each type in the first zone where it is typical)."""
    W = {j: v["W"] for j, v in inst["techniques"].items()}
    pairs = sorted(((inst["q"][r] * sum(W[j] for j in inst["trap_techniques"][i] if j in W), i, r)
                    for r in inst["P"] for i in inst["K"]
                    if any(plausible(inst, i, z, r) for z in inst["Z"])), reverse=True)
    out = []
    for t in range(inst["H"]):
        for _, i, r in pairs[:inst["B_t"]]:
            z = next(z for z in inst["Z"] if plausible(inst, i, z, r))
            out.append((i, z, t, r))
    return out


def b_max_pathcov(inst):
    bb = burn_blind(inst)
    def f(s):
        ev = evaluator.evaluate(bb, s, "med")
        return ev["hop_coverage_pct"] * 10 ** 6 + ev["Q_int"] / 10 ** 3
    return _greedy(inst, f)


BASELINES = {
    "Greedy-BiDir": b_greedy_bidir, "Round-Robin": b_round_robin, "Static-Best": b_static_best,
    "LP-Relaxation": b_lp_relaxation, "Random": b_random, "Single-Zone": b_single_zone,
    "Greedy-Diverse": b_greedy_diverse, "Max-PathCov": b_max_pathcov,
    "ThreatIntel-Only": b_threatintel_only, "Greedy-HighRho": b_greedy_highrho,
}


def repair(inst, raw, enc=None):
    enc = enc or Enc(inst)
    raw_set = set(tuple(d) for d in raw)
    w = WCNF()
    for c in enc.hard:
        w.append(c)
    for k, xv in enc.X.items():
        w.append([xv] if k in raw_set else [-xv], weight=1)
    with RC2(w, solver="g4") as rc2:
        m = rc2.compute()
        if m is None:
            return None, None
        cost = rc2.cost
    rep = enc.decode(m)
    removed = sorted(raw_set - set(rep)); added = sorted(set(rep) - raw_set)
    return rep, {"changes": cost, "removed": removed, "added": added}
