"""Named values for the response document, computed only from out/results.json."""
import json
R = json.load(open("out/results.json"))
M = {m["method"]: m for m in R["methods"]}
f = lambda x: f"{x:,.2f}"
p = lambda x: f"{x:.1f}%"
mm, tl, sf = M["RC2 max-min (r*)"], M["RC2 tier-lex Q-med"], M["RC2 burst-first (V3 §5.2)"]
raw = [m for m in R["methods"] if m["state"] in ("infeasible", "raw") and not m["method"].startswith("RC2")]
rep = [m for m in R["methods"] if m["state"] == "repaired"]
best_raw = max(raw, key=lambda m: m["r_min"]); best_rep = max(rep, key=lambda m: m["r_min"])
feas_all = [m for m in R["methods"] if m["feasible"]]
l2best_feas = max(feas_all, key=lambda m: m["L2_emulated_worst_mean"])
l2best_all = max(R["methods"], key=lambda m: m["L2_emulated_worst_mean"])
a, k = R["adaptive"]["controlled_REDEPLOY"], R["adaptive"]["financial_KEEP_check"]
mi, z, w = R["micro"], R["zero_burn"], R["weights"]
cert = mm["solver"]["certificate"]
viol_counts = {}
for m in raw:
    for c in m["violations"]:
        viol_counts[c] = viol_counts.get(c, 0) + 1
V = {
    "code": R["meta"]["code_hash"], "inst": R["instance"]["hash"], "runtime": f"{R['meta']['seconds']:.0f}",
    "enc_vars": f"{R['encoding']['total_vars']:,}", "enc_clauses": f"{R['encoding']['hard_clauses']:,}",
    "rstar": f(mm["r_min"]), "mm_id": mm["run_id"], "mm_n": len(mm["schedule"]), "mm_worst": mm["worst_profile"],
    "mm_low": f(mm["scores"]["low"]["Q"]), "mm_med": f(mm["scores"]["med"]["Q"]), "mm_high": f(mm["scores"]["high"]["Q"]), "mm_burst": f(mm["scores"]["burst"]["Q"]),
    "mm_burn_high": p(mm["scores"]["high"]["Burn_any_pct"]), "mm_burn_med": p(mm["scores"]["med"]["Burn_any_pct"]),
    "mm_tech": mm["scores"]["med"]["techniques"], "mm_fam": mm["scores"]["med"]["families"],
    "tl_id": tl["run_id"], "tl_med": f(tl["scores"]["med"]["Q"]), "tl_r": f(tl["r_min"]), "tl_worst": tl["worst_profile"],
    "tl_tiers": " / ".join(f(v / 100) for v in tl["solver"]["tiers_int"].values()), "tl_passes": tl["solver"]["passes"],
    "wp_same": w["weighted_equals_lex"],
    "sf_id": sf["run_id"], "sf_r": f(sf["r_min"]), "sf_burst": f(sf["scores"]["burst"]["Q"]), "sf_worst": sf["worst_profile"],
    "mm_vs_tl_gain": p(100 * (mm["r_min"] - tl["r_min"]) / tl["r_min"]), "mm_vs_tl_medloss": p(100 * (tl["scores"]["med"]["Q"] - mm["scores"]["med"]["Q"]) / tl["scores"]["med"]["Q"]),
    "sf_gap": p(100 * (mm["r_min"] - sf["r_min"]) / mm["r_min"]),
    "n_raw_infeasible": sum(1 for m in raw if not m["feasible"]), "n_baselines": len(raw),
    "viol_counts": ", ".join(f"{c} in {n}" for c, n in sorted(viol_counts.items(), key=lambda x: -x[1])),
    "best_raw": best_raw["method"], "best_raw_r": f(best_raw["r_min"]),
    "best_rep": best_rep["method"], "best_rep_r": f(best_rep["r_min"]),
    "rep_changes": ", ".join(f"{m['method'].replace(' (repaired)','')} {m['repair']['changes']}" for m in rep),
    "raw_burn_range": f"{min(m['scores']['burst']['Burn_any_pct'] for m in raw):.1f}–{max(m['scores']['burst']['Burn_any_pct'] for m in raw):.1f}%",
    "raw_r_range": f"{f(min(m['r_min'] for m in raw))}–{f(max(m['r_min'] for m in raw))}",
    "l2_all_match": all(all(v["match"] for v in m["L2_deterministic"].values()) for m in R["methods"]),
    "l2_n_sched": len(R["methods"]),
    "l2_conns": f"{sum(sum(v['connections'] for v in m['L2_deterministic'].values()) for m in R['methods']):,}",
    "l2_mm_worst": f"{mm['L2_emulated_worst_mean']:,.0f}", "l2_best_feas": l2best_feas["method"],
    "l2_best_all": l2best_all["method"], "l2_best_all_v": f"{l2best_all['L2_emulated_worst_mean']:,.0f}",
    "cc_ok": all(R["cross_check"]["agree"].values()), "cc_status": R["cross_check"]["maxmin"]["status"],
    "cert_vars": f"{cert['cnf_vars']:,}", "cert_clauses": f"{cert['cnf_clauses']:,}", "cert_lines": f"{cert['proof_lines']:,}",
    "cert_ok": cert["drat_check"].get("verified"), "sat_calls": mm["solver"]["sat_calls"],
    "mi_sub": f"{mi['subsets_enumerated']:,}", "mi_feas": mi["feasible_schedules"], "mi_r": f(mi["enum_r_star"]),
    "mi_all": mi["match_r_star"] and mi["match_lex"] and mi["match_weighted"], "mi_pos": mi["schedules_with_r_gt_0"],
    "mi_distinct": mi["distinct_r_values"], "mi_cert": mi["certificate"]["drat_check"].get("verified"),
    # Algorithm 1 (paper): deployed max-min schedule vs r*' of the updated instance
    "a_dep_r": f(a["deployed_r_min_updated"]), "a_rstar": f(a["r_star_updated"]), "a_dec": a["decision"],
    "a_new_r": f(a["new_r_min"]), "a_new_med": f(a["new_Qmed"]), "a_audit": a["audit"], "a_gate": a["gate"],
    "a_cert": a["certificate"]["drat_check"].get("verified"), "a_newn": len(a["new_schedule"]),
    "a_qgen": f"{a['q_after']['Generic_Linux']:.3f}", "a_qoth": f"{a['q_after']['HR_Workstation']:.3f}",
    # earlier Q-med acceptance rule (comparison paragraph)
    "a_q0": f(a["qmed_rule"]["Qmed_old_original_inputs"]), "a_q1": f(a["qmed_rule"]["Qmed_old_updated"]), "a_qn": f(a["qmed_rule"]["Qmed_new_updated"]),
    "a_dq": f(a["qmed_rule"]["dQ"]), "a_dqp": f"{a['qmed_rule']['dQ_pct']:.1f}%",
    "a_rc": f(a["qmed_rule"]["r_min_old_updated"]), "a_rn": f(a["qmed_rule"]["r_min_new_updated"]),
    "a_rob_vs_qrule": f"{100 * (a['new_r_min'] - a['qmed_rule']['r_min_new_updated']) / a['qmed_rule']['r_min_new_updated']:.1f}%",
    "k_dep_r": f(k["deployed_r_min_updated"]), "k_rstar": f(k["r_star_updated"]), "k_dec": k["decision"],
    "w_l4unit": f(w["tier_min_unit_int"]["L4"] / 100), "w_below4": f((w["tier_totals_int"]["L3"] + w["tier_totals_int"]["L2"] + w["tier_totals_int"]["L1"]) / 100),
    "zb_all": z["all_profiles"], "zb_lm": f(z["low_med_only_r_int"] / 100), "zb_c3": f(z["churn3_all_profiles_r_int"] / 100), "zb_c3u": f(z["churn3_unconstrained_r_int"] / 100),
    "sens_max_regret": f"{max(r['base_schedule_regret_pct'] for r in R['sensitivity']['runs']):.2f}%",
    "sens_max_case": max(R['sensitivity']['runs'], key=lambda r: r['base_schedule_regret_pct']),
    "tau_d": R["instance"]["tau_d"], "tau_dp": R["instance"]["tau_dp"],
}
V["sens_max_case"] = f"{V['sens_max_case']['param']} ×{V['sens_max_case']['factor']}"
json.dump(V, open("out/vals.json", "w"), indent=1, ensure_ascii=False)
for kk, vv in V.items():
    print(kk, "=", vv)

# ---- extra values used in the response text
bid, bidr = M["Greedy-BiDir"], M["Greedy-BiDir (repaired)"]
V.update({
    "bid_med": f(bid["scores"]["med"]["Q"]), "bid_r": f(bid["r_min"]), "bid_viol": ", ".join(f"{c}×{len(v)}" for c, v in bid["violations"].items()),
    "bidr_med": f(bidr["scores"]["med"]["Q"]), "bidr_r": f(bidr["r_min"]), "bidr_ch": bidr["repair"]["changes"],
    "ratio_raw": f"{mm['r_min'] / best_raw['r_min']:.2f}", "ratio_rep": f"{mm['r_min'] / best_rep['r_min']:.2f}",
    "max_tech_rc2": max(M[x]["scores"]["med"]["techniques"] for x in M if x.startswith("RC2")),
    "tech18": ", ".join(m["method"] for m in R["methods"] if m["scores"]["med"]["techniques"] == 18) or "none",
    "a_rdrop": f"{100 * (a['qmed_rule']['r_min_old_updated'] - a['qmed_rule']['r_min_new_updated']) / a['qmed_rule']['r_min_old_updated']:.1f}%",
    "mm_sched_rows": [],
})
import evaluator, instance
inst = instance.build_xlarge()
_, _ = None, None
u, v = evaluator.burn_state(inst, [tuple(d) for d in mm["schedule"]], "high")
for d in sorted(mm["schedule"], key=lambda d: (d[2], d[1])):
    i, zz, t, r = d
    fpid = inst["fingerprint"][r]
    V["mm_sched_rows"].append([str(t), zz, i, f"{r} ({fpid})",
                               "type" if u[(i, zz, t)] else ("persona" if v[(fpid, t)] else "no")])
json.dump(V, open("out/vals.json", "w"), indent=1, ensure_ascii=False)
