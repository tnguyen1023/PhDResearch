# Code ↔ paper verification (ZSTP V3, Feedback Items 1–7)

## Verdict
The MaxSAT model, hard constraints, burn semantics, objective, max–min search, certificate and
cross-checks in the code match the paper, and the original code reproduces the paper's reported
numbers exactly (code hash 3bd3a071f2d1, instance hash 5cb2c5f369c5). Four problems were found and
fixed; three paper statements need updating.

## Reproduced exactly (original code, rerun)
Encoding 8,340 vars / 33,011 clauses · r* = 7,052.62 (θ_high), 17 SAT calls · certificate
52,386 vars / 277,714 clauses / 75,708 DRAT lines, drat-trim VERIFIED · CP-SAT r* and 4 tier values
OPTIMAL and equal · tiers 8,285.68 / 1,730.84 / 464.20 / 17.12 · all 13 rows of Table 4 · Table 2
failure counts · Table 5 values · burn 0% / 27.3%, 3 of 11 deployments · baseline burn 50–75% ·
FM 1.11 / 1.11 / 0.84 / 0.25–0.59 · L4 unit 433.50 vs 5,985.68 · zero-burn INFEASIBLE, low+med =
7,052.62 · micro 262,144 / 131 / 2,249.09, all three methods agree, VERIFIED · sensitivity 0.19% /
10.18% / q(Finance) optimal · 33.1%, 9.4%, 49.6%, 1.46× · 1,334 connections, deterministic match all ·
Q-med rule comparison 16,346.88→17,398.53 (+6.4%), 8,597.26→7,118.58 (−17.2%), +31.4% · 64 random
schedules matched.

## Problems found and fixed
1. **Algorithm 1 mismatch (major).** Paper §6.1: deployed = max–min schedule; robust re-solve;
   KEEP iff deployed schedule is feasible and attains r*′; drat-trim gate. Code: deployed = Q-med
   schedule; decision = "Q-med rises" (the rule the paper now calls "earlier"). The paper's 8,501.83
   and KEEP 7,052.66 could not come from the submitted code. adaptive.py rewritten to the paper's
   algorithm; the old rule is kept as the comparison. Reproduces 8,501.83 / 9,352.53 / REDEPLOY /
   KEEP 7,052.66; gate PASS, certificate VERIFIED.
2. **Out of memory.** cross_check.zero_burn_maxmin expanded each burn rule into all combinations
   (10.8 M clauses) and the run was killed at 8 GB. Replaced by an exactly equivalent linear
   formulation; same results, run now < 2 GB.
3. **L2 seeds tied to the code hash.** Every code edit changed the attacker's random episodes
   (paper 2,038 → 1,929 after an unrelated edit). Seeds now depend only on instance, profile and
   episode, and all schedules face the same episodes (common random numbers), enabling paired tests
   (l2_stats.py, Table R3b).
4. **Non-unique optimum.** Many schedules reach r*; the code returned an arbitrary one, so Q-med of
   the re-solved schedule was undefined (paper 15,237.92, rerun 15,771.50). Added a tie-break
   (max Q-med subject to Q_θ ≥ r* for all θ). Main max–min schedule: tie-break returns the same
   schedule, so Table 4/5 are canonical as published. Re-solved REDEPLOY schedule: 15,771.50.

Smaller: CP-SAT "agree" now requires OPTIMAL status; charts.py no longer crashes if a baseline is
feasible and no longer hard-codes axis limits/labels; stale docstrings (tier_lex is 4-pass not BMO;
τ_dp0 = 4 is stated by the paper); 95% CIs added to Table R3.

## New tests (all pass)
* test_pb.py — adder PB encoding exact for every input and threshold (120 random sums). The DRAT
  certificate is only as trustworthy as this encoding; previously untested.
* test_encoding_vs_checker.py — hard layer = rule checker in both directions on 1,635 independently
  drawn schedules (328 feasible), scores equal the evaluator for all 4 profiles. The existing test
  only checked one direction on solver-produced schedules.

## Paper text that must change
* §6.2: "Q-med 15,237.92" → **15,771.50** (highest Q-med among r*′-optimal schedules).
* §7.5 / §7.1: "highest lowest-profile mean (2,038)" — with common random numbers the max–min mean is
  **2,030**; it is significantly higher (paired bootstrap, 95%) than 20 of the 22 other schedules,
  but **not** than Greedy-Diverse as produced (+64, CI [−166, +265]; infeasible) or the RC2 Q-med
  schedule (+214, CI [−33, +333]). Reword to say so.
* §7.1: code version 3bd3a071f2d1 → **d2e22c25c5f2** (instance hash unchanged); runtime ~6 min.
* §7.5: optionally cite the two new tests alongside the 64-schedule check.

## Formulation points a reviewer may raise (no code change made)
* **L3_fwd / L3_bwd.** Code gives every covered hop 100 + 70 = 170; there is no separate forward vs
  backward notion. Either implement backward credit or say "each covered hop earns weight 170
  (100 forward + 70 backward)". Same for Table 3 L2 rows: code weights techniques by W_j and families
  by the sum of their W_j, not by a count.
* **Persona decomposition (contribution 5).** With one fingerprint per role, fingerprint rotation
  for a role is impossible in the experiments, so the claimed benefit ("retiring a fingerprint does not
  retire the role") is never exercised. An instance with 2 fingerprints per role would validate it.
* **NP-hardness wording.** In the code C10b applies regardless of ρ_π; it is vacuous in the
  reduction because H = 1 < W, not because ρ_π = 0.
* **Baselines.** Table 4 compares against raw (infeasible) baselines; repaired versions exist in the
  results (best: Greedy-Diverse repaired 3,915.24 → 1.80×). Reporting both, and adding one
  burn-aware, constraint-aware heuristic, pre-empts a "strawman" critique.
* **Scale.** One instance (640 decisions, H = 4). A small instance family with runtime growth would
  support "achievable at the evaluated problem size".
* **Unnormalized max–min.** Profiles have different coefficient scales (ω), so the binding profile
  partly reflects scale; a normalized variant (min_θ Q_θ / Q_θ*) is a cheap robustness check.
