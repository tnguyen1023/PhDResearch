"""Additional experiments for the revised paper (writes out/extra.json).

E1  Robust heuristics: two burn-aware, rule-aware baselines that optimize the SAME worst-case
    objective min_theta Q_theta as the max-min search (unlike the ten burn-blind baselines):
      * Robust-Greedy: add the deployment with the largest gain in min_theta Q_theta while the
        partial schedule respects every rule that adding deployments can break (C2, C3, C4, C5,
        C5b, C8, C12, C14); then minimum-change repair to satisfy C10a/C10b.
      * Robust-LocalSearch: hill climbing with plateau moves over feasible schedules (add / remove /
        replace one deployment; a move is kept if the schedule passes the rule checker and its
        worst case does not fall), 10 restarts x 4,000 moves, fixed seeds, started from the repaired
        Robust-Greedy schedule and from the nine other repaired baselines.
E2  Scalability: exact max-min search with certificate for horizons H = 4, 5, 6, 8 (all other
    XLarge values unchanged; kappa extended), each checked by drat-trim; also the four-pass Q-med time.
E3  Persona decomposition: XLarge with two fingerprints per role (|P| = 8, |F| = 8; each persona
    inherits its role's plausibility and prior), so a role can rotate fingerprints. r* and burn
    compared with the one-fingerprint instance.
"""
import json, time, random, copy, os, subprocess, sys
import instance, encoder, solvers, evaluator, baselines

OUT = "out"
SEED = 20261003


def drat_check(cert):
    exe = "/tmp/drat-trim/drat-trim"
    if not cert or not os.path.exists(exe):
        return {"checked": False}
    p = subprocess.run([exe, cert["cnf"], cert["drat"]], capture_output=True, text=True, timeout=3600)
    return {"checked": True, "verified": "s VERIFIED" in p.stdout}


MONOTONE = {"C2", "C3", "C4", "C5", "C5b", "C8", "C12", "C14", "F15"}


def partial_ok(inst, sched):
    return not (set(evaluator.check(inst, sched)) & MONOTONE)


def rmin(inst, sched):
    return evaluator.evaluate_all(inst, sched)["r_min_int"]


def robust_greedy(inst):
    cand = [(i, z, t, r) for t in range(inst["H"]) for (i, z, r) in baselines.candidates(inst)]
    sched, cur = [], rmin(inst, [])
    while True:
        best, bestv = None, cur
        for d in cand:
            if d in sched:
                continue
            s2 = sched + [d]
            if not partial_ok(inst, s2):
                continue
            v = rmin(inst, s2)
            if v > bestv:
                best, bestv = d, v
        if best is None:
            return sched
        sched.append(best); cur = bestv


def local_search(inst, start, rnd, moves=4000):
    cand = [(i, z, t, r) for t in range(inst["H"]) for (i, z, r) in baselines.candidates(inst)]
    cur = list(evaluator.norm(start)); cv = rmin(inst, cur)
    assert not evaluator.check(inst, cur)
    best, bv = list(cur), cv
    for _ in range(moves):
        s2 = list(cur); op = rnd.random()
        if op < 0.3 and s2:
            s2.pop(rnd.randrange(len(s2)))
        elif op < 0.6:
            d = rnd.choice(cand)
            if d in s2:
                continue
            s2.append(d)
        elif s2:
            d = rnd.choice(cand)
            if d in s2:
                continue
            s2[rnd.randrange(len(s2))] = d
        if evaluator.check(inst, s2):
            continue
        v = rmin(inst, s2)
        if v >= cv:
            cur, cv = s2, v
            if v > bv:
                best, bv = list(s2), v
    return best, bv


def e1(inst, enc):
    S = inst["scale"]
    t0 = time.time()
    g_raw = robust_greedy(inst)
    g_viol = evaluator.check(inst, g_raw)
    g_rep, info = baselines.repair(inst, g_raw, enc) if g_viol else (g_raw, {"changes": 0})
    t_g = time.time() - t0
    starts = {"Robust-Greedy (repaired)": g_rep}
    for name, fn in baselines.BASELINES.items():
        raw = fn(inst)
        rep, _ = baselines.repair(inst, raw, enc) if evaluator.check(inst, raw) else (raw, None)
        starts[name + " (repaired)"] = rep
    rnd = random.Random(SEED)
    t1 = time.time()
    runs = []
    for k, (sname, st) in enumerate(starts.items()):
        b, v = local_search(inst, st, random.Random(SEED + k))
        runs.append({"start": sname, "start_r": rmin(inst, st) / S, "final_r": v / S, "schedule": [list(d) for d in b]})
    t_ls = time.time() - t1
    best = max(runs, key=lambda r: r["final_r"])
    ev_g = evaluator.evaluate_all(inst, g_rep)
    ev_ls = evaluator.evaluate_all(inst, [tuple(d) for d in best["schedule"]])
    return {
        "robust_greedy": {"raw_violations": {k: len(v) for k, v in g_viol.items()}, "repair_changes": info["changes"],
                          "r_min": ev_g["r_min"], "worst_profile": ev_g["worst_profile"],
                          "per_profile": {th: v["Q"] for th, v in ev_g["per_profile"].items()},
                          "burn_burst_pct": ev_g["per_profile"]["burst"]["Burn_any_pct"], "seconds": round(t_g, 1),
                          "schedule": [list(d) for d in g_rep]},
        "local_search": {"restarts": len(runs), "moves_per_restart": 4000, "runs": runs,
                         "best_r": best["final_r"], "best_start": best["start"],
                         "mean_r": sum(r["final_r"] for r in runs) / len(runs),
                         "n_reaching_rstar": sum(1 for r in runs if round(r["final_r"] * S) >= 705262),
                         "best_per_profile": {th: v["Q"] for th, v in ev_ls["per_profile"].items()},
                         "best_worst_profile": ev_ls["worst_profile"], "seconds": round(t_ls, 1)},
    }


def variant(H=4, fp_per_role=1):
    base = instance.build_xlarge()
    inst = {k: v for k, v in base.items() if k not in ("coef", "tau_d", "tau_dp", "slot_valid", "families", "hash")}
    inst["name"] = f"XLarge-H{H}-F{fp_per_role}"
    inst["H"] = H
    inst["kappa"] = [8] * H
    if fp_per_role > 1:
        roles = base["P"]
        P, fpm, rt, rz, q = [], {}, {}, {}, {}
        for r in roles:
            for k in range(fp_per_role):
                p = f"{r}#{k + 1}"
                P.append(p); fpm[p] = f"{base['fingerprint'][r]}{'abcdefgh'[k]}"
                rt[p] = base["role_types"][r]; rz[p] = base["role_zones"][r]; q[p] = base["q"][r]
        inst.update({"P": P, "fingerprint": fpm, "role_types": rt, "role_zones": rz, "q": q})
    return instance.finalize(inst)


def solve_variant(inst, tag):
    enc = encoder.Enc(inst)
    t0 = time.time()
    mm = solvers.maxmin(enc, proof_path=f"{OUT}/maxmin_{tag}")
    t_mm = time.time() - t0
    t0 = time.time()
    tl = solvers.tier_lex(enc, "med")
    t_tl = time.time() - t0
    cert = mm["certificate"]
    t0 = time.time(); dc = drat_check(cert); t_dc = time.time() - t0
    ev = evaluator.evaluate_all(inst, mm["schedule"])
    S = inst["scale"]
    return {"instance": inst["name"], "hash": inst["hash"], "H": inst["H"], "P": len(inst["P"]), "F": len(set(inst["fingerprint"].values())),
            "decisions": len(enc.X), "vars": enc.stats()["total_vars"], "hard_clauses": enc.stats()["hard_clauses"],
            "r_star": mm["r_star_int"] / S, "sat_calls": mm["sat_calls"], "maxmin_seconds": round(t_mm, 1),
            "qmed_4pass_seconds": round(t_tl, 2), "Qmed_lex": tl["objective_int"] / S,
            "cert_vars": cert["cnf_vars"], "cert_clauses": cert["cnf_clauses"], "proof_lines": cert["proof_lines"],
            "drat_verified": dc.get("verified"), "drat_seconds": round(t_dc, 1),
            "feasible": not evaluator.check(inst, mm["schedule"]),
            "worst_profile": ev["worst_profile"], "per_profile": {th: v["Q"] for th, v in ev["per_profile"].items()},
            "deployments": len(mm["schedule"]),
            "burn_any_pct": {th: v["Burn_any_pct"] for th, v in ev["per_profile"].items()},
            "pburn_pct": {th: v["PBurn_pct"] for th, v in ev["per_profile"].items()},
            "schedule": [list(d) for d in mm["schedule"]]}


def main(which):
    path = os.environ.get("EXTRA_OUT", f"{OUT}/extra.json")
    X = json.load(open(path)) if os.path.exists(path) else {}
    if "e1" in which:
        inst = instance.build_xlarge(); enc = encoder.Enc(inst)
        X["E1"] = e1(inst, enc)
        print("E1", X["E1"]["robust_greedy"]["r_min"], X["E1"]["local_search"]["best_r"], X["E1"]["local_search"]["mean_r"])
    if "e2" in which:
        X.setdefault("E2", {})
        for H in (4, 5, 6, 8):
            X["E2"][str(H)] = solve_variant(variant(H, 1), f"H{H}")
            r = X["E2"][str(H)]; print("E2", H, r["r_star"], r["maxmin_seconds"], r["drat_verified"])
            json.dump(X, open(path, "w"), indent=1)
    if "e3" in which:
        X["E3"] = {"F1": solve_variant(variant(4, 1), "F1"), "F2": solve_variant(variant(4, 2), "F2")}
        print("E3", X["E3"]["F1"]["r_star"], X["E3"]["F2"]["r_star"], X["E3"]["F2"]["pburn_pct"])
    json.dump(X, open(path, "w"), indent=1)


if __name__ == "__main__":
    main(sys.argv[1:] or ["e1", "e2", "e3"])
