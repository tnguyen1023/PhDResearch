"""Algorithm 1 (threat-adaptive re-scheduling), exactly as stated in the paper (Section 6.1).

Input: deployed schedule x_dep (the max-min schedule of the current instance); STIX bundle B.
Step 1  q_p := normalize(q_p + alpha * c * [p = p(B)])                         alpha = 0.3
Step 2  U11 / F15: set rho_pi from B if given; recompute tau_d, tau_dp and slot validity
        (instance.finalize); rebuild the WCNF
Step 3  Robust re-solve: r*' and x*' by the exact max-min search, with a new certificate
Step 4  Acceptance: KEEP iff x_dep satisfies every hard rule under the updated inputs and
        min_theta Q'_theta(x_dep) >= r*'; otherwise REDEPLOY x*'. Q-med is reported, never decides.
Step 5  Gate: the schedule to be deployed is re-tested against every hard rule by the independent
        checker, and (on REDEPLOY) its certificate is verified by drat-trim. If either check fails
        the change is BLOCKED and x_dep stays in place.

Also reported, for the paper's comparison paragraph: the earlier acceptance rule (REDEPLOY iff
Q-med rises), applied to the tier-lex Q-med schedule, with old and new Q-med schedules scored on
the SAME updated inputs.
"""
import instance, encoder, solvers, evaluator

ALPHA = 0.3
CAMPAIGN_ROLE = {"OT_infiltration": "Generic_Linux",       # only GK-valid role in the OT zone
                 "financial": "Finance_DB_Server"}
CAMPAIGN_PATH = {"OT_infiltration": "ot_infiltration", "financial": "web_to_db"}


def update_q(q, role, conf):
    raw = {r: v + (ALPHA * conf if r == role else 0.0) for r, v in q.items()}
    s = sum(raw.values())
    return {r: round(v / s, 6) for r, v in raw.items()}


def updated_instance(inst0, bundle):
    q1 = update_q(inst0["q"], CAMPAIGN_ROLE[bundle["campaign_class"]], bundle["confidence"])
    rho_override = {p: v["rho"] for p, v in inst0["paths"].items()}
    if bundle.get("rho_pi") is not None:
        rho_override[CAMPAIGN_PATH[bundle["campaign_class"]]] = bundle["rho_pi"]
    return instance.build_xlarge(q=q1, path_rho_override=rho_override)


def run_bundle(inst0, deployed, qmed_current, bundle, drat_check=None, out_dir="out"):
    """deployed = max-min schedule of inst0 (x_dep); qmed_current = tier-lex Q-med schedule of inst0
    (used only for the comparison with the earlier Q-med acceptance rule)."""
    deployed = [tuple(d) for d in deployed]
    inst1 = updated_instance(inst0, bundle)                                  # Steps 1-2
    enc1 = encoder.Enc(inst1)
    S = inst1["scale"]
    rs = solvers.maxmin(enc1, proof_path=f"{out_dir}/maxmin_updated_{inst1['hash']}")   # Step 3
    # r*' optima are not unique: take the one with the highest Q-med so reported Q-med is well defined
    x_new = solvers.maxmin_tiebreak(enc1, rs["r_star_int"], "med")["schedule"]
    viol_dep = evaluator.check(inst1, deployed)
    ev_dep = evaluator.evaluate_all(inst1, deployed)
    ev_new = evaluator.evaluate_all(inst1, x_new)
    keep = (not viol_dep) and ev_dep["r_min_int"] >= rs["r_star_int"]       # Step 4
    decision = "KEEP" if keep else "REDEPLOY"
    to_deploy = deployed if keep else x_new
    audit = evaluator.check(inst1, to_deploy)                                # Step 5
    cert = rs["certificate"]
    cert["drat_check"] = drat_check(cert) if drat_check else {"checked": False}
    cert_ok = keep or bool(cert["drat_check"].get("verified"))
    gate = "PASS" if (not audit and cert_ok) else "BLOCKED"

    # Comparison: earlier acceptance rule (REDEPLOY iff Q-med rises) on the Q-med schedule.
    qnew = solvers.tier_lex(enc1, "med")
    ev_q_old = evaluator.evaluate_all(inst1, qmed_current)
    ev_q_new = evaluator.evaluate_all(inst1, qnew["schedule"])
    dq = ev_q_new["per_profile"]["med"]["Q_int"] - ev_q_old["per_profile"]["med"]["Q_int"]
    return {
        "bundle": bundle, "q_before": inst0["q"], "q_after": inst1["q"],
        "rho_after": {p: v["rho"] for p, v in inst1["paths"].items()},
        "tau_d_before": inst0["tau_d"], "tau_d_after": inst1["tau_d"], "tau_dp_after": inst1["tau_dp"],
        "instance_hash_after": inst1["hash"],
        # --- Algorithm 1 (paper)
        "deployed_schedule": [list(d) for d in deployed],
        "deployed_violations_updated": viol_dep,
        "deployed_r_min_original": evaluator.evaluate_all(inst0, deployed)["r_min"],
        "deployed_r_min_updated": ev_dep["r_min"], "deployed_worst_profile_updated": ev_dep["worst_profile"],
        "deployed_Qmed_updated": ev_dep["per_profile"]["med"]["Q"],
        "r_star_updated": rs["r_star_int"] / S,
        "new_schedule": [list(d) for d in x_new],
        "new_r_min": ev_new["r_min"], "new_Qmed": ev_new["per_profile"]["med"]["Q"],
        "new_per_profile": {th: v["Q"] for th, v in ev_new["per_profile"].items()},
        "decision": decision, "acceptance_rule": "KEEP iff x_dep feasible under updated inputs and min_theta Q'(x_dep) >= r*'",
        "audit": audit or "all hard constraints pass", "certificate": cert, "gate": gate,
        # --- comparison with the earlier Q-med acceptance rule
        "qmed_rule": {
            "Qmed_old_original_inputs": evaluator.evaluate_all(inst0, qmed_current)["per_profile"]["med"]["Q"],
            "Qmed_old_updated": ev_q_old["per_profile"]["med"]["Q"],
            "Qmed_new_updated": ev_q_new["per_profile"]["med"]["Q"],
            "dQ": dq / S, "dQ_pct": 100.0 * dq / ev_q_old["per_profile"]["med"]["Q_int"],
            "decision": "REDEPLOY" if (dq > 0 or evaluator.check(inst1, qmed_current)) else "KEEP",
            "r_min_old_updated": ev_q_old["r_min"], "r_min_new_updated": ev_q_new["r_min"],
            "new_schedule": [list(d) for d in qnew["schedule"]],
        },
    }


BUNDLES = {
    "controlled_REDEPLOY": {"campaign_class": "OT_infiltration", "confidence": 0.92, "rho_pi": 0.72},
    "financial_KEEP_check": {"campaign_class": "financial", "confidence": 0.70, "rho_pi": None},
}
