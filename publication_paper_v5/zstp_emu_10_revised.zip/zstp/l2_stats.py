"""Paired statistics for the L2 stochastic emulation (reads out/results.json only).

Every schedule faces the same attacker episodes (common random numbers, see run_all.l2), so the
max-min schedule can be compared with each other schedule pairwise. Statistic: the difference of
the worst-profile mean, D = min_theta mean_e Q_A(theta,e) - min_theta mean_e Q_B(theta,e).
95% CI by paired bootstrap (episodes resampled with the same indices for both schedules,
independently per profile), 10,000 replicates, fixed seed. Writes out/l2_paired.json and a
table to out/tables.json / tables.md section "l2_paired".
"""
import json, random

R = json.load(open("out/results.json"))
M = {m["method"]: m for m in R["methods"]}
A = "RC2 max-min (r*)"
B_REPS, SEED = 10000, 20261003


def worst_mean(qs_by_th, idx):
    return min(sum(qs_by_th[th][i] for i in idx[th]) / len(idx[th]) for th in qs_by_th)


def compare(a, b, rnd):
    qa = {th: v["Q_list"] for th, v in M[a]["L2_stochastic"].items()}
    qb = {th: v["Q_list"] for th, v in M[b]["L2_stochastic"].items()}
    n = len(next(iter(qa.values())))
    full = {th: list(range(n)) for th in qa}
    d0 = worst_mean(qa, full) - worst_mean(qb, full)
    ds = []
    for _ in range(B_REPS):
        idx = {th: [rnd.randrange(n) for _ in range(n)] for th in qa}
        ds.append(worst_mean(qa, idx) - worst_mean(qb, idx))
    ds.sort()
    lo, hi = ds[int(0.025 * B_REPS)], ds[int(0.975 * B_REPS) - 1]
    p_le0 = sum(1 for d in ds if d <= 0) / B_REPS
    return {"A": a, "B": b, "worst_mean_A": worst_mean(qa, full), "worst_mean_B": worst_mean(qb, full),
            "diff": d0, "ci95": [lo, hi], "bootstrap_share_diff_le_0": p_le0, "A_better_95": lo > 0}


def main():
    rnd = random.Random(SEED)
    rows = [compare(A, b, rnd) for b in M if b != A]
    rows.sort(key=lambda r: r["diff"])
    json.dump(rows, open("out/l2_paired.json", "w"), indent=1)
    T = json.load(open("out/tables.json"))
    T["l2_paired"] = {"title": "Table R3b. L2 paired comparison (common random numbers): worst-profile mean of RC2 max-min minus that of each schedule, 95% paired-bootstrap CI",
                      "header": ["Schedule B", "Feasible", "Worst mean max-min", "Worst mean B", "Difference", "95% CI", "Max-min better at 95%"],
                      "rows": [[r["B"], "yes" if M[r["B"]]["feasible"] else "no", f"{r['worst_mean_A']:,.0f}", f"{r['worst_mean_B']:,.0f}",
                                f"{r['diff']:+,.0f}", f"[{r['ci95'][0]:+,.0f}, {r['ci95'][1]:+,.0f}]", "yes" if r["A_better_95"] else "no"] for r in rows]}
    json.dump(T, open("out/tables.json", "w"), indent=1, ensure_ascii=False)
    t = T["l2_paired"]
    with open("out/tables.md", "a") as fh:
        fh.write(f"## {t['title']}\n\n| " + " | ".join(t["header"]) + " |\n|" + "---|" * len(t["header"]) + "\n")
        for r in t["rows"]:
            fh.write("| " + " | ".join(r) + " |\n")
        fh.write("\n")
    for r in rows:
        print(f"{r['B']:32s} diff {r['diff']:+8.0f}  CI [{r['ci95'][0]:+.0f}, {r['ci95'][1]:+.0f}]  better95={r['A_better_95']}")


if __name__ == "__main__":
    main()
