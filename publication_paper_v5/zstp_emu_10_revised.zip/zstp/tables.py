"""Generate every table (Markdown + CSV + tables.json) from out/results.json only."""
import json, csv, os

R = json.load(open("out/results.json"))
TH = ["low", "med", "high", "burst"]
T = {}


def f1(x):
    return f"{x:,.2f}"


def vio(m):
    return "none" if not m["violations"] else ", ".join(f"{k}×{len(v)}" for k, v in sorted(m["violations"].items()))


rows = []
for m in R["methods"]:
    rows.append([m["method"], m["run_id"], m["state"], "yes" if m["feasible"] else "no", vio(m)] +
                [f1(m["scores"][t]["Q"]) for t in TH] + [f1(m["r_min"]), m["worst_profile"]])
T["scores"] = {"title": "Table R1. Per-profile scores from the common evaluator (XLarge)",
               "header": ["Method", "Run ID", "State", "Feasible", "Violations (checker)", "Q low", "Q med", "Q high", "Q burst", "Worst-case (min)", "Worst profile"],
               "rows": rows}

rows = []
for m in R["methods"]:
    s, st = m["scores"], m["static"]
    rows.append([m["method"], str(len(m["schedule"])), f"{s['med']['techniques']}/18", f"{s['med']['families']}/8",
                 f"{st['path_persistence_pct']:.0f}%", f"{s['med']['hop_coverage_pct']:.1f}%", f"{s['med']['early_intercept_pct']:.1f}%",
                 f"{st['zone_spread_pct']:.0f}%", f"{st['persona_diversity_pct']:.0f}%",
                 f"{s['burst']['TBurn_pct']:.1f}%", f"{s['burst']['PBurn_pct']:.1f}%", f"{s['med']['Burn_any_pct']:.1f}%",
                 str(st["C14_leaks"]), f"{s['burst']['FM_avg']:.2f}"])
T["metrics"] = {"title": "Table R2. Schedule metrics (techniques, coverage and FM at θ_med unless marked; burn at θ_burst and θ_med)",
                "header": ["Method", "Deployments", "ATT&CK tech", "Tactic fam", "Path persist (C10a+b)", "Hop cov", "Early-intercept",
                           "Zone spread", "Persona div", "TBurn θ_burst", "PBurn θ_burst", "Burn θ_med", "C14 leaks", "FM-avg θ_burst"],
                "rows": rows}

rows = []
for m in R["methods"]:
    det = all(v["match"] for v in m["L2_deterministic"].values())
    conns = sum(v["connections"] for v in m["L2_deterministic"].values())
    sto = m["L2_stochastic"]
    rows.append([m["method"], "yes" if det else "NO", str(conns)] +
                [f"{sto[t]['Q_mean']:,.0f} ± {sto[t]['Q_sd']:,.0f}" for t in TH] + [f"{m['L2_emulated_worst_mean']:,.0f}"] +
                [(lambda t: f"[{sto[t]['Q_mean'] - sto[t]['Q_ci95_half']:,.0f}, {sto[t]['Q_mean'] + sto[t]['Q_ci95_half']:,.0f}]")(
                    min(sto, key=lambda t: sto[t]["Q_mean"]))])
T["l2"] = {"title": "Table R3. L2 process emulation (real TCP sockets). Deterministic: log-derived score equals evaluator. Stochastic: mean ± sd over 100 episodes; last column = 95% CI of the worst-profile mean",
           "header": ["Method", "Deterministic match (4 profiles)", "Deterministic connections", "Emulated low", "Emulated med", "Emulated high", "Emulated burst", "Emulated worst mean", "95% CI (worst profile)"],
           "rows": rows}

cc = R["cross_check"]; mm = R["methods"][0]
cert = mm["solver"]["certificate"]
T["crosscheck"] = {"title": "Table R4. Independent cross-checks and optimality certificate (XLarge)",
                   "header": ["Quantity", "SAT / RC2", "CP-SAT (independent model)", "Agree"],
                   "rows": [["r* = max min_θ Q_θ", f1(mm["solver"]["r_star_int"] / 100), f1(cc["maxmin"]["r_star_int"] / 100) + f" ({cc['maxmin']['status']})", str(cc["agree"]["r_star"])],
                            ["Q-med 4-pass tiers L4/L3/L2/L1", " / ".join(f1(v / 100) for v in R["methods"][1]["solver"]["tiers_int"].values()),
                             " / ".join(f1(v / 100) for v in cc["lex_med"]["tiers_int"].values()), str(cc["agree"]["lex_tiers"])],
                            ["UNSAT certificate at r*+0.01", f"CNF {cert['cnf_vars']:,} vars / {cert['cnf_clauses']:,} clauses; DRAT {cert['proof_lines']:,} lines",
                             "drat-trim: " + ("VERIFIED" if cert["drat_check"].get("verified") else "not verified"), str(cert["drat_check"].get("verified"))]]}

mi = R["micro"]
T["micro"] = {"title": "Table R5. Micro-instance exhaustive validation (|K|=3, |Z|=2, H=3, |P|=2)",
              "header": ["Quantity", "Value"],
              "rows": [["Binary x / plausible x", f"{mi['binary_x']} / {mi['plausible_x']}"],
                       ["Subsets enumerated (all subsets of plausible x)", f"{mi['subsets_enumerated']:,}"],
                       ["Feasible schedules (checker)", str(mi["feasible_schedules"])],
                       ["Schedules with worst-case > 0", str(mi["schedules_with_r_gt_0"])],
                       ["r* by enumeration / SAT / CP-SAT", f"{f1(mi['enum_r_star'])} / {f1(mi['sat_r_star'])} / {f1(mi['cpsat_r_star'])}"],
                       ["SAT schedule in enumerated optimal set", str(mi["sat_schedule_in_enum_optimal_set"])],
                       ["Tier-lex Q-med: enumeration vs RC2", f"{mi['enum_best_lex_tiers']} vs {mi['rc2_lex_tiers']}"],
                       ["Weighted Q-med: enumeration vs RC2", f"{f1(mi['enum_best_Qmed'])} vs {f1(mi['rc2_weighted_Qmed'])}"],
                       ["DRAT certificate", "VERIFIED" if mi["certificate"]["drat_check"].get("verified") else "not verified"]]}

rows = []
for k, a in R["adaptive"].items():
    qr = a["qmed_rule"]
    rows.append([k, f"{a['bundle']['campaign_class']} (conf {a['bundle']['confidence']})",
                 "—" if a["bundle"]["rho_pi"] is None else str(a["bundle"]["rho_pi"]),
                 f1(a["deployed_r_min_updated"]), f1(a["r_star_updated"]), a["decision"],
                 f1(a["new_r_min"]), f1(a["new_Qmed"]),
                 "pass" if a["audit"] == "all hard constraints pass" else str(a["audit"]),
                 "VERIFIED" if a["certificate"]["drat_check"].get("verified") else "not verified", a["gate"],
                 f"{f1(qr['Qmed_old_updated'])} → {f1(qr['Qmed_new_updated'])} ({qr['dQ_pct']:+.1f}%)",
                 f"{f1(qr['r_min_old_updated'])} → {f1(qr['r_min_new_updated'])}"])
T["adaptive"] = {"title": "Table R6. Algorithm 1 (deployed = max-min schedule; KEEP iff it is feasible and attains r*′ on the updated inputs). Last two columns: earlier Q-med acceptance rule on the Q-med schedule, for comparison",
                 "header": ["Bundle", "Campaign", "Updated ρ_π", "Deployed worst-case (updated inputs)", "r*′ (updated instance)", "Decision",
                            "New worst-case", "New Q-med", "Audit", "Certificate", "Gate", "Q-med rule: Q-med old → new", "Q-med rule: worst-case old → new"],
                 "rows": rows}

w = R["weights"]
T["weights"] = {"title": "Table R7. Do the fixed weights enforce strict tier priority? (θ_med coefficients)",
                "header": ["Condition", "Holds?", "Numbers"],
                "rows": [["L4 unit > max(L3+L2+L1)", str(w["dominance_holds"]["L4>L3+L2+L1"]), f"{f1(w['tier_min_unit_int']['L4']/100)} vs {f1((w['tier_totals_int']['L3']+w['tier_totals_int']['L2']+w['tier_totals_int']['L1'])/100)}"],
                         ["L3 unit > max(L2+L1)", str(w["dominance_holds"]["L3>L2+L1"]), f"{f1(w['tier_min_unit_int']['L3']/100)} vs {f1((w['tier_totals_int']['L2']+w['tier_totals_int']['L1'])/100)}"],
                         ["L2 unit > max(L1)", str(w["dominance_holds"]["L2>L1"]), f"{f1(w['tier_min_unit_int']['L2']/100)} vs {f1(w['tier_totals_int']['L1']/100)}"],
                         ["Weighted pass = lexicographic optimum on this instance", str(w["weighted_equals_lex"]), "tiers " + " / ".join(f1(v/100) for v in w["weighted_pass_tiers_int"].values())]]}

z = R["zero_burn"]
T["zeroburn"] = {"title": "Table R8. Is zero burn achievable? (exact CP-SAT feasibility)",
                 "header": ["Requirement", "Result"],
                 "rows": [["No burned deployment under all four profiles (C8 churn ≤ 2)", "INFEASIBLE" if z["all_profiles"] == "INFEASIBLE" else f1(z["all_profiles_r_int"] / 100)],
                          ["No burned deployment under θ_low and θ_med only: best worst-case", f1(z["low_med_only_r_int"] / 100)],
                          ["Churn relaxed to ≤ 3, zero burn all profiles: best worst-case", f1(z["churn3_all_profiles_r_int"] / 100)],
                          ["Churn relaxed to ≤ 3, burn allowed: r*", f1(z["churn3_unconstrained_r_int"] / 100)]]}

s = R["sensitivity"]
rows = [[r["param"], f"×{r['factor']}" if r["param"] != "q_Finance" else f"q(Finance)={r['factor']}", f1(r["r_star"]),
         f1(r.get("base_schedule_r", 0)), f"{r.get('base_schedule_regret_pct', 0):.2f}%", f1(r["Qmed_lex"]), "yes" if r["lex_schedule_changed"] else "no"] for r in s["runs"]]
T["sensitivity"] = {"title": f"Table R9. Sensitivity (solver re-run per case). Base r* = {f1(s['base_r_star'])}, base tier-lex Q-med = {f1(s['base_Qmed_lex'])}",
                    "header": ["Parameter", "Change", "New r*", "Original r* schedule re-scored", "Regret of original schedule", "New tier-lex Q-med", "Q-med schedule changed"],
                    "rows": rows}

rows = []
for mname in ["RC2 max-min (r*)", "RC2 tier-lex Q-med"]:
    m = next(x for x in R["methods"] if x["method"] == mname)
    for d in m["schedule"]:
        rows.append([mname, d[0], d[1], str(d[2]), d[3], R["instance"]["fingerprints"][d[3]]])
T["schedules"] = {"title": "Table R10. RC2 schedules (type, zone, slot, role, fingerprint)", "header": ["Schedule", "Type", "Zone", "Slot", "Role", "Fingerprint"], "rows": rows}

json.dump(T, open("out/tables.json", "w"), indent=1, ensure_ascii=False)
with open("out/tables.md", "w") as fh:
    fh.write(f"# ZSTP rerun tables\n\nGenerated from out/results.json (code {R['meta']['code_hash']}, instance {R['instance']['hash']}).\n\n")
    for k, t in T.items():
        fh.write(f"## {t['title']}\n\n| " + " | ".join(t["header"]) + " |\n|" + "---|" * len(t["header"]) + "\n")
        for r in t["rows"]:
            fh.write("| " + " | ".join(r) + " |\n")
        fh.write("\n")
        with open(f"out/table_{k}.csv", "w", newline="") as c:
            wr = csv.writer(c); wr.writerow(t["header"]); wr.writerows(t["rows"])
print("tables written:", list(T))
