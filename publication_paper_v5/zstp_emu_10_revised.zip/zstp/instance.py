"""ZSTP instance construction.

Every value used anywhere in the pipeline comes from an instance dict built here and
saved to JSON. Values the papers state are used as stated; values the papers do not
state (technique map, attack-path hops, GK tables, path emphasis per profile) are
documented defaults, marked DEFAULT below.
"""
import json, math, hashlib

TAU_D0 = 3        # paper: tau_d0 = 3
TAU_DP0 = 4       # paper (Algorithm 1, step 2): tau_dp0 = 4
RHO_MAX = 1.0     # chosen so floor(3*(1-rho)) reproduces Table 3: (2,2,1,1)


def tau_rule(base, rho):
    """U11 rule: floor, clamp at 1."""
    return max(1, math.floor(base * (1.0 - rho / RHO_MAX) + 1e-9))


TECHNIQUES = {  # id: (tactic family, W_j = base*(1+sigma))   DEFAULT weights
    "T1190": ("initial_access", 1.2), "T1133": ("initial_access", 1.3),
    "T1110": ("credential_access", 1.4), "T1003": ("credential_access", 1.8), "T1558": ("credential_access", 1.7),
    "T1046": ("discovery", 1.0), "T1087": ("discovery", 1.1), "T1018": ("discovery", 1.0),
    "T1021": ("lateral_movement", 1.6), "T1210": ("lateral_movement", 1.7), "T1570": ("lateral_movement", 1.5),
    "T1005": ("collection", 1.4), "T1213": ("collection", 1.5),
    "T1071": ("command_and_control", 1.3), "T1572": ("command_and_control", 1.8),
    "T1048": ("exfiltration", 1.6),
    "T0855": ("ics_impact", 2.0), "T0886": ("ics_impact", 1.9),
}

TRAP_TECHNIQUES = {  # DEFAULT
    "ssh_trap": ["T1110", "T1021", "T1133", "T1570"],
    "db_trap": ["T1213", "T1005", "T1003"],
    "web_trap": ["T1190", "T1071", "T1046"],
    "dns_trap": ["T1572", "T1048", "T1018"],
    "smb_trap": ["T1021", "T1210", "T1570", "T1087"],
    "rdp_trap": ["T1133", "T1021", "T1558"],
    "ot_trap": ["T0855", "T0886", "T1046"],
    "generic_trap": ["T1046", "T1018", "T1087"],
}

ZONES = ["DMZ", "Internal", "Cloud", "OT", "Mgmt"]
TYPE_ZONE_OK = {  # DEFAULT G_K type-zone plausibility (C5b part 1)
    "DMZ": ["web_trap", "ssh_trap", "dns_trap", "rdp_trap", "generic_trap"],
    "Internal": ["db_trap", "smb_trap", "ssh_trap", "rdp_trap", "generic_trap", "web_trap"],
    "Cloud": ["web_trap", "db_trap", "ssh_trap", "dns_trap"],
    "OT": ["ot_trap", "generic_trap"],
    "Mgmt": ["ssh_trap", "rdp_trap", "dns_trap", "generic_trap"],
}
# Roles as listed in the papers; one concrete fingerprint bundle per role (|F| = 4).
ROLES = {  # role: (fingerprint id, plausible types, plausible zones)   DEFAULT tables
    "HR_Workstation": ("fp1", ["smb_trap", "rdp_trap", "web_trap", "generic_trap"], ["Internal", "Cloud"]),
    "DevOps_JumpHost": ("fp2", ["ssh_trap", "rdp_trap", "dns_trap", "web_trap", "generic_trap"], ["DMZ", "Internal", "Mgmt", "Cloud"]),
    "Finance_DB_Server": ("fp3", ["db_trap", "smb_trap", "web_trap"], ["Internal", "Cloud"]),
    "Generic_Linux": ("fp4", ["ssh_trap", "dns_trap", "ot_trap", "generic_trap", "web_trap", "db_trap"], ZONES),
}
AIR_GAPPED = ["OT"]  # C5: IT-crossing types forbidden in the air-gapped zone
AIR_GAP_CROSSING_TYPES = ["web_trap", "smb_trap", "rdp_trap", "dns_trap", "db_trap", "ssh_trap"]
CONFLICTS = [["dns_trap", "generic_trap"], ["web_trap", "generic_trap"]]  # C4 (paper: dns+generic)

# Attack paths: hops (zone, technique, iv). Last hop = target. rho = path frequency.
PATHS = {  # DEFAULT hops; rho values from the papers' force-multiplier table where given
    "web_to_db": {"rho": 0.30, "critical": 1, "hops": [["DMZ", "T1190", 1.0], ["Internal", "T1021", 1.8], ["Internal", "T1213", 2.0]]},
    "ot_infiltration": {"rho": 0.15, "critical": 2, "hops": [["DMZ", "T1133", 1.0], ["Mgmt", "T1021", 1.4], ["OT", "T0886", 1.7], ["OT", "T0855", 2.0]]},
    "brute_to_ad": {"rho": 0.20, "critical": 1, "hops": [["DMZ", "T1110", 1.0], ["Internal", "T1558", 1.6], ["Internal", "T1003", 1.9]]},
    "cloud_exfil": {"rho": 0.25, "critical": 1, "hops": [["Cloud", "T1190", 1.0], ["Cloud", "T1005", 1.3], ["Cloud", "T1048", 1.5]]},
}

PROFILES = {  # rho_theta from the papers; path emphasis omega is DEFAULT
    "low": {"rho": 0.10, "omega": {"web_to_db": 1.0, "ot_infiltration": 0.2, "brute_to_ad": 0.6, "cloud_exfil": 1.0}},
    "med": {"rho": 0.30, "omega": {"web_to_db": 1.0, "ot_infiltration": 1.0, "brute_to_ad": 1.0, "cloud_exfil": 1.0}},
    "high": {"rho": 0.60, "omega": {"web_to_db": 0.8, "ot_infiltration": 0.6, "brute_to_ad": 1.4, "cloud_exfil": 0.8}},
    "burst": {"rho": 0.85, "omega": {"web_to_db": 0.6, "ot_infiltration": 2.0, "brute_to_ad": 1.0, "cloud_exfil": 0.6}},
}

LAYER_W = {"L4": 1000, "L3_fwd": 100, "L3_bwd": 70, "L2_tech": 10, "L2_fam": 12, "L1": 1}
SCALE = 100  # all coefficients multiplied by SCALE and rounded -> integers (reported Q = int / SCALE)


def build_xlarge(q=None, path_rho_override=None, perturb=None):
    types = list(TRAP_TECHNIQUES)
    roles = list(ROLES)
    inst = {
        "name": "XLarge",
        "K": types, "Z": list(ZONES), "H": 4, "P": roles,
        "fingerprint": {r: ROLES[r][0] for r in roles},
        "techniques": {j: {"family": f, "W": w} for j, (f, w) in TECHNIQUES.items()},
        "trap_techniques": TRAP_TECHNIQUES,
        "type_zone_ok": TYPE_ZONE_OK,
        "role_types": {r: ROLES[r][1] for r in roles},
        "role_zones": {r: ROLES[r][2] for r in roles},
        "air_gapped": AIR_GAPPED, "air_gap_crossing_types": AIR_GAP_CROSSING_TYPES,
        "conflicts": CONFLICTS,
        "B_t": 4, "B_z": 2, "churn_max": 2, "W_gap": 2,
        "kappa": [8, 8, 8, 8], "kappa_min": 2,
        "paths": json.loads(json.dumps(PATHS)),
        "profiles": json.loads(json.dumps(PROFILES)),
        "q": q or {r: 0.25 for r in roles},
        "layer_w": LAYER_W, "scale": SCALE,
        "tau_d0": TAU_D0, "tau_dp0": TAU_DP0, "rho_max": RHO_MAX,
    }
    if path_rho_override:
        for p, v in path_rho_override.items():
            inst["paths"][p]["rho"] = v
    for k, f in (perturb or {}).items():  # sensitivity analysis hooks
        if k == "rho":
            for p in inst["paths"].values():
                p["rho"] = round(p["rho"] * f, 4)
        elif k == "iv":
            for p in inst["paths"].values():
                p["hops"] = [[z, j, round(iv * f, 4)] for z, j, iv in p["hops"]]
        elif k == "W":
            inst["techniques"] = {j: {**v, "W": round(v["W"] * f, 4)} for j, v in inst["techniques"].items()}
        elif k == "L4":
            inst["layer_w"] = {**inst["layer_w"], "L4": inst["layer_w"]["L4"] * f}
        elif k == "q_Finance":
            raw = {r: (f if r == "Finance_DB_Server" else (1 - f) / (len(inst["P"]) - 1)) for r in inst["P"]}
            inst["q"] = raw
    return finalize(inst)


def build_micro():
    inst = {
        "name": "Micro",
        "K": ["ssh_trap", "web_trap", "db_trap"], "Z": ["DMZ", "Internal"], "H": 3,
        "P": ["DevOps_JumpHost", "Finance_DB_Server"],
        "fingerprint": {"DevOps_JumpHost": "fp2", "Finance_DB_Server": "fp3"},
        "techniques": {j: {"family": TECHNIQUES[j][0], "W": TECHNIQUES[j][1]} for j in
                       ["T1190", "T1071", "T1046", "T1110", "T1021", "T1133", "T1570", "T1213", "T1005", "T1003"]},
        "trap_techniques": {k: TRAP_TECHNIQUES[k] for k in ["ssh_trap", "web_trap", "db_trap"]},
        "type_zone_ok": {"DMZ": ["web_trap", "ssh_trap"], "Internal": ["db_trap", "ssh_trap", "web_trap"]},
        "role_types": {"DevOps_JumpHost": ["ssh_trap", "web_trap"], "Finance_DB_Server": ["db_trap", "web_trap"]},
        "role_zones": {"DevOps_JumpHost": ["DMZ", "Internal"], "Finance_DB_Server": ["Internal"]},
        "air_gapped": [], "air_gap_crossing_types": [],
        "conflicts": [],
        "B_t": 2, "B_z": 1, "churn_max": 2, "W_gap": 2,
        "kappa": [8, 8, 8], "kappa_min": 2,
        "paths": {"web_to_db": {"rho": 0.30, "critical": 1,
                                "hops": [["DMZ", "T1190", 1.0], ["Internal", "T1021", 1.8], ["Internal", "T1213", 2.0]]}},
        "profiles": {k: {"rho": v["rho"], "omega": {"web_to_db": 1.0}} for k, v in PROFILES.items()},
        "q": {"DevOps_JumpHost": 0.5, "Finance_DB_Server": 0.5},
        "layer_w": LAYER_W, "scale": SCALE,
        "tau_d0": TAU_D0, "tau_dp0": TAU_DP0, "rho_max": RHO_MAX,
    }
    return finalize(inst)


def finalize(inst):
    """Derive thresholds (U11) and integer coefficients. Pure function of the instance."""
    Z, H = inst["Z"], inst["H"]
    # U11: effective rho at zone z under profile = max(profile rho, max rho of paths through z)
    zone_path_rho = {z: 0.0 for z in Z}
    for p in inst["paths"].values():
        for z, _, _ in p["hops"]:
            zone_path_rho[z] = max(zone_path_rho[z], p["rho"])
    tau_d, tau_dp = {}, {}
    for th, pr in inst["profiles"].items():
        tau_d[th] = {z: tau_rule(inst["tau_d0"], max(pr["rho"], zone_path_rho[z])) for z in Z}
        tau_dp[th] = tau_rule(inst["tau_dp0"], pr["rho"])
    inst["tau_d"], inst["tau_dp"] = tau_d, tau_dp
    # F15 slot validity
    inst["slot_valid"] = [inst["kappa"][t] >= inst["kappa_min"] for t in range(H)]
    # integer coefficients per profile
    S, LW = inst["scale"], inst["layer_w"]
    Wt = {j: v["W"] for j, v in inst["techniques"].items()}
    coef = {}
    for th, pr in inst["profiles"].items():
        c = {"L4": {}, "L3": {}, "L2_tech": {}, "L2_fam": {}, "L1": {}}
        for pn, p in inst["paths"].items():
            om = pr["omega"][pn]
            hops = p["hops"]
            max_iv = max(h[2] for h in hops[:-1])
            wbar = sum(Wt[h[1]] for h in hops) / len(hops)
            for t in range(H):
                c["L4"][f"{pn}|{t}"] = round(S * LW["L4"] * p["rho"] * om * max_iv * wbar)
                for hi, (z, j, iv) in enumerate(hops):
                    c["L3"][f"{pn}|{hi}|{t}"] = round(S * (LW["L3_fwd"] + LW["L3_bwd"]) * p["rho"] * om * iv * Wt[j])
        for j in inst["techniques"]:
            c["L2_tech"][j] = round(S * LW["L2_tech"] * Wt[j])
        fams = sorted({v["family"] for v in inst["techniques"].values()})
        for f in fams:
            c["L2_fam"][f] = round(S * LW["L2_fam"] * sum(Wt[j] for j in inst["techniques"] if inst["techniques"][j]["family"] == f))
        for i in inst["K"]:
            tj = [j for j in inst["trap_techniques"][i] if j in Wt]
            wi = sum(Wt[j] for j in tj) / len(tj)
            for r in inst["P"]:
                c["L1"][f"{i}|{r}"] = round(S * LW["L1"] * wi * inst["q"][r] * 4)  # x4 so q=0.25 -> 1.0
        coef[th] = c
    inst["coef"] = coef
    inst["families"] = sorted({v["family"] for v in inst["techniques"].values()})
    body = json.dumps({k: v for k, v in inst.items() if k != "hash"}, sort_keys=True)
    inst["hash"] = hashlib.sha256(body.encode()).hexdigest()[:12]
    return inst


def detects(inst, i, j):
    return j in inst["trap_techniques"][i]


if __name__ == "__main__":
    x = build_xlarge()
    print(x["hash"], x["tau_d"], x["tau_dp"])
    m = build_micro()
    print(m["hash"], m["tau_d"], m["tau_dp"])
