"""Common evaluator and independent hard-constraint checker.

Pure Python, written directly from the model definitions; it never calls a solver and
never reads encoder variables. Every method's schedule (RC2 or baseline) is scored here.

Schedule = collection of deployments (type i, zone z, slot t, role r); the role's
fingerprint is inst['fingerprint'][r].

Burn convention (observe-then-burn): within slot t the attacker observes, credit is
computed from burn state fixed at the START of t, then counters update.
  type burn   u[i,z,t] = 1  iff t >= tau and (i,z) was present in every slot t-tau .. t-1
  persona burn v[f,t]  = 1  iff t >= tau_p and f was used in every slot t-tau_p .. t-1
  credit      d = x and not u and not v   (every layer, incl. L2_fam, is gated on d)
"""
import math
from collections import defaultdict


def norm(schedule):
    return sorted({tuple(s) for s in schedule})


def burn_state(inst, sched, th):
    H = inst["H"]
    present = defaultdict(bool); used = defaultdict(bool)
    fp = inst["fingerprint"]
    for i, z, t, r in sched:
        present[(i, z, t)] = True
        used[(fp[r], t)] = True
    tp = inst["tau_dp"][th]
    u, v = {}, {}
    for i, z, t, r in sched:
        td = inst["tau_d"][th][z]
        u[(i, z, t)] = t >= td and all(present[(i, z, s)] for s in range(t - td, t))
        f = fp[r]
        v[(f, t)] = t >= tp and all(used[(f, s)] for s in range(t - tp, t))
    return u, v


def evaluate(inst, schedule, th):
    sched = norm(schedule)
    fp = inst["fingerprint"]
    c = inst["coef"][th]
    u, v = burn_state(inst, sched, th)
    live = [(i, z, t, r) for (i, z, t, r) in sched if not u[(i, z, t)] and not v[(fp[r], t)]]
    live_set = set(live)
    # coverage c[pi,h,t] and interception e[pi,t]
    cov = set()
    for pn, p in inst["paths"].items():
        for hi, (hz, hj, _) in enumerate(p["hops"]):
            for (i, z, t, r) in live:
                if z == hz and hj in inst["trap_techniques"][i]:
                    cov.add((pn, hi, t))
    L4 = L3 = 0
    ecount = 0
    for pn, p in inst["paths"].items():
        n = len(p["hops"])
        for t in range(inst["H"]):
            if any((pn, hi, t) in cov for hi in range(n - 1)):
                L4 += c["L4"][f"{pn}|{t}"]; ecount += 1
            for hi in range(n):
                if (pn, hi, t) in cov:
                    L3 += c["L3"][f"{pn}|{hi}|{t}"]
    techs = {j for (i, z, t, r) in live for j in inst["trap_techniques"][i] if j in inst["techniques"]}
    fams = {inst["techniques"][j]["family"] for j in techs}
    L2t = sum(c["L2_tech"][j] for j in techs)
    L2f = sum(c["L2_fam"][f] for f in fams)
    L1 = sum(c["L1"][f"{i}|{r}"] for (i, z, t, r) in live)
    Q = L4 + L3 + L2t + L2f + L1
    anyb = sum(1 for (i, z, t, r) in sched if u[(i, z, t)] or v[(fp[r], t)])
    tb = sum(1 for (i, z, t, r) in sched if u[(i, z, t)])
    pb = sum(1 for (i, z, t, r) in sched if v[(fp[r], t)])
    n = len(sched)
    n_e = sum(inst["H"] for _ in inst["paths"])
    n_h = sum(len(p["hops"]) * inst["H"] for p in inst["paths"].values())
    # force multiplier: per live deployment, total L3 over (path,hop) it covers / max single one
    fms = []
    for (i, z, t, r) in sched:
        vals = [c["L3"][f"{pn}|{hi}|{t}"] for pn, p in inst["paths"].items()
                for hi, (hz, hj, _) in enumerate(p["hops"]) if hz == z and hj in inst["trap_techniques"][i]]
        if not vals:
            fms.append(0.0)
        else:
            fms.append((sum(vals) / max(vals)) if (i, z, t, r) in live_set else 0.0)
    S = inst["scale"]
    return {
        "Q": Q / S,
        "layers": {"L4": L4 / S, "L3": L3 / S, "L2_tech": L2t / S, "L2_fam": L2f / S, "L1": L1 / S},
        "Q_int": Q, "layers_int": {"L4": L4, "L3": L3, "L2": L2t + L2f, "L1": L1},
        "deployments": n, "type_burned": tb, "persona_burned": pb, "burned_any": anyb,
        "Burn_any_pct": 100.0 * anyb / n if n else 0.0,
        "TBurn_pct": 100.0 * tb / n if n else 0.0, "PBurn_pct": 100.0 * pb / n if n else 0.0,
        "techniques": len(techs), "families": len(fams),
        "early_intercept_pct": 100.0 * ecount / n_e,
        "hop_coverage_pct": 100.0 * len(cov) / n_h,
        "FM_avg": sum(fms) / len(fms) if fms else 0.0,
    }


def evaluate_all(inst, schedule):
    res = {th: evaluate(inst, schedule, th) for th in inst["profiles"]}
    worst = min(res, key=lambda th: res[th]["Q_int"])
    return {"per_profile": res, "r_min": res[worst]["Q"], "r_min_int": res[worst]["Q_int"], "worst_profile": worst}


def static_metrics(inst, schedule):
    """Profile-independent metrics (C10 persistence, zone spread, persona diversity, C14 leaks)."""
    sched = norm(schedule)
    H = inst["H"]
    pers = []
    for pn, p in inst["paths"].items():
        hz, hj, _ = p["hops"][p["critical"]]
        covered = [any(z == hz and hj in inst["trap_techniques"][i] for (i, z, tt, r) in sched if tt == t) for t in range(H)]
        need = math.ceil(p["rho"] * H)
        gap_ok = all(any(covered[s] for s in range(t, t + inst["W_gap"])) for t in range(H - inst["W_gap"] + 1))
        pers.append(sum(covered) >= need and gap_ok)
    zones = {z for (i, z, t, r) in sched}
    roles = {r for (i, z, t, r) in sched}
    leaks = 0
    fp = inst["fingerprint"]
    for t in range(H):
        byf = defaultdict(set)
        for (i, z, tt, r) in sched:
            if tt == t:
                byf[fp[r]].add(z)
        leaks += sum(len(zs) - 1 for zs in byf.values() if len(zs) > 1)
    return {"path_persistence_pct": 100.0 * sum(pers) / len(pers),
            "zone_spread_pct": 100.0 * len(zones) / len(inst["Z"]),
            "persona_diversity_pct": 100.0 * len(roles) / len(inst["P"]),
            "C14_leaks": leaks}


def check(inst, schedule):
    """Independent hard-constraint checker. Returns {constraint: [violation descriptions]}."""
    sched = norm(schedule)
    H, fp = inst["H"], inst["fingerprint"]
    V = defaultdict(list)
    per_t = defaultdict(int); per_zt = defaultdict(int)
    for (i, z, t, r) in sched:
        if not inst["slot_valid"][t]:
            V["F15"].append(f"slot {t} invalid")
        per_t[t] += 1; per_zt[(z, t)] += 1
        if z in inst["air_gapped"] and i in inst["air_gap_crossing_types"]:
            V["C5"].append(f"{i}@{z}/t{t}")
        ok = (i in inst["type_zone_ok"].get(z, [])) and (i in inst["role_types"][r]) and (z in inst["role_zones"][r])
        if not ok:
            V["C5b"].append(f"{i}@{z}/t{t} as {r}")
    for t, n in per_t.items():
        if n > inst["B_t"]:
            V["C2"].append(f"t{t}: {n}>{inst['B_t']}")
    for (z, t), n in per_zt.items():
        if n > inst["B_z"]:
            V["C3"].append(f"{z}/t{t}: {n}>{inst['B_z']}")
    S = set(sched)
    for a, b in inst["conflicts"]:
        for z in inst["Z"]:
            for t in range(H):
                if any((a, z, t, r) in S for r in inst["P"]) and any((b, z, t, r) in S for r in inst["P"]):
                    V["C4"].append(f"{a}+{b}@{z}/t{t}")
    # C8 churn per (i,z,r)
    for i in inst["K"]:
        for z in inst["Z"]:
            for r in inst["P"]:
                seq = [(i, z, t, r) in S for t in range(H)]
                ch = sum(1 for t in range(1, H) if seq[t] != seq[t - 1])
                if ch > inst["churn_max"]:
                    V["C8"].append(f"{i}@{z} as {r}: {ch} changes")
    # C10a / C10b on critical hops (deployment presence, not burn-gated)
    for pn, p in inst["paths"].items():
        hz, hj, _ = p["hops"][p["critical"]]
        cov = [any(z == hz and hj in inst["trap_techniques"][i] for (i, z, tt, r) in sched if tt == t) for t in range(H)]
        need = math.ceil(p["rho"] * H)
        if sum(cov) < need:
            V["C10a"].append(f"{pn}: {sum(cov)}<{need}")
        for t in range(H - inst["W_gap"] + 1):
            if not any(cov[s] for s in range(t, t + inst["W_gap"])):
                V["C10b"].append(f"{pn}: gap at t{t}..t{t + inst['W_gap'] - 1}")
    # C12 fingerprint unique per (z,t); C14 fingerprint unique per t across zones
    for t in range(H):
        byzf = defaultdict(int); byf = defaultdict(set); byf_n = defaultdict(int)
        for (i, z, tt, r) in sched:
            if tt == t:
                byzf[(z, fp[r])] += 1; byf[fp[r]].add(z); byf_n[fp[r]] += 1
        for (z, f), n in byzf.items():
            if n > 1:
                V["C12"].append(f"{f}@{z}/t{t} x{n}")
        for f, zs in byf.items():
            if len(zs) > 1:
                V["C14"].append(f"{f} in {sorted(zs)} at t{t}")
    return dict(V)


CONSTRAINTS = ["C2", "C3", "C4", "C5", "C5b", "C8", "C10a", "C10b", "C12", "C14", "F15"]
