"""WCNF encoding of ZSTP (hard layer + per-profile objective indicators).

Every auxiliary variable is defined by a full equivalence, so for any assignment to x the
auxiliaries are forced to the values the evaluator computes. Scenario-specific burn state is
represented by a separate copy of u, v, d, cov, e, g, fam for every profile theta.

Auxiliary variables (per profile theta unless noted):
  present[i,z,t]   (shared)  <-> OR_r x[i,z,t,r]
  used[f,t]        (shared)  <-> OR_{i,z} x[i,z,t,r(f)]
  u[i,z,t]   type burn       <-> AND_{s=t-tau_d..t-1} present[i,z,s]     (only if t >= tau_d)
  v[f,t]     persona burn    <-> AND_{s=t-tau_p..t-1} used[f,s]           (only if t >= tau_p)
  d[i,z,t,r] live deployment <-> x & ~u & ~v
  cov[pi,h,t]                <-> OR_{i detects hop tech, r} d[i,z_h,t,r]
  e[pi,t]    interception    <-> OR_{h non-final} cov[pi,h,t]
  g[j]       technique       <-> OR_{i detects j, z,t,r} d
  fam[phi]   tactic family   <-> OR_{j in phi} g[j]
  ch[i,z,r,t] churn (shared) <-> x[.,t] XOR x[.,t-1]
  y[pi,t]    critical-hop presence (shared, for C10a/b) <-> OR x at critical hop
"""
import math
from pysat.formula import IDPool, WCNF, CNF
from pysat.card import CardEnc, EncType

TRUE, FALSE = True, False


class Enc:
    def __init__(self, inst):
        self.inst = inst
        self.pool = IDPool()
        self.hard = []
        self.terms = {}  # theta -> list of (layer, coef, lit)
        self._build()

    # ---------- helpers ----------
    def v(self, *key):
        return self.pool.id(key)

    def fresh(self, tag):
        self._n = getattr(self, "_n", 0) + 1
        return self.pool.id(("aux", tag, self._n))

    def OR(self, key, lits):
        lits = [l for l in lits if l is not FALSE]
        if any(l is TRUE for l in lits):
            return TRUE
        if not lits:
            return FALSE
        if len(lits) == 1:
            return lits[0]
        o = self.v(*key)
        self.hard.append([-o] + lits)
        for l in lits:
            self.hard.append([o, -l])
        return o

    def AND(self, key, lits):
        lits = [l for l in lits if l is not TRUE]
        if any(l is FALSE for l in lits):
            return FALSE
        if not lits:
            return TRUE
        if len(lits) == 1:
            return lits[0]
        o = self.v(*key)
        self.hard.append([o] + [-l for l in lits])
        for l in lits:
            self.hard.append([-o, l])
        return o

    @staticmethod
    def NEG(l):
        if l is TRUE:
            return FALSE
        if l is FALSE:
            return TRUE
        return -l

    def atmost(self, lits, k):
        lits = [l for l in lits if l is not FALSE]
        if len(lits) <= k:
            return
        enc = CardEnc.atmost(lits=lits, bound=k, vpool=self.pool, encoding=EncType.seqcounter)
        self.hard.extend(enc.clauses)

    def atleast(self, lits, k):
        lits = [l for l in lits if l is not FALSE]
        if k <= 0:
            return
        enc = CardEnc.atleast(lits=lits, bound=k, vpool=self.pool, encoding=EncType.seqcounter)
        self.hard.extend(enc.clauses)

    # ---------- model ----------
    def _build(self):
        I = self.inst
        K, Z, H, P = I["K"], I["Z"], I["H"], I["P"]
        fp = I["fingerprint"]
        X = {}
        for i in K:
            for z in Z:
                for t in range(H):
                    for r in P:
                        X[(i, z, t, r)] = self.v("x", i, z, t, r)
        self.X = X
        # F15 (pre-filter): invalid slots disabled
        for (i, z, t, r), x in X.items():
            if not I["slot_valid"][t]:
                self.hard.append([-x])
        # C5 air-gap, C5b plausibility (unit clauses)
        for (i, z, t, r), x in X.items():
            if z in I["air_gapped"] and i in I["air_gap_crossing_types"]:
                self.hard.append([-x])
            elif not (i in I["type_zone_ok"].get(z, []) and i in I["role_types"][r] and z in I["role_zones"][r]):
                self.hard.append([-x])
        # C2, C3
        for t in range(H):
            self.atmost([X[(i, z, t, r)] for i in K for z in Z for r in P], I["B_t"])
            for z in Z:
                self.atmost([X[(i, z, t, r)] for i in K for r in P], I["B_z"])
        # presence / usage
        pres = {(i, z, t): self.OR(("pres", i, z, t), [X[(i, z, t, r)] for r in P]) for i in K for z in Z for t in range(H)}
        fps = sorted(set(fp.values()))
        used = {(f, t): self.OR(("used", f, t), [X[(i, z, t, r)] for i in K for z in Z for r in P if fp[r] == f])
                for f in fps for t in range(H)}
        # C4 conflicts
        for a, b in I["conflicts"]:
            for z in Z:
                for t in range(H):
                    pa, pb = pres[(a, z, t)], pres[(b, z, t)]
                    if pa is not FALSE and pb is not FALSE:
                        self.hard.append([-pa, -pb])
        # C8 churn
        for i in K:
            for z in Z:
                for r in P:
                    chs = []
                    for t in range(1, H):
                        a, b = X[(i, z, t, r)], X[(i, z, t - 1, r)]
                        c = self.v("ch", i, z, r, t)
                        self.hard += [[-c, a, b], [-c, -a, -b], [c, -a, b], [c, a, -b]]
                        chs.append(c)
                    self.atmost(chs, I["churn_max"])
        # C10a / C10b on critical hop presence
        for pn, p in I["paths"].items():
            hz, hj, _ = p["hops"][p["critical"]]
            y = [self.OR(("y", pn, t), [X[(i, hz, t, r)] for i in K for r in P if hj in I["trap_techniques"][i]]) for t in range(H)]
            self.atleast(y, math.ceil(p["rho"] * H))
            W = I["W_gap"]
            for t in range(H - W + 1):
                win = [y[s] for s in range(t, t + W)]
                self.hard.append([l for l in win if l is not FALSE])
        # C12 / C14 fingerprint uniqueness
        for t in range(H):
            for f in fps:
                self.atmost([X[(i, z, t, r)] for i in K for z in Z for r in P if fp[r] == f], 1)
                for z in Z:
                    self.atmost([X[(i, z, t, r)] for i in K for r in P if fp[r] == f], 1)
        # objective indicators per profile
        for th in I["profiles"]:
            c = I["coef"][th]
            u = {}
            for i in K:
                for z in Z:
                    td = I["tau_d"][th][z]
                    for t in range(H):
                        u[(i, z, t)] = FALSE if t < td else self.AND(("u", th, i, z, t), [pres[(i, z, s)] for s in range(t - td, t)])
            tp = I["tau_dp"][th]
            vv = {}
            for f in fps:
                for t in range(H):
                    vv[(f, t)] = FALSE if t < tp else self.AND(("v", th, f, t), [used[(f, s)] for s in range(t - tp, t)])
            d = {}
            for (i, z, t, r), x in X.items():
                d[(i, z, t, r)] = self.AND(("d", th, i, z, t, r), [x, self.NEG(u[(i, z, t)]), self.NEG(vv[(fp[r], t)])])
            terms = []
            for pn, p in I["paths"].items():
                n = len(p["hops"])
                for t in range(H):
                    covs = []
                    for hi, (hz, hj, _) in enumerate(p["hops"]):
                        cv = self.OR(("cov", th, pn, hi, t), [d[(i, hz, t, r)] for i in K for r in P if hj in I["trap_techniques"][i]])
                        covs.append(cv)
                        if cv is not FALSE:
                            terms.append(("L3", c["L3"][f"{pn}|{hi}|{t}"], cv))
                    e = self.OR(("e", th, pn, t), covs[:n - 1])
                    if e is not FALSE:
                        terms.append(("L4", c["L4"][f"{pn}|{t}"], e))
            g = {}
            for j in I["techniques"]:
                g[j] = self.OR(("g", th, j), [d[(i, z, t, r)] for (i, z, t, r) in X if j in I["trap_techniques"][i]])
                if g[j] is not FALSE:
                    terms.append(("L2", c["L2_tech"][j], g[j]))
            for fam in I["families"]:
                fv = self.OR(("fam", th, fam), [g[j] for j in I["techniques"] if I["techniques"][j]["family"] == fam])
                if fv is not FALSE:
                    terms.append(("L2", c["L2_fam"][fam], fv))
            for (i, z, t, r), dl in d.items():
                if dl is not FALSE:
                    terms.append(("L1", c["L1"][f"{i}|{r}"], dl))
            self.terms[th] = terms

    def decode(self, model):
        s = set(l for l in model if l > 0)
        return sorted(k for k, x in self.X.items() if x in s)

    def stats(self):
        return {"primary_vars": len(self.X), "total_vars": self.pool.top, "hard_clauses": len(self.hard)}


# ---------- pseudo-Boolean  sum(w_i * l_i) >= T  via binary adders ----------
class PB:
    """Adder-network PB encoding with constant folding. sum() builds the binary sum once;
    geq(T) returns a literal equivalent to (sum >= T)."""

    def __init__(self, enc, terms, tag):
        self.enc, self.tag = enc, tag
        self.maxsum = sum(w for w, _ in terms)
        self.m = max(1, self.maxsum.bit_length())
        nums = []
        for w, l in terms:
            if w <= 0:
                continue
            nums.append([l if (w >> b) & 1 else FALSE for b in range(w.bit_length())])
        while len(nums) > 1:
            nxt = []
            for k in range(0, len(nums) - 1, 2):
                nxt.append(self.add(nums[k], nums[k + 1]))
            if len(nums) % 2:
                nxt.append(nums[-1])
            nums = nxt
        self.bits = nums[0] if nums else [FALSE]

    def xor3(self, a, b, c):
        lits = [a, b, c]
        consts = [l for l in lits if l is TRUE or l is FALSE]
        var = [l for l in lits if not (l is TRUE or l is FALSE)]
        parity = sum(1 for l in consts if l is TRUE) % 2
        if not var:
            return TRUE if parity else FALSE
        if len(var) == 1:
            return var[0] if parity == 0 else -var[0]
        o = self.enc.fresh(self.tag + "s")
        H = self.enc.hard
        if len(var) == 2:
            a, b = var
            if parity:  # o = ~(a xor b)
                H += [[-o, a, -b], [-o, -a, b], [o, a, b], [o, -a, -b]]
            else:
                H += [[-o, a, b], [-o, -a, -b], [o, -a, b], [o, a, -b]]
            return o
        a, b, c = var
        H += [[-o, a, b, c], [-o, -a, -b, c], [-o, -a, b, -c], [-o, a, -b, -c],
              [o, -a, b, c], [o, a, -b, c], [o, a, b, -c], [o, -a, -b, -c]]
        return o

    def maj(self, a, b, c):
        lits = [a, b, c]
        nt = sum(1 for l in lits if l is TRUE)
        var = [l for l in lits if not (l is TRUE or l is FALSE)]
        if nt >= 2:
            return TRUE
        if nt == 1:
            if len(var) == 2:
                return self.enc.OR(("aux", self.tag + "m", self._cnt()), var)
            return var[0] if var else FALSE
        # nt == 0
        if len(var) < 2:
            return FALSE
        if len(var) == 2:
            return self.enc.AND(("aux", self.tag + "a", self._cnt()), var)
        a, b, c = var
        o = self.enc.fresh(self.tag + "c")
        self.enc.hard += [[-o, a, b], [-o, a, c], [-o, b, c], [o, -a, -b], [o, -a, -c], [o, -b, -c]]
        return o

    def _cnt(self):
        self.enc._n = getattr(self.enc, "_n", 0) + 1
        return self.enc._n

    def add(self, A, B):
        n = max(len(A), len(B))
        A = A + [FALSE] * (n - len(A)); B = B + [FALSE] * (n - len(B))
        out, carry = [], FALSE
        for k in range(n):
            out.append(self.xor3(A[k], B[k], carry))
            carry = self.maj(A[k], B[k], carry)
        out.append(carry)
        while len(out) > 1 and out[-1] is FALSE:
            out.pop()
        return out

    def geq(self, T):
        """Literal (or constant) equivalent to sum >= T."""
        if T <= 0:
            return TRUE
        if T > self.maxsum:
            return FALSE
        m = max(len(self.bits), T.bit_length())
        base = 1 << m
        const = base - T  # sum + const >= base  <=>  sum >= T
        C = [TRUE if (const >> b) & 1 else FALSE for b in range(m)]
        s = self.add(self.bits + [FALSE] * (m - len(self.bits)), C)
        return s[m] if len(s) > m else FALSE
