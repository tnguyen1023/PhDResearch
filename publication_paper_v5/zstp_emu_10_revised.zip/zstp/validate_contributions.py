"""Validation of the emulation and of each contribution against the paper's definitions.
Reads out/results.json (and runs small solver instances); writes out/validation.json.

V1  Emulation semantics. An independent reference simulator, written from the stated attacker
    model (no sockets, no code shared with emulation_l2.py), replays every recorded stochastic
    episode from the same seeds and must reproduce the socket emulator's per-episode score exactly:
      per slot t, start: honeypot recognized iff its (type, zone) was observed in each of the
        previous tau_d(theta, z) slots, or its fingerprint in each of the previous tau_dp(theta) slots;
      recon: each zone z is probed with probability rho_theta; a probe observes every honeypot in z;
      attack: each path pi is traversed with probability min(1, rho_pi * omega_theta,pi); at every hop
        it contacts each unrecognized honeypot in the hop zone that detects the hop technique;
      credit: L4 if a non-final hop of pi is contacted in t, L3 per contacted hop, L2/L1 for every
        unrecognized honeypot contacted (probe or attack).
    Also checked: the attacker's draw frequencies against the stated probabilities (binomial z),
    and, in deterministic mode, that recognized honeypots = evaluator burn set and contacted hops =
    evaluator coverage, for every schedule and profile.
V2  STIX 2.1 bundles: required properties, unique ids, every sighting refers to an indicator.
V3  U11 thresholds and Algorithm 1 inputs/outputs against the values stated in the paper.
V4  Four-pass procedure: each pass optimum is kept as a floor in the final schedule, the final
    schedule is the lexicographic optimum (CP-SAT agrees), and the fixed weights alone do not
    enforce tier priority (so the passes are needed).
V5  NP-hardness reduction (Section 3.4): random Maximum k-Coverage instances are encoded as ZSTP
    instances exactly as described and solved; the optimum must equal brute-force maximum coverage.
V6  C10a / C10b split: the two rules are distinct (schedules breaking one but not the other exist).
"""
import json, math, random, hashlib, itertools, statistics, time
from collections import defaultdict
import instance, encoder, solvers, evaluator

R = json.load(open("out/results.json"))
INST = instance.build_xlarge()
V = {}


# ------------------------------------------------------------------ V1
def ref_episode(inst, sched, th, rnd, deterministic):
    fp = inst["fingerprint"]; c = inst["coef"][th]; prof = inst["profiles"][th]
    seen_tz, seen_fp = defaultdict(set), defaultdict(set)
    contacted_live, cov, recognized = set(), set(), set()
    draws = {"probe": [], "path": []}
    for t in range(inst["H"]):
        slot = [d for d in sched if d[2] == t]
        rec = {}
        for (i, z, tt, r) in slot:
            td, tp = inst["tau_d"][th][z], inst["tau_dp"][th]
            rec[(i, z, tt, r)] = (t >= td and all(s in seen_tz[(i, z)] for s in range(t - td, t))) or \
                                 (t >= tp and all(s in seen_fp[fp[r]] for s in range(t - tp, t)))
        for z in inst["Z"]:
            u = rnd.random()
            hit = deterministic or u < prof["rho"]
            draws["probe"].append(hit)
            if hit:
                for d in slot:
                    if d[1] == z:
                        seen_tz[(d[0], z)].add(t); seen_fp[fp[d[3]]].add(t)
                        (recognized if rec[d] else contacted_live).add(d)
        for pn, p in inst["paths"].items():
            pa = 1.0 if deterministic else min(1.0, p["rho"] * prof["omega"][pn])
            u = rnd.random()
            go = deterministic or u < pa
            draws["path"].append((go, pa))
            if not go:
                continue
            for hi, (hz, hj, _) in enumerate(p["hops"]):
                for d in slot:
                    if d[1] == hz and hj in inst["trap_techniques"][d[0]] and not rec[d]:
                        cov.add((pn, hi, t)); contacted_live.add(d)
    Q = 0
    for pn, p in inst["paths"].items():
        n = len(p["hops"])
        for t in range(inst["H"]):
            if any((pn, h, t) in cov for h in range(n - 1)):
                Q += c["L4"][f"{pn}|{t}"]
            Q += sum(c["L3"][f"{pn}|{h}|{t}"] for h in range(n) if (pn, h, t) in cov)
    techs = {j for d in contacted_live for j in inst["trap_techniques"][d[0]] if j in inst["techniques"]}
    Q += sum(c["L2_tech"][j] for j in techs) + sum(c["L2_fam"][f] for f in {inst["techniques"][j]["family"] for j in techs})
    Q += sum(c["L1"][f"{d[0]}|{d[3]}"] for d in contacted_live)
    return Q, cov, recognized, draws


def v1():
    t0 = time.time()
    seed_key = f"{INST['hash']}|L2"; S = INST["scale"]
    n_ep = mism = 0
    probe_hits = probe_n = 0
    path_stats = defaultdict(lambda: [0, 0])
    det_ok = True
    for m in R["methods"]:
        sched = sorted(set(map(tuple, m["schedule"])))
        for th in INST["profiles"]:
            ql = m["L2_stochastic"][th]["Q_list"]
            for ep, qrec in enumerate(ql):
                seed = int(hashlib.sha256(f"{seed_key}|{th}|{ep}".encode()).hexdigest()[:12], 16)
                q, _, _, dr = ref_episode(INST, sched, th, random.Random(seed), False)
                n_ep += 1
                if abs(q / S - qrec) > 1e-9:
                    mism += 1
                if m["method"] == "RC2 max-min (r*)":   # draws do not depend on the schedule: count once
                    probe_hits += sum(dr["probe"]); probe_n += len(dr["probe"])
                    for go, pa in dr["path"]:
                        path_stats[(th, pa)][0] += go; path_stats[(th, pa)][1] += 1
            # deterministic: recognized = evaluator burn set; contacted hops = evaluator coverage
            seed = int(hashlib.sha256(f"{seed_key}|{th}|0".encode()).hexdigest()[:12], 16)
            q, cov, recog, _ = ref_episode(INST, sched, th, random.Random(seed), True)
            u, v = evaluator.burn_state(INST, sched, th)
            burned = {d for d in sched if u[(d[0], d[1], d[2])] or v[(INST["fingerprint"][d[3]], d[2])]}
            ev = evaluator.evaluate(INST, sched, th)
            if recog != burned or q != ev["Q_int"] or len(cov) != round(ev["hop_coverage_pct"] * sum(len(p["hops"]) * INST["H"] for p in INST["paths"].values()) / 100):
                det_ok = False
    # probability checks
    zs = []
    for th in INST["profiles"]:
        pass
    probe_by_th = {}
    for m in [x for x in R["methods"] if x["method"] == "RC2 max-min (r*)"]:
        sched = sorted(set(map(tuple, m["schedule"])))
        for th in INST["profiles"]:
            h = n = 0
            for ep in range(len(m["L2_stochastic"][th]["Q_list"])):
                seed = int(hashlib.sha256(f"{seed_key}|{th}|{ep}".encode()).hexdigest()[:12], 16)
                _, _, _, dr = ref_episode(INST, sched, th, random.Random(seed), False)
                h += sum(dr["probe"]); n += len(dr["probe"])
            p = INST["profiles"][th]["rho"]
            probe_by_th[th] = {"stated": p, "observed": h / n, "n": n, "z": (h / n - p) / math.sqrt(p * (1 - p) / n)}
    path_rows = []
    for (th, pa), (h, n) in sorted(path_stats.items()):
        z = 0.0 if pa in (0.0, 1.0) else (h / n - pa) / math.sqrt(pa * (1 - pa) / n)
        path_rows.append({"profile": th, "stated": pa, "observed": h / n, "n": n, "z": z})
    V["V1"] = {"episodes_replayed": n_ep, "score_mismatches": mism,
               "deterministic_burn_and_coverage_equal_evaluator": det_ok,
               "probe_probability": probe_by_th, "path_probability": path_rows,
               "max_abs_z": max([abs(r["z"]) for r in path_rows] + [abs(r["z"]) for r in probe_by_th.values()]),
               "seconds": round(time.time() - t0, 1)}


# ------------------------------------------------------------------ V2
def v2():
    import glob
    errs, n_obj, n_files = [], 0, 0
    for f in sorted(glob.glob("out/stix_*.json")):
        b = json.load(open(f)); n_files += 1
        if b.get("type") != "bundle" or not b.get("id", "").startswith("bundle--"):
            errs.append(f"{f}: bad bundle")
        ids = [o["id"] for o in b["objects"]]
        if len(ids) != len(set(ids)):
            errs.append(f"{f}: duplicate ids")
        ind = {o["id"] for o in b["objects"] if o["type"] == "indicator"}
        for o in b["objects"]:
            n_obj += 1
            for k in ("type", "spec_version", "id", "created", "modified"):
                if k not in o:
                    errs.append(f"{f}: {o.get('id')} missing {k}")
            if o["spec_version"] != "2.1" or not o["id"].startswith(o["type"] + "--"):
                errs.append(f"{f}: {o['id']} bad spec/id")
            if o["type"] == "indicator" and not all(k in o for k in ("pattern", "pattern_type", "valid_from")):
                errs.append(f"{f}: indicator incomplete")
            if o["type"] == "sighting" and o.get("sighting_of_ref") not in ind:
                errs.append(f"{f}: dangling sighting")
    V["V2"] = {"bundles": n_files, "objects": n_obj, "errors": errs}


# ------------------------------------------------------------------ V3
def v3():
    paper = {"tau_d": {"low": 2, "med": 2, "high": 1, "burst": 1}, "tau_dp": {"low": 3, "med": 2, "high": 1, "burst": 1}}
    tdo = {th: sorted(set(INST["tau_d"][th].values())) for th in INST["profiles"]}
    a = R["adaptive"]["controlled_REDEPLOY"]
    changed = sorted(z for z in INST["Z"] if a["tau_d_before"]["low"][z] == 2 and a["tau_d_after"]["low"][z] == 1)
    changed_med = sorted(z for z in INST["Z"] if a["tau_d_before"]["med"][z] == 2 and a["tau_d_after"]["med"][z] == 1)
    checks = {
        "tau_d = 2,2,1,1 (every zone)": all(tdo[th] == [paper["tau_d"][th]] for th in tdo),
        "tau_dp = 3,2,1,1": INST["tau_dp"] == paper["tau_dp"],
        "q(Generic_Linux) 0.25 -> 0.412, others -> 0.196": round(a["q_after"]["Generic_Linux"], 3) == 0.412 and all(round(v, 3) == 0.196 for k, v in a["q_after"].items() if k != "Generic_Linux"),
        "tau_d 2 -> 1 in DMZ, Mgmt, OT for low and med": changed == changed_med == ["DMZ", "Mgmt", "OT"],
        "C10a needs ceil(0.72*4) = 3 slots": math.ceil(a["rho_after"]["ot_infiltration"] * 4) == 3,
        "REDEPLOY: 8,501.83 < r*' = 9,352.53": a["decision"] == "REDEPLOY" and round(a["deployed_r_min_updated"], 2) == 8501.83 and round(a["r_star_updated"], 2) == 9352.53,
        "KEEP: deployed attains r*' = 7,052.66": R["adaptive"]["financial_KEEP_check"]["decision"] == "KEEP" and round(R["adaptive"]["financial_KEEP_check"]["r_star_updated"], 2) == 7052.66,
        "gate PASS with verified certificate (both bundles)": all(v["gate"] == "PASS" and v["certificate"]["drat_check"].get("verified") for v in R["adaptive"].values()),
        "F15: every slot valid (8 h >= 2 h)": all(INST["slot_valid"]),
        "L4 unit 433.50; lower tiers up to 5,985.68": R["weights"]["tier_min_unit_int"]["L4"] == 43350 and sum(R["weights"]["tier_totals_int"][k] for k in ("L3", "L2", "L1")) == 598568,
    }
    V["V3"] = {"checks": checks, "all_pass": all(checks.values())}


# ------------------------------------------------------------------ V4
def v4():
    M = {m["method"]: m for m in R["methods"]}
    tl = M["RC2 tier-lex Q-med"]
    lay = evaluator.evaluate(INST, [tuple(d) for d in tl["schedule"]], "med")["layers_int"]
    passes = tl["solver"]["passes"]
    floors_kept = all(lay[p["tier"]] >= p["optimum_int"] for p in passes)
    exact = all(lay[p["tier"]] == p["optimum_int"] for p in passes)
    V["V4"] = {"pass_optima": {p["tier"]: p["optimum_int"] / 100 for p in passes},
               "final_schedule_tiers": {k: v / 100 for k, v in lay.items()},
               "every_floor_kept": floors_kept, "final_equals_pass_optima": exact,
               "cpsat_lex_agrees": R["cross_check"]["agree"]["lex_tiers"],
               "weights_alone_enforce_priority": all(R["weights"]["dominance_holds"].values()),
               "small_instance_lex_matches_enumeration": R["micro"]["match_lex"]}


# ------------------------------------------------------------------ V5
def coverage_instance(sets, k):
    items = sorted({e for s in sets for e in s})
    techs = {f"I{e}": {"family": f"f{e}", "W": 1.0} for e in items}
    techs["TX"] = {"family": "fx", "W": 1.0}
    K = [f"S{i}" for i in range(len(sets))]
    P = [f"role#{j}" for j in range(k)]
    inst = {"name": "kcov", "K": K, "Z": ["Z"], "H": 1, "P": P,
            "fingerprint": {p: f"fp{j}" for j, p in enumerate(P)},
            "techniques": techs, "trap_techniques": {f"S{i}": [f"I{e}" for e in s] for i, s in enumerate(sets)},
            "type_zone_ok": {"Z": K}, "role_types": {p: K for p in P}, "role_zones": {p: ["Z"] for p in P},
            "air_gapped": [], "air_gap_crossing_types": [], "conflicts": [],
            "B_t": k, "B_z": k, "churn_max": 2, "W_gap": 2, "kappa": [8], "kappa_min": 2,
            "paths": {"none": {"rho": 0.0, "critical": 0, "hops": [["Z", "TX", 1.0], ["Z", "TX", 1.0]]}},
            "profiles": {"med": {"rho": 0.3, "omega": {"none": 1.0}}},
            "q": {p: 0.25 for p in P},
            "layer_w": {"L4": 0, "L3_fwd": 0, "L3_bwd": 0, "L2_tech": 1, "L2_fam": 0, "L1": 0}, "scale": 100,
            "tau_d0": 3, "tau_dp0": 4, "rho_max": 1.0}
    return instance.finalize(inst)


def v5(n=30, seed=5):
    rnd = random.Random(seed); ok = 0; rows = []
    for _ in range(n):
        m, u = rnd.randint(4, 8), rnd.randint(5, 10)
        sets = [sorted(rnd.sample(range(u), rnd.randint(1, 4))) for _ in range(m)]
        k = rnd.randint(1, 3)
        brute = max(len(set().union(*c)) if c else 0 for c in itertools.combinations(sets, min(k, m)))
        inst = coverage_instance(sets, k)
        enc = encoder.Enc(inst)
        wp = solvers.weighted_pass(enc, "med")
        mm = solvers.maxmin(enc)
        z = wp["objective_int"] // 100
        feas = not evaluator.check(inst, wp["schedule"])
        rows.append({"m": m, "items": u, "k": k, "brute_force": brute, "zstp_weighted": z, "zstp_maxmin": mm["r_star_int"] // 100, "feasible": feas})
        ok += (z == brute == mm["r_star_int"] // 100 and feas)
    V["V5"] = {"instances": n, "agree": ok, "examples": rows[:5]}


# ------------------------------------------------------------------ V6
def v6():
    raw = [m for m in R["methods"] if m["state"] == "infeasible"]
    only_b = [m["method"] for m in raw if "C10b" in m["violations"] and "C10a" not in m["violations"]]
    only_a = [m["method"] for m in raw if "C10a" in m["violations"] and "C10b" not in m["violations"]]
    both = [m["method"] for m in raw if "C10a" in m["violations"] and "C10b" in m["violations"]]
    # constructed witness for "C10a without C10b": enough slots overall is not implied by no gaps, and vice versa
    V["V6"] = {"break_C10b_only": only_b, "break_C10a_only": only_a, "break_both": both,
               "distinct": bool(only_b) or bool(only_a)}


if __name__ == "__main__":
    for f in (v3, v4, v6, v2, v5, v1):
        f(); print(f.__name__, json.dumps(V[f.__name__.upper()], default=str)[:400])
    json.dump(V, open("out/validation.json", "w"), indent=1, default=str)
