"""Single entry point. Produces out/results.json (the one results source) plus certificates,
STIX bundles and instance files. Every table is generated from results.json by tables.py.

    python3 run_all.py            # full run
"""
import json, hashlib, glob, os, subprocess, time, copy, platform
import instance, encoder, solvers, evaluator, baselines, cross_check, micro, adaptive, emulation_l2 as em

OUT = "out"
os.makedirs(OUT, exist_ok=True)
N_EPISODES = 100


def code_hash():
    h = hashlib.sha256()
    for f in ["instance.py", "encoder.py", "evaluator.py", "solvers.py", "baselines.py", "cross_check.py",
              "micro.py", "adaptive.py", "emulation_l2.py", "run_all.py"]:
        h.update(open(f, "rb").read())
    return h.hexdigest()[:12]


CODE = code_hash()


def run_id(inst, method):
    return hashlib.sha256(f"{inst['hash']}|{method}|{CODE}".encode()).hexdigest()[:10]


def record(inst, method, sched, objective, state, extra=None):
    ev = evaluator.evaluate_all(inst, sched)
    rec = {
        "run_id": run_id(inst, method), "instance": inst["name"], "instance_hash": inst["hash"],
        "method": method, "objective": objective, "state": state,
        "schedule": [list(d) for d in evaluator.norm(sched)],
        "violations": evaluator.check(inst, sched),
        "scores": {th: {k: v for k, v in ev["per_profile"][th].items()} for th in inst["profiles"]},
        "r_min": ev["r_min"], "worst_profile": ev["worst_profile"],
        "static": evaluator.static_metrics(inst, sched),
    }
    rec["feasible"] = not rec["violations"]
    rec.update(extra or {})
    return rec


def l2(inst, rec):
    """Common random numbers: the attacker's random stream depends only on the instance, the
    profile and the episode -- not on the method or the code version -- and the number of draws
    per episode does not depend on the schedule, so every schedule faces the same attacker
    episodes and methods can be compared pairwise."""
    sched = [tuple(d) for d in rec["schedule"]]
    seed_key = f"{inst['hash']}|L2"
    det, sto = {}, {}
    for th in inst["profiles"]:
        d = em.emulate(inst, sched, th, 1, True, seed_key)
        det[th] = {"Q_log": d["Q_mean"], "Q_eval": rec["scores"][th]["Q"],
                   "match": abs(d["Q_mean"] - rec["scores"][th]["Q"]) < 1e-6, "connections": d["connections"]}
        s = em.emulate(inst, sched, th, N_EPISODES, False, seed_key)
        sto[th] = {k: v for k, v in s.items() if k != "log"}
        # 95% normal-approximation CI half-width of the episode mean (sample sd, n episodes)
        n = s["episodes"]
        sto[th]["Q_ci95_half"] = 1.96 * s["Q_sd"] * (n / (n - 1)) ** 0.5 / n ** 0.5 if n > 1 else 0.0
        if rec["method"].startswith("RC2 max-min"):
            with open(f"{OUT}/stix_{rec['run_id']}_{th}.json", "w") as fh:
                json.dump(em.stix_bundle(inst, rec["run_id"], th, s["log"]), fh, indent=1)
    rec["L2_deterministic"] = det
    rec["L2_stochastic"] = sto
    rec["L2_emulated_worst_mean"] = min(v["Q_mean"] for v in sto.values())


def drat_check(cert):
    exe = "/tmp/drat-trim/drat-trim"
    if not cert or not os.path.exists(exe):
        return {"checked": False, "reason": "drat-trim not available"}
    p = subprocess.run([exe, cert["cnf"], cert["drat"]], capture_output=True, text=True, timeout=900)
    ok = "s VERIFIED" in p.stdout
    return {"checked": True, "verified": ok, "checker": "drat-trim", "tail": p.stdout.strip().splitlines()[-2:]}


def main():
    t_start = time.time()
    R = {"meta": {"code_hash": CODE, "python": platform.python_version(), "started": time.strftime("%Y-%m-%d %H:%M:%S"),
                  "note": "Independent reimplementation from the ZSTP papers; instance values not stated in the papers are documented defaults in instance.py."}}
    inst = instance.build_xlarge()
    json.dump(inst, open(f"{OUT}/instance_xlarge.json", "w"), indent=1)
    json.dump(instance.build_micro(), open(f"{OUT}/instance_micro.json", "w"), indent=1)
    R["instance"] = {"hash": inst["hash"], "K": len(inst["K"]), "Z": len(inst["Z"]), "H": inst["H"], "P": len(inst["P"]),
                     "F": len(set(inst["fingerprint"].values())), "fingerprints": inst["fingerprint"],
                     "tau_d": inst["tau_d"], "tau_dp": inst["tau_dp"], "B_t": inst["B_t"], "B_z": inst["B_z"],
                     "paths": {k: v["rho"] for k, v in inst["paths"].items()}}
    enc = encoder.Enc(inst)
    R["encoding"] = enc.stats()
    recs = []
    # --- RC2 procedures
    mm = solvers.maxmin(enc, proof_path=f"{OUT}/maxmin_xlarge")
    cert = mm["certificate"]; cert["drat_check"] = drat_check(cert)
    recs.append(record(inst, "RC2 max-min (r*)", mm["schedule"], "max_x min_theta Q_theta (exact, SAT binary search)", "raw",
                       {"solver": {"r_star_int": mm["r_star_int"], "sat_calls": mm["sat_calls"], "seconds": round(mm["seconds"], 1), "certificate": cert}}))
    tl = solvers.tier_lex(enc, "med")
    recs.append(record(inst, "RC2 tier-lex Q-med", tl["schedule"], "4 RC2 passes at theta_med: L4, then L3, L2, L1, earlier tier optima kept as hard floors", "raw",
                       {"solver": {"tiers_int": tl["tiers_int"], "passes": tl["passes"], "seconds": round(tl["seconds"], 2)}}))
    wp = solvers.weighted_pass(enc, "med")

    sf = solvers.scenario_first(enc)
    recs.append(record(inst, "RC2 burst-first (V3 §5.2)", sf["schedule"], "Q_burst, then Q_high, Q_med, Q_low with floors", "raw",
                       {"solver": {"floors_int": sf["floors_int"], "seconds": round(sf["seconds"], 1)}}))
    # canonical r*-optimal schedule: among all schedules with min_theta Q_theta >= r*, the one
    # with the highest Q_med (r* optima are not unique; the plain search returns an arbitrary one)
    tb = solvers.maxmin_tiebreak(enc, mm["r_star_int"], "med")
    recs.append(record(inst, "RC2 max-min + Q-med tie-break", tb["schedule"], "max Q_med s.t. Q_theta >= r* for every theta", "raw",
                       {"solver": {"r_star_int": mm["r_star_int"], "Qmed_int": tb["objective_int"], "seconds": round(tb["seconds"], 1)}}))
    # --- baselines
    for name, fn in baselines.BASELINES.items():
        raw = fn(inst)
        r0 = record(inst, name, raw, "heuristic (burn-blind where it scores)", "raw")
        if r0["feasible"]:
            recs.append(r0); continue
        r0["state"] = "infeasible"
        recs.append(r0)
        rep, info = baselines.repair(inst, raw, enc)
        recs.append(record(inst, name + " (repaired)", rep, "nearest feasible schedule to raw (min changes)", "repaired",
                           {"repair": {"changes": info["changes"], "removed": [list(x) for x in info["removed"]], "added": [list(x) for x in info["added"]]}}))
    # --- L2 emulation for every record
    for rec in recs:
        l2(inst, rec)
    R["methods"] = recs
    # --- cross-checks (independent CP-SAT model)
    R["cross_check"] = {
        "maxmin": cross_check.maxmin(inst), "lex_med": cross_check.lex(inst, "med"), "weighted_med": cross_check.weighted(inst, "med"),
    }
    cc = R["cross_check"]
    # agreement counts only if CP-SAT proved optimality (a time-limited FEASIBLE value is not a check)
    R["cross_check"]["agree"] = {
        "r_star": cc["maxmin"]["status"] == "OPTIMAL" and cc["maxmin"]["r_star_int"] == mm["r_star_int"],
        "lex_tiers": all(s == "OPTIMAL" for s in cc["lex_med"]["status"]) and cc["lex_med"]["tiers_int"] == tl["tiers_int"],
        "weighted": cc["weighted_med"]["status"] == "OPTIMAL" and cc["weighted_med"]["objective_int"] == wp["objective_int"],
    }
    # --- weight dominance analysis
    terms = enc.terms["med"]
    tot = {k: sum(w for (L, w, _) in terms if L == k) for k in ["L4", "L3", "L2", "L1"]}
    minw = {k: min(w for (L, w, _) in terms if L == k) for k in ["L4", "L3", "L2", "L1"]}
    wp_ms = set()
    wp_tiers = evaluator.evaluate(inst, wp["schedule"], "med")["layers_int"]
    R["weights"] = {
        "tier_totals_int": tot, "tier_min_unit_int": minw,
        "dominance_holds": {"L4>L3+L2+L1": minw["L4"] > tot["L3"] + tot["L2"] + tot["L1"],
                            "L3>L2+L1": minw["L3"] > tot["L2"] + tot["L1"], "L2>L1": minw["L2"] > tot["L1"]},
        "weighted_pass_tiers_int": wp_tiers, "lex_tiers_int": tl["tiers_int"],
        "weighted_equals_lex": wp_tiers == tl["tiers_int"],
    }
    # --- zero-burn analysis
    zb_all = cross_check.zero_burn_maxmin(inst)
    zb_lm = cross_check.zero_burn_maxmin(inst, ("low", "med"))
    i2 = copy.deepcopy(inst); i2["churn_max"] = 3
    zb_c3, mm_c3 = cross_check.zero_burn_maxmin(i2), cross_check.maxmin(i2)
    R["zero_burn"] = {
        "all_profiles": zb_all.get("status"), "all_profiles_r_int": zb_all.get("r_star_int"),
        "low_med_only_r_int": zb_lm.get("r_star_int"), "low_med_only_status": zb_lm.get("status"),
        "churn3_all_profiles_r_int": zb_c3.get("r_star_int"), "churn3_all_profiles_status": zb_c3.get("status"),
        "churn3_unconstrained_r_int": mm_c3["r_star_int"], "churn3_unconstrained_status": mm_c3["status"],
    }
    # --- micro-instance
    R["micro"] = micro.run()
    R["micro"]["certificate"]["drat_check"] = drat_check(R["micro"]["certificate"])
    # --- adaptive loop: Algorithm 1 as in the paper (deployed = max-min schedule; robust re-solve;
    #     KEEP iff the deployed schedule is feasible and still attains r*'; drat-trim gate)
    R["adaptive"] = {k: adaptive.run_bundle(inst, mm["schedule"], tl["schedule"], b, drat_check=drat_check, out_dir=OUT)
                     for k, b in adaptive.BUNDLES.items()}
    # --- sensitivity (+/-25%), solver re-run each time
    sens = []
    base_mm = set(map(tuple, mm["schedule"])); base_tl = set(map(tuple, tl["schedule"]))
    for key in ["rho", "iv", "W", "L4"]:
        for f in [0.75, 1.25]:
            ip = instance.build_xlarge(perturb={key: f}); ep = encoder.Enc(ip)
            a = solvers.maxmin(ep); b = solvers.tier_lex(ep, "med")
            base_r = evaluator.evaluate_all(ip, mm["schedule"])["r_min_int"]
            sens.append({"param": key, "factor": f, "r_star": a["r_star_int"] / ip["scale"],
                         "base_schedule_r": base_r / ip["scale"],
                         "base_schedule_regret_pct": round(100.0 * (a["r_star_int"] - base_r) / a["r_star_int"], 2),
                         "r_star_schedule_changed": set(map(tuple, a["schedule"])) != base_mm,
                         "Qmed_lex": b["objective_int"] / ip["scale"],
                         "lex_schedule_changed": set(map(tuple, b["schedule"])) != base_tl})
    for v in [0.40]:
        ip = instance.build_xlarge(perturb={"q_Finance": v}); ep = encoder.Enc(ip)
        a = solvers.maxmin(ep); b = solvers.tier_lex(ep, "med")
        base_r = evaluator.evaluate_all(ip, mm["schedule"])["r_min_int"]
        sens.append({"param": "q_Finance", "factor": v, "r_star": a["r_star_int"] / ip["scale"],
                     "base_schedule_r": base_r / ip["scale"],
                     "base_schedule_regret_pct": round(100.0 * (a["r_star_int"] - base_r) / a["r_star_int"], 2),
                     "r_star_schedule_changed": set(map(tuple, a["schedule"])) != base_mm,
                     "Qmed_lex": b["objective_int"] / ip["scale"], "lex_schedule_changed": set(map(tuple, b["schedule"])) != base_tl})
    R["sensitivity"] = {"base_r_star": mm["r_star_int"] / inst["scale"], "base_Qmed_lex": tl["objective_int"] / inst["scale"], "runs": sens}
    R["meta"]["seconds"] = round(time.time() - t_start, 1)
    json.dump(R, open(f"{OUT}/results.json", "w"), indent=1, default=str)
    print("done", R["meta"]["seconds"], "s")


if __name__ == "__main__":
    main()
