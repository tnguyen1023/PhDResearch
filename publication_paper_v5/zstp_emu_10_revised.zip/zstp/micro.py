"""Exhaustive validation on the micro-instance (|K|=3, |Z|=2, H=3, |P|=2 -> 36 binary x).

Any x outside the static plausibility table is fixed to 0 by C5/C5b unit clauses, so
enumerating every subset of the plausible variables enumerates every candidate feasible
schedule. Each subset is checked by the independent checker and scored by the evaluator.
"""
import itertools, time
import instance, evaluator, encoder, solvers, cross_check
from baselines import plausible


def enumerate_all(inst):
    cand = [(i, z, t, r) for t in range(inst["H"]) for z in inst["Z"] for i in inst["K"] for r in inst["P"]
            if plausible(inst, i, z, r)]
    t0 = time.time()
    feas = []
    n = 0
    for mask in range(1 << len(cand)):
        n += 1
        sched = [cand[k] for k in range(len(cand)) if mask >> k & 1]
        # cheap budget prefilter (identical to C2/C3 in the checker)
        if any(sum(1 for d in sched if d[2] == t) > inst["B_t"] for t in range(inst["H"])):
            continue
        if evaluator.check(inst, sched):
            continue
        q = {th: evaluator.evaluate(inst, sched, th)["Q_int"] for th in inst["profiles"]}
        lay = evaluator.evaluate(inst, sched, "med")["layers_int"]
        feas.append((sched, q, lay))
    return cand, n, feas, time.time() - t0


def run():
    inst = instance.build_micro()
    cand, n, feas, dt = enumerate_all(inst)
    rmins = [min(q.values()) for _, q, _ in feas]
    best_r = max(rmins)
    r_opt = [f for f, r in zip(feas, rmins) if r == best_r]
    med = [q["med"] for _, q, _ in feas]
    best_med = max(med)
    lexkey = lambda L: (L["L4"], L["L3"], L["L2"], L["L1"])
    best_lex = max(lexkey(l) for _, _, l in feas)
    enc = encoder.Enc(inst)
    mm = solvers.maxmin(enc, proof_path="out/maxmin_micro")
    tl = solvers.tier_lex(enc, "med")
    wp = solvers.weighted_pass(enc, "med")
    sf = solvers.scenario_first(enc)
    sf_r = evaluator.evaluate_all(inst, sf["schedule"])["r_min_int"]
    cp = cross_check.maxmin(inst)
    return {
        "instance_hash": inst["hash"], "binary_x": len(enc.X), "plausible_x": len(cand),
        "subsets_enumerated": n, "feasible_schedules": len(feas), "seconds": round(dt, 1),
        "distinct_r_values": len(set(rmins)), "schedules_with_r_gt_0": sum(1 for r in rmins if r > 0),
        "enum_r_star": best_r / inst["scale"], "enum_r_star_optimal_set_size": len(r_opt),
        "enum_best_Qmed": best_med / inst["scale"], "enum_best_lex_tiers": [v / inst["scale"] for v in best_lex],
        "sat_r_star": mm["r_star_int"] / inst["scale"], "sat_schedule": mm["schedule"],
        "sat_schedule_in_enum_optimal_set": any(sorted(f[0]) == sorted(mm["schedule"]) for f in r_opt),
        "cpsat_r_star": cp["r_star_int"] / inst["scale"],
        "rc2_lex_tiers": [tl["tiers_int"][k] / inst["scale"] for k in ["L4", "L3", "L2", "L1"]],
        "rc2_weighted_Qmed": wp["objective_int"] / inst["scale"],
        "scenario_first_r": sf_r / inst["scale"],
        "match_r_star": mm["r_star_int"] == best_r == cp["r_star_int"],
        "match_lex": tuple(tl["tiers_int"][k] for k in ["L4", "L3", "L2", "L1"]) == best_lex,
        "match_weighted": wp["objective_int"] == best_med,
        "certificate": mm["certificate"],
    }


if __name__ == "__main__":
    import json
    print(json.dumps({k: v for k, v in run().items() if k != "sat_schedule"}, indent=1))
