# ZSTP rerun — independent reimplementation

Reimplements the ZSTP honeypot-scheduling model from the paper's equations and produces every
reported number from one results file.

    pip install python-sat ortools scipy
    python3 run_all.py      # ~7 min on 2 cores -> out/results.json (+ certificates, STIX bundles)
    python3 tables.py       # every table -> out/tables.md, out/table_*.csv, out/tables.json
    python3 charts.py       # comparison table C1 + figures out/fig1..fig7 (from results.json only)
    python3 test_consistency.py   # encoder vs evaluator agreement on random feasible schedules
    drat-trim out/maxmin_xlarge.cnf out/maxmin_xlarge.drat   # optimality certificate check

| File | Role |
|---|---|
| instance.py | XLarge and micro instances; U11 thresholds; integer coefficients. Values the paper does not state are marked DEFAULT. |
| evaluator.py | Common evaluator (burn, coverage, scores, metrics) and independent hard-constraint checker |
| encoder.py | WCNF encoding with per-profile burn states; adder-based PB encoding |
| solvers.py | RC2 weighted pass, tier-lexicographic (BMO), burst-first with floors, exact max-min (SAT binary search + DRAT) |
| cross_check.py | Independent CP-SAT model: max-min, lexicographic passes with floors, weighted, zero-burn feasibility |
| baselines.py | Ten baselines + nearest-feasible repair |
| micro.py | Exhaustive micro-instance validation |
| adaptive.py | Algorithm 1 (KEEP / REDEPLOY) with U11 |
| emulation_l2.py | L2 process emulation: asyncio TCP honeypots, Bernoulli attackers, STIX 2.1 bundles |
| run_all.py | Single entry point; run IDs = hash(instance, method, code) |

Two complete runs produce identical results.json apart from timing fields.
