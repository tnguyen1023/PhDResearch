"""Algorithm 1 (threat-adaptive re-solve) on controlled STIX bundles.

Step 1  q_p := normalize(q_p + alpha * confidence * onehot(role mapped from campaign))   alpha = 0.3
Step 2a U11: path rho updated from the bundle; tau thresholds recomputed (instance.finalize)
Step 3  RC2 re-solve of the tier-lexicographic Q-med objective on the regenerated WCNF
Step 4  Both the current and the new schedule are scored by the evaluator under the SAME updated
        inputs; dQ = Qmed(new) - Qmed(current); REDEPLOY iff dQ > 0 (or current infeasible)
Step 5  Checker audit of the new schedule before it is accepted
Also reported: worst-case score of both schedules under the updated inputs, and the updated
instance's own r* (re-solved), so the guarantee that survives the update is explicit.
Two robustness-preserving variants are evaluated on the same bundle:
  A. guarded acceptance: REDEPLOY only if Q-med rises AND the worst-case score does not fall
  B. robust re-solve: deploy the max-min schedule of the updated instance (certified r* for the new inputs)
"""
import instance, encoder, solvers, evaluator

ALPHA = 0.3
CAMPAIGN_ROLE = {"OT_infiltration": "Generic_Linux",       # only GK-valid role in the OT zone
                 "financial": "Finance_DB_Server"}
CAMPAIGN_PATH = {"OT_infiltration": "ot_infiltration", "financial": "web_to_db"}


def update_q(q, role, conf):
    raw = {r: v + (ALPHA * conf if r == role else 0.0) for r, v in q.items()}
    s = sum(raw.values())
    return {r: round(v / s, 6) for r, v in raw.items()}


def run_bundle(inst0, current, bundle):
    q1 = update_q(inst0["q"], CAMPAIGN_ROLE[bundle["campaign_class"]], bundle["confidence"])
    rho_override = {p: v["rho"] for p, v in inst0["paths"].items()}
    if bundle.get("rho_pi") is not None:
        rho_override[CAMPAIGN_PATH[bundle["campaign_class"]]] = bundle["rho_pi"]
    inst1 = instance.build_xlarge(q=q1, path_rho_override=rho_override)
    enc1 = encoder.Enc(inst1)
    new = solvers.tier_lex(enc1, "med")
    old_viol = evaluator.check(inst1, current)
    ev_old_I0 = evaluator.evaluate_all(inst0, current)
    ev_old = evaluator.evaluate_all(inst1, current)
    ev_new = evaluator.evaluate_all(inst1, new["schedule"])
    dq = ev_new["per_profile"]["med"]["Q_int"] - ev_old["per_profile"]["med"]["Q_int"]
    decision = "REDEPLOY" if (dq > 0 or old_viol) else "KEEP"
    audit = evaluator.check(inst1, new["schedule"])
    rstar1 = solvers.maxmin(enc1, proof_path=f"out/maxmin_updated_{inst1['hash']}")
    S = inst1["scale"]
    # Option A: guarded acceptance -- switch only if Q-med rises AND the worst-case score does not fall
    guarded = "REDEPLOY" if (old_viol or (dq > 0 and ev_new["r_min_int"] >= ev_old["r_min_int"])) else "KEEP"
    # Option B: robust re-solve -- deploy the max-min schedule of the updated instance
    rob = rstar1["schedule"]
    ev_rob = evaluator.evaluate_all(inst1, rob)
    return {
        "bundle": bundle, "q_before": inst0["q"], "q_after": q1,
        "rho_after": {p: v["rho"] for p, v in inst1["paths"].items()},
        "tau_d_after": inst1["tau_d"], "tau_dp_after": inst1["tau_dp"], "instance_hash_after": inst1["hash"],
        "current_schedule": current, "new_schedule": new["schedule"],
        "current_violations_under_updated_inputs": old_viol,
        "Qmed_current_original_inputs": ev_old_I0["per_profile"]["med"]["Q"],
        "Qmed_current_updated_inputs": ev_old["per_profile"]["med"]["Q"],
        "Qmed_new_updated_inputs": ev_new["per_profile"]["med"]["Q"],
        "dQ": dq / S, "dQ_pct": 100.0 * dq / ev_old["per_profile"]["med"]["Q_int"],
        "decision": decision,
        "audit_new": audit or "all hard constraints pass",
        "per_profile_current": {th: v["Q"] for th, v in ev_old["per_profile"].items()},
        "per_profile_new": {th: v["Q"] for th, v in ev_new["per_profile"].items()},
        "r_min_current_updated": ev_old["r_min"], "r_min_new_updated": ev_new["r_min"],
        "r_star_updated_instance": rstar1["r_star_int"] / S,
        "guarded_decision": guarded,
        "guarded_rule": "REDEPLOY iff Qmed(new) > Qmed(current) and worst-case(new) >= worst-case(current), both on updated inputs",
        "robust_resolve": {
            "schedule": rob, "audit": evaluator.check(inst1, rob) or "all hard constraints pass",
            "per_profile": {th: v["Q"] for th, v in ev_rob["per_profile"].items()},
            "Qmed": ev_rob["per_profile"]["med"]["Q"], "r_min": ev_rob["r_min"], "worst_profile": ev_rob["worst_profile"],
            "burn_high_pct": ev_rob["per_profile"]["high"]["Burn_any_pct"],
            "certificate": rstar1["certificate"],
        },
        "burn_high_pct_current": ev_old["per_profile"]["high"]["Burn_any_pct"],
        "burn_high_pct_new": ev_new["per_profile"]["high"]["Burn_any_pct"],
    }


BUNDLES = {
    "controlled_REDEPLOY": {"campaign_class": "OT_infiltration", "confidence": 0.92, "rho_pi": 0.72},
    "financial_KEEP_check": {"campaign_class": "financial", "confidence": 0.70, "rho_pi": None},
}
