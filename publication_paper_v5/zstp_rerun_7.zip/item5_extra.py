"""Revised Algorithm 1 decision (robust re-solve) computed from results.json only:
re-run max-min on the updated inputs; keep the deployed robust schedule if it already reaches the
new optimum, otherwise deploy the new max-min schedule."""
import json, instance, evaluator
R = json.load(open("out/results.json"))
mm = [tuple(d) for d in R["methods"][0]["schedule"]]
out = {}
for k, a in R["adaptive"].items():
    i1 = instance.build_xlarge(q=a["q_after"], path_rho_override=a["rho_after"])
    e = evaluator.evaluate_all(i1, mm)
    best = a["robust_resolve"]["r_min"]
    out[k] = {"deployed_r_min_updated": e["r_min"], "deployed_Qmed_updated": e["per_profile"]["med"]["Q"],
              "new_optimum": best, "decision": "KEEP" if round(e["r_min"], 2) >= round(best, 2) else "REDEPLOY",
              "deployed_violations": evaluator.check(i1, mm)}
json.dump(out, open("out/item5_extra.json", "w"), indent=1)
print(out)
