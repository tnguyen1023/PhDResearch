"""Charts for the response document, generated only from out/results.json.

Encoding used in every chart:
  color  = method family  (blue #2a78d6 = RC2 procedures, orange #eb6834 = baselines; validated palette)
  fill   = feasibility    (filled = feasible, hollow = infeasible as produced)
One x-scale per panel; no dual axes. Numbers are in the tables; charts label selectively.
"""
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

R = json.load(open("out/results.json"))
M = {m["method"]: m for m in R["methods"]}
BLUE, ORANGE = "#2a78d6", "#eb6834"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e6e5e1", "#ffffff"
TH = ["low", "med", "high", "burst"]
BASES = [m for m in M if not m.startswith("RC2") and not m.endswith("(repaired)")]
RC2 = [m for m in M if m.startswith("RC2")]

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
    "xtick.color": INK2, "ytick.color": INK, "axes.titlesize": 9.5, "axes.titleweight": "bold",
    "axes.titlecolor": INK, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
})


def style(ax, grid_axis="x"):
    for s in ["top", "right", "left"]:
        ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)


def short(n):
    return n.replace(" (V3 §5.2)", " (V3)").replace("tier-lex Q-med", "Q-med (4-pass)")


def legend_family(ax, loc="lower right", hollow=True):
    h = [Patch(color=BLUE, label="RC2 procedure"), Patch(color=ORANGE, label="Baseline")]
    if hollow:
        h += [Line2D([], [], marker="o", ls="", mfc="white", mec=INK2, mew=1.5, ms=7, label="Infeasible (as produced)"),
              Line2D([], [], marker="o", ls="", mfc=INK2, mec=INK2, ms=7, label="Feasible")]
    ax.legend(handles=h, loc=loc, frameon=False, fontsize=7.5)


# ---------- Fig 1: worst-case score, every schedule (dumbbell raw -> repaired) ----------
def fig1():
    rows = [(m, M[m]["r_min"], None, BLUE) for m in RC2]
    rows += [(b, M[b]["r_min"], M[b + " (repaired)"]["r_min"], ORANGE) for b in BASES]
    rows.sort(key=lambda r: max(r[1], r[2] or 0))
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    for y, (name, raw, rep, col) in enumerate(rows):
        if rep is None:
            ax.plot([0, raw], [y, y], color=col, lw=2, solid_capstyle="round")
            ax.plot(raw, y, "o", color=col, ms=8, mec="white", mew=1.5)
        else:
            ax.plot([raw, rep], [y, y], color=GRID, lw=2, zorder=1)
            ax.plot(raw, y, "o", mfc="white", mec=col, mew=2, ms=8, zorder=3)
            ax.plot(rep, y, "o", color=col, ms=8, mec="white", mew=1.5, zorder=3)
    ax.set_yticks(range(len(rows)), [short(r[0]) for r in rows])
    best = max(rows, key=lambda r: r[1])
    ax.annotate(f"r* = {best[1]:,.2f}", (best[1], len(rows) - 1), xytext=(-6, 9), textcoords="offset points", ha="right", color=INK, fontsize=8)
    ax.set_xlabel("Worst-case score  min over θ of Q_θ  (higher is better)")
    ax.set_title("Worst-case score of every schedule (XLarge, common evaluator)", loc="left")
    ax.set_xlim(0, best[1] * 1.08)
    style(ax); legend_family(ax)
    fig.tight_layout(); fig.savefig("out/fig1_worstcase.png", dpi=200); plt.close(fig)


# ---------- Fig 2: per-profile scores, small multiples (feasible schedules) ----------
def fig2():
    names = RC2 + [b + " (repaired)" for b in BASES]
    names.sort(key=lambda n: M[n]["r_min"])
    fig, axs = plt.subplots(1, 4, figsize=(6.8, 4.2), sharey=True, sharex=True)
    xmax = max(M[n]["scores"][t]["Q"] for n in names for t in TH) * 1.05
    for ax, t in zip(axs, TH):
        for y, n in enumerate(names):
            col = BLUE if n.startswith("RC2") else ORANGE
            ax.barh(y, M[n]["scores"][t]["Q"], height=0.62, color=col, edgecolor=SURF, linewidth=1)
        ax.set_title(f"θ_{t}", loc="left")
        ax.set_xlim(0, xmax)
        ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, p: f"{v/1000:.0f}k"))
        style(ax)
    axs[0].set_yticks(range(len(names)), [short(n).replace(" (repaired)", " (rep.)") for n in names])
    fig.suptitle("Score under each attacker profile — feasible schedules only", x=0.01, ha="left", fontsize=9.5, fontweight="bold", color=INK)
    fig.legend(handles=[Patch(color=BLUE, label="RC2 procedure"), Patch(color=ORANGE, label="Baseline (repaired)")],
               loc="lower center", ncol=2, frameon=False, fontsize=7.5, bbox_to_anchor=(0.6, 0))
    fig.tight_layout(rect=(0, 0.05, 1, 0.95)); fig.savefig("out/fig2_profiles.png", dpi=200); plt.close(fig)


# ---------- Fig 3: Q-med vs worst-case trade-off ----------
def fig3():
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    for n, m in M.items():
        col = BLUE if n.startswith("RC2") else ORANGE
        feas = m["feasible"]
        ax.plot(m["scores"]["med"]["Q"], m["r_min"], "o", ms=8, mfc=col if feas else "white", mec=col if not feas else "white",
                mew=2 if not feas else 1.5, zorder=3)
    lab = {"RC2 max-min (r*)": (-10, 4, "right"), "RC2 burst-first (V3 §5.2)": (-10, -10, "right"),
           "RC2 tier-lex Q-med": (0, -16, "center"), "Greedy-Diverse": (-10, 6, "right")}
    for n, (dx, dy, ha) in lab.items():
        m = M[n]
        txt = short(n).replace("tier-lex Q-med", "Q-med (4-pass)") + ("\n(infeasible)" if n == "Greedy-Diverse" else "")
        ax.annotate(txt, (m["scores"]["med"]["Q"], m["r_min"]), xytext=(dx, dy), textcoords="offset points",
                    ha=ha, va="center" if dy > -12 else "top", fontsize=7.3, color=INK)
    fmt = matplotlib.ticker.FuncFormatter(lambda v, p: f"{v:,.0f}")
    ax.xaxis.set_major_formatter(fmt); ax.yaxis.set_major_formatter(fmt)
    ax.set_xlim(0, 11800)
    ax.set_xlabel("Q at θ_med (what the Q-med objective maximizes)")
    ax.set_ylabel("Worst-case score (what r* maximizes)")
    ax.set_title("Q-med and the robust objective pick different schedules", loc="left")
    ax.set_xlim(left=0); ax.set_ylim(bottom=0)
    style(ax, "both"); ax.spines["left"].set_visible(True); ax.spines["left"].set_color(GRID)
    legend_family(ax, loc="upper left")
    fig.tight_layout(); fig.savefig("out/fig3_tradeoff.png", dpi=200); plt.close(fig)


# ---------- Fig 4: burn rates at theta_med and theta_burst ----------
def fig4():
    names = RC2 + BASES
    names.sort(key=lambda n: M[n]["scores"]["burst"]["Burn_any_pct"])
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 3.9), sharey=True, sharex=True)
    for ax, t in zip(axs, ["med", "burst"]):
        for y, n in enumerate(names):
            m = M[n]; col = BLUE if n.startswith("RC2") else ORANGE
            v = m["scores"][t]["Burn_any_pct"]
            ax.barh(y, v, height=0.62, color=col if m["feasible"] else SURF, edgecolor=col, linewidth=1.4)
        ax.set_title(f"Burned deployments at θ_{t}", loc="left")
        ax.set_xlim(0, 100)
        ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, p: f"{v:.0f}%"))
        style(ax)
    axs[0].set_yticks(range(len(names)), [short(n) for n in names])
    fig.legend(handles=[Patch(color=BLUE, label="RC2 procedure (feasible)"), Patch(facecolor=SURF, edgecolor=ORANGE, linewidth=1.4, label="Baseline as produced (infeasible)")],
               loc="lower center", ncol=2, frameon=False, fontsize=7.5)
    fig.tight_layout(rect=(0, 0.06, 1, 1)); fig.savefig("out/fig4_burn.png", dpi=200); plt.close(fig)


# ---------- Fig 5: REDEPLOY decomposition ----------
def fig5():
    a = R["adaptive"]["controlled_REDEPLOY"]
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.9), gridspec_kw={"width_ratios": [3, 2]})
    ax = axs[0]
    labels = ["Current schedule,\noriginal inputs", "Current schedule,\nupdated inputs", "New schedule,\nupdated inputs"]
    vals = [a["Qmed_current_original_inputs"], a["Qmed_current_updated_inputs"], a["Qmed_new_updated_inputs"]]
    ax.bar(range(3), vals, width=0.55, color=BLUE, edgecolor=SURF)
    for x, v in enumerate(vals):
        ax.text(x, v, f"{v:,.0f}", ha="center", va="bottom", fontsize=7.5, color=INK)
    ax.text(1, vals[1] * 0.5, f"model\nupdate\n+{vals[1]-vals[0]:,.0f}", ha="center", fontsize=7, color="white")
    ax.set_ylim(0, vals[2] * 1.12)
    ax.text(2, vals[2] * 0.5, f"schedule\nchange\n+{a['dQ']:,.0f}", ha="center", fontsize=7, color="white")
    ax.set_xticks(range(3), labels, fontsize=7.2); ax.set_ylabel("Q at θ_med")
    ax.set_title("Q-med: most of the rise is the model update", loc="left")
    style(ax, "y")
    ax = axs[1]
    vals2 = [a["r_min_current_updated"], a["r_min_new_updated"]]
    ax.bar(range(2), vals2, width=0.55, color=BLUE, edgecolor=SURF)
    for x, v in enumerate(vals2):
        ax.text(x, v, f"{v:,.0f}", ha="center", va="bottom", fontsize=7.5, color=INK)
    ax.axhline(a["r_star_updated_instance"], color=INK2, ls="--", lw=1)
    ax.text(1.35, a["r_star_updated_instance"], f"r* of updated\ninstance {a['r_star_updated_instance']:,.0f}", fontsize=6.8, color=INK2, va="bottom", ha="right")
    ax.set_xticks(range(2), ["Current", "New"], fontsize=7.5); ax.set_ylabel("Worst-case score (updated inputs)")
    ax.set_ylim(0, a["r_star_updated_instance"] * 1.22)
    ax.set_title("Worst case after REDEPLOY", loc="left")
    style(ax, "y")
    fig.tight_layout(); fig.savefig("out/fig5_redeploy.png", dpi=200); plt.close(fig)


# ---------- Fig 6: L2 emulation, worst-profile mean +/- sd ----------
def fig6():
    names = sorted(M, key=lambda n: M[n]["L2_emulated_worst_mean"])
    fig, ax = plt.subplots(figsize=(6.6, 5.0))
    for y, n in enumerate(names):
        m = M[n]; col = BLUE if n.startswith("RC2") else ORANGE
        th = min(m["L2_stochastic"], key=lambda t: m["L2_stochastic"][t]["Q_mean"])
        mu, sd = m["L2_stochastic"][th]["Q_mean"], m["L2_stochastic"][th]["Q_sd"]
        ax.plot([mu - sd, mu + sd], [y, y], color=col, lw=1.2, alpha=0.6)
        ax.plot(mu, y, "o", ms=7, mfc=col if m["feasible"] else "white", mec=col if not m["feasible"] else "white", mew=2 if not m["feasible"] else 1.2)
    ax.set_yticks(range(len(names)), [short(n).replace(" (repaired)", " (rep.)") for n in names], fontsize=7.2)
    ax.set_xlabel("Emulated score in the worst profile: mean ± 1 sd over 100 episodes (real TCP sockets)")
    ax.set_title("L2 emulation: worst-profile score over 100 episodes", loc="left")
    ax.set_xlim(left=0)
    style(ax); legend_family(ax, loc="lower right")
    fig.tight_layout(); fig.savefig("out/fig6_l2.png", dpi=200); plt.close(fig)


# ---------- Fig 7: sensitivity ----------
def fig7():
    runs = R["sensitivity"]["runs"]
    lab = [f"{r['param']} ×{r['factor']}" if r["param"] != "q_Finance" else "q(Finance) = 0.40" for r in runs]
    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    for y, r in enumerate(runs):
        ax.plot([r["base_schedule_r"], r["r_star"]], [y, y], color=GRID, lw=2)
        ax.plot(r["base_schedule_r"], y, "o", mfc="white", mec=BLUE, mew=2, ms=7)
        ax.plot(r["r_star"], y, "o", color=BLUE, ms=7, mec="white", mew=1.2)
        if r["base_schedule_regret_pct"] > 0.5:
            ax.text(r["r_star"] + 120, y, f"regret {r['base_schedule_regret_pct']:.1f}%", va="center", fontsize=7.2, color=INK2)
    ax.axvline(R["sensitivity"]["base_r_star"], color=INK2, ls=":", lw=1)
    ax.text(R["sensitivity"]["base_r_star"] + 40, -0.9, "base r*", fontsize=7, color=INK2, ha="left")
    ax.set_ylim(-1.2, len(runs) - 0.5)
    ax.set_yticks(range(len(runs)), lab)
    ax.set_xlabel("Worst-case score")
    ax.set_title("Sensitivity (±25%): re-solved r* vs original schedule re-scored", loc="left")
    ax.legend(handles=[Line2D([], [], marker="o", ls="", mfc=BLUE, mec="white", ms=7, label="New r* (re-solved)"),
                       Line2D([], [], marker="o", ls="", mfc="white", mec=BLUE, mew=2, ms=7, label="Original schedule, re-scored")],
              loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2, frameon=False, fontsize=7.5)
    style(ax)
    fig.tight_layout(); fig.savefig("out/fig7_sensitivity.png", dpi=200); plt.close(fig)


# ---------- Comparison table (RC2 max-min vs every baseline) ----------
def comparison():
    mm = M["RC2 max-min (r*)"]
    rows = []
    for b in BASES:
        raw, rep = M[b], M[b + " (repaired)"]
        rows.append([b, ", ".join(f"{k}×{len(v)}" for k, v in sorted(raw["violations"].items())),
                     f"{raw['r_min']:,.2f}", f"{rep['r_min']:,.2f}", str(rep["repair"]["changes"]),
                     f"{rep['scores']['med']['Q']:,.2f}", f"{raw['scores']['burst']['Burn_any_pct']:.1f}%",
                     f"{raw['scores']['med']['techniques']}/18", f"{mm['r_min'] / rep['r_min']:.2f}×"])
    rows.sort(key=lambda r: -float(r[3].replace(",", "")))
    rows.insert(0, ["RC2 max-min (r*)", "none (feasible)", f"{mm['r_min']:,.2f}", "—", "—", f"{mm['scores']['med']['Q']:,.2f}",
                    f"{mm['scores']['burst']['Burn_any_pct']:.1f}%", f"{mm['scores']['med']['techniques']}/18", "1.00×"])
    T = json.load(open("out/tables.json"))
    T["comparison"] = {"title": "Table C1. RC2 max-min against every baseline (raw = as produced; repaired = nearest feasible schedule)",
                       "header": ["Method", "Raw violations", "Raw worst-case", "Repaired worst-case", "Repair changes",
                                  "Repaired Q-med", "Raw burn θ_burst", "Raw techniques", "RC2 r* ÷ repaired worst-case"],
                       "rows": rows}
    json.dump(T, open("out/tables.json", "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    for f in (fig1, fig2, fig3, fig4, fig5, fig6, fig7, comparison):
        f()
    print("charts written")
