"""Optimization procedures on the WCNF encoding.

  weighted_pass   : one RC2 call, soft clauses weighted by the paper's layer weights (1000:100:70:10:12:1)
  tier_lex        : L4 > L3 > L2 > L1 strict priority at one profile. Implemented as one RC2 call with
                    BMO weights (each tier's unit weight exceeds the total of all lower tiers), which is
                    equivalent to four passes with hard floors; tier values are then re-verified by
                    explicit 4-pass floors in CP-SAT (cross_check.py).
  scenario_first  : V3 procedure: maximize Q_burst, then Q_high, Q_med, Q_low, each earlier optimum kept
                    as a PB hard floor (adder encoding); RC2 each pass.
  maxmin          : exact r* = max_x min_theta Q_theta(x) by binary search on T with incremental SAT;
                    optimum proven by SAT at T* and UNSAT at T*+1 (DRAT proof exported for UNSAT).
"""
import time
from pysat.examples.rc2 import RC2, RC2Stratified
from pysat.formula import WCNF, CNF
from pysat.solvers import Solver
from encoder import Enc, PB, TRUE, FALSE

TIER = {"L4": 3, "L3": 2, "L2": 1, "L1": 0}


def _obj_value(terms, model_set):
    return sum(w for (_, w, l) in terms if (l is TRUE) or (l in model_set))


def _rc2(hard, soft, stratified=True):
    w = WCNF()
    for c in hard:
        w.append(c)
    for lit, wt in soft:
        if wt > 0:
            w.append([lit], weight=wt)
    t0 = time.time()
    S = RC2Stratified if stratified else RC2
    with S(w, solver="g4", adapt=True, exhaust=True, minz=True) as rc2:
        m = rc2.compute()
        cost = rc2.cost
    return m, cost, time.time() - t0


def weighted_pass(enc, th):
    terms = enc.terms[th]
    m, cost, dt = _rc2(enc.hard, [(l, w) for (_, w, l) in terms])
    ms = set(x for x in m if x > 0)
    return {"schedule": enc.decode(m), "objective_int": _obj_value(terms, ms), "rc2_cost": cost, "seconds": dt}


def bmo_weights(terms):
    """Tier multipliers so that one unit of a higher tier outweighs everything below."""
    tot = {k: sum(w for (L, w, _) in terms if L == k) for k in TIER}
    mult, acc = {}, 0
    for k in sorted(TIER, key=TIER.get):  # L1, L2, L3, L4
        mult[k] = acc + 1
        acc += tot[k] * mult[k]
    return mult


def tier_lex_bmo(enc, th):
    """Single RC2 call with BMO weights (kept for reference; not used in results)."""
    terms = enc.terms[th]
    mult = bmo_weights(terms)
    m, cost, dt = _rc2(enc.hard, [(l, w * mult[L]) for (L, w, l) in terms])
    ms = set(x for x in m if x > 0)
    tiers = {k: sum(w for (L, w, l) in terms if L == k and (l is TRUE or l in ms)) for k in TIER}
    return {"schedule": enc.decode(m), "tiers_int": tiers, "objective_int": sum(tiers.values()), "seconds": dt}


def tier_lex(enc, th):
    """Four sequential RC2 passes at profile th: L4, then L3, L2, L1.
    Before each pass, every earlier tier's certified optimum is added as a hard PB floor
    (tier(x) >= tier*), so no lower-tier gain can reduce a higher tier."""
    terms = enc.terms[th]
    base_len = len(enc.hard)
    floor_units, tiers, passes, t0, m = [], {}, [], time.time(), None
    for k in ["L4", "L3", "L2", "L1"]:
        soft = [(l, w) for (L, w, l) in terms if L == k and l is not TRUE and l is not FALSE]
        const = sum(w for (L, w, l) in terms if L == k and l is TRUE)
        tp = time.time()
        m, cost, _ = _rc2(enc.hard + [[u] for u in floor_units], soft)
        ms = set(x for x in m if x > 0)
        val = const + sum(w for (l, w) in soft if l in ms)
        tiers[k] = val
        passes.append({"pass": len(passes) + 1, "tier": k, "optimum_int": val,
                       "floors_kept": [p["tier"] for p in passes], "seconds": round(time.time() - tp, 2)})
        g = PB(enc, [(w, l) for (l, w) in soft], "tierfloor_" + k).geq(val - const)
        if g is FALSE:
            raise RuntimeError("tier floor unsatisfiable")
        if g is not TRUE:
            floor_units.append(g)
    sched = enc.decode(m)
    del enc.hard[base_len:]
    return {"schedule": sched, "tiers_int": tiers, "objective_int": sum(tiers.values()),
            "passes": passes, "seconds": time.time() - t0}


def scenario_first(enc, order=("burst", "high", "med", "low")):
    base_len = len(enc.hard)
    floor_units, floors, t0, sched = [], {}, time.time(), None
    for th in order:
        terms = enc.terms[th]
        m, cost, _ = _rc2(enc.hard + [[u] for u in floor_units], [(l, w) for (_, w, l) in terms])
        ms = set(x for x in m if x > 0)
        val = _obj_value(terms, ms)
        floors[th] = val
        sched = enc.decode(m)
        pb = PB(enc, [(w, l) for (_, w, l) in terms], "floor_" + th)
        g = pb.geq(val)
        if g is FALSE:
            raise RuntimeError("floor unsatisfiable")
        if g is not TRUE:
            floor_units.append(g)
    del enc.hard[base_len:]
    return {"schedule": sched, "floors_int": floors, "seconds": time.time() - t0}


def maxmin(enc, proof_path=None, lb_hint=0):
    """Exact r*. Returns schedule, r*_int, and the UNSAT proof for T*+1."""
    t0 = time.time()
    base_len = len(enc.hard)
    pbs = {}
    for th, terms in enc.terms.items():
        pbs[th] = PB(enc, [(w, l) for (_, w, l) in terms], "mm_" + th)
    ub = min(p.maxsum for p in pbs.values())
    s = Solver(name="g4", bootstrap_with=enc.hard)
    added = len(enc.hard)
    act_cache = {}

    def check(T):
        nonlocal added
        lits = []
        for th, p in pbs.items():
            g = p.geq(T)
            if g is FALSE:
                return False, None
            if g is not TRUE:
                lits.append(g)
        for c in enc.hard[added:]:
            s.add_clause(c)
        added = len(enc.hard)
        ok = s.solve(assumptions=lits)
        return ok, (s.get_model() if ok else None)

    lo, best = lb_hint, None
    ok, m = check(lo)
    assert ok
    best = m
    hi = ub + 1  # invariant: lo feasible, hi infeasible
    calls = 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        ok, m = check(mid)
        calls += 1
        if ok:
            ms = set(x for x in m if x > 0)
            val = min(_obj_value(enc.terms[th], ms) for th in enc.terms)
            lo, best = max(mid, val), m
        else:
            hi = mid
    s.delete()
    rstar = lo
    # certificate: CNF + (sum_theta >= r*+1) is UNSAT; export CNF and DRAT proof
    cert = None
    if proof_path:
        cnf = CNF(from_clauses=list(enc.hard))
        for th, p in pbs.items():
            g = p.geq(rstar + 1)
            if g is FALSE:
                cnf.append([])  # trivially UNSAT
            elif g is not TRUE:
                cnf.append([g])
        cnf.extend(enc.hard[len(cnf.clauses) - len(pbs):] if False else [])
        # include any definitions created by the last geq calls
        extra = enc.hard[added:]
        for c in extra:
            cnf.append(c)
        cnf.to_file(proof_path + ".cnf")
        with Solver(name="g4", bootstrap_with=cnf.clauses, with_proof=True) as ps:
            res = ps.solve()
            proof = ps.get_proof()
        with open(proof_path + ".drat", "w") as fh:
            fh.write("\n".join(proof) + "\n")
        cert = {"unsat_at": rstar + 1, "solver_result": res, "cnf": proof_path + ".cnf",
                "drat": proof_path + ".drat", "proof_lines": len(proof), "cnf_vars": cnf.nv, "cnf_clauses": len(cnf.clauses)}
    del enc.hard[base_len:]  # drop PB definitions
    return {"schedule": enc.decode(best), "r_star_int": rstar, "sat_calls": calls, "seconds": time.time() - t0,
            "certificate": cert}
