import json, re
D = json.load(open("doc.json"))
srcs = ["results.json", "extra_e13.json", "extra_e2.json", "validation.json", "l2_paired.json", "vals.json", "tables.json"]
known = set()
def add_num(v):
    if isinstance(v, bool): return
    if isinstance(v, (int, float)):
        for f in (f"{v:,.2f}", f"{v:,.1f}", f"{v:,.0f}", f"{v:.2f}", f"{v:.1f}", f"{v:.0f}", f"{v:,}", str(v), f"{v/100:,.2f}", f"{v/60:.0f}", f"{v/60:.1f}"):
            known.add(f)
        for s in (f"{abs(v):,.0f}", f"{abs(v):,.2f}"): known.add(s)
def walk(o):
    if isinstance(o, dict): [walk(v) for v in o.values()]
    elif isinstance(o, list): [walk(v) for v in o]
    elif isinstance(o, (int, float)): add_num(o)
    elif isinstance(o, str):
        for tok in re.findall(r"\d[\d,]*\.?\d*", o): known.add(tok.rstrip(".,"))
for s in srcs:
    walk(json.load(open(f"/home/claude/zstp/out/{s}")))
# derived values used in the text
R = json.load(open("/home/claude/zstp/out/results.json")); M = {m["method"]: m for m in R["methods"]}
mm, tl = M["RC2 max-min (r*)"], M["RC2 tier-lex Q-med"]
best_raw = max((m for m in R["methods"] if m["state"] == "infeasible"), key=lambda m: m["r_min"])
best_rep = max((m for m in R["methods"] if m["state"] == "repaired"), key=lambda m: m["r_min"])
a = R["adaptive"]["controlled_REDEPLOY"]
derived = {
  "33.1": 100 * (mm["r_min"] - tl["r_min"]) / mm["r_min"], "9.4": 100 * (tl["scores"]["med"]["Q"] - mm["scores"]["med"]["Q"]) / tl["scores"]["med"]["Q"],
  "49.6": 100 * (mm["r_min"] / tl["r_min"] - 1), "1.46": mm["r_min"] / best_raw["r_min"], "1.80": mm["r_min"] / best_rep["r_min"],
  "6.3": 100 * (mm["r_min"] - M["RC2 burst-first (V3 §5.2)"]["r_min"]) / mm["r_min"],
  "17.2": 100 * (a["qmed_rule"]["r_min_old_updated"] - a["qmed_rule"]["r_min_new_updated"]) / a["qmed_rule"]["r_min_old_updated"],
  "31.4": 100 * (a["new_r_min"] / a["qmed_rule"]["r_min_new_updated"] - 1),
  "1,051.65": a["qmed_rule"]["dQ"], "6.4": a["qmed_rule"]["dQ_pct"], "28.8": None,
}
issues = []
for k, v in derived.items():
    if v is not None and f"{v:,.2f}"[:len(k)] != k and f"{v:.1f}" != k and f"{v:,.2f}" != k:
        issues.append(f"derived {k} -> computed {v:.3f}")
# numbers in prose
CONST = set("""0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 22 23 24 25 0.01 0.1 0.10 0.30 0.60 0.85 0.15 0.20 0.25 0.3 0.7 0.72 0.92 0.40 0.4 1,000 100 70 12 640 2.1 2.0 3.0 1.0 2.0 95 99 10,000 4,000 90,000 2026 1998 2003 2004 2006 2008 2011 2013 2014 2015 2017 2018 2019 2020 2021 2024 1.9 9.15 3.13 3.11 2.1 64 30 34 805 830 328 1,635 262,144 131 8,340 33,011""".split())
unk = []
for i, p in enumerate(D["paras"]):
    if p.startswith("[") and re.match(r"\[\d+\]", p): continue   # references
    for tok in re.findall(r"(?<![A-Za-z_])\d[\d,]*\.?\d*", p):
        t = tok.rstrip(".,")
        if t in known or t in CONST: continue
        ctx = p[max(0, p.find(tok) - 50): p.find(tok) + 40].replace("\n", " ")
        unk.append((t, ctx))
print("derived-value issues:", issues)
print("numbers not traced to a result file or a stated constant:", len(unk))
for t, c in unk: print(f"  {t:>10} | …{c}…")
