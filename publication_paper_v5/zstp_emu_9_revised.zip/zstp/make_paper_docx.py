"""Apply the verified revisions to the ZSTP paper (word/document.xml), in place."""
import json, re
from xml.sax.saxutils import escape

DOC = "u/word/document.xml"
x = open(DOC, encoding="utf-8").read()
R = json.load(open("/home/claude/zstp/out/results.json"))
P = json.load(open("/home/claude/zstp/out/l2_paired.json"))
M = {m["method"]: m for m in R["methods"]}


def rep(old, new, count=1):
    global x
    old_x, new_x = escape(old), escape(new)
    n = x.count(old_x)
    assert n == count, f"expected {count} of: {old[:70]!r}, found {n}"
    x = x.replace(old_x, new_x)


# ---------------- text corrections ----------------
rep("Under L2 process emulation with real TCP sockets and STIX 2.1 bundles, a deterministic replay reproduces every model score exactly.",
    "Under L2 process emulation with real TCP sockets and STIX 2.1 bundles, a deterministic replay reproduces every model score exactly, "
    "and with common random numbers the max–min schedule has a significantly higher emulated worst-profile score than 20 of the 22 other "
    "schedules (paired bootstrap, 95%). A validation suite — an exhaustive test of the adder encoding, a two-directional "
    "encoding-versus-checker test on 1,635 independently drawn schedules, CP-SAT cross-checks, exhaustive enumeration of a small "
    "instance, and four drat-trim-verified certificates — finds no disagreement.")

rep("an independent CP-SAT cross-check, exhaustive enumeration of a small instance, and full transparency",
    "an independent CP-SAT cross-check, exhaustive enumeration of a small instance, a reproducible validation test suite with paired "
    "statistics for the emulation, and full transparency")

rep("every path frequency is 0 (so C10a and C10b require nothing), the slot is valid, and with one slot no churn or burn rule applies.",
    "every path frequency is 0 (so C10a requires nothing), with one slot (H = 1 < W) C10b has no window, the slot is valid, and no "
    "churn or burn rule applies.")

# Table 3: describe the coefficients exactly as implemented
rep("Path-hop forward coverage across attack path π",
    "Path-hop coverage across attack path π; L3_fwd and L3_bwd are summed, so each covered hop earns weight 170")
rep("Path-hop backward credit (0.7× L3_fwd rate)", "Backward component of the same hop-coverage term (0.7× L3_fwd rate)")
rep("Number of distinct ATT&CK tactic families", "Distinct ATT&CK tactic families covered, each weighted by the sum of its technique weights")
rep("Number of distinct ATT&CK techniques covered", "Distinct ATT&CK techniques covered, each weighted by W_j")

# Section 5.2 timings from the final run
mms = M["RC2 max-min (r*)"]["solver"]
tls = M["RC2 tier-lex Q-med"]["solver"]
rep("the passes take 0.85 s in total", f"the passes take {tls['seconds']:.2f} s in total")
rep("(17 solver calls, 18.7 s)", f"({mms['sat_calls']} solver calls, {mms['seconds']:.1f} s)")

# Section 6.2: canonical re-solved schedule
a = R["adaptive"]["controlled_REDEPLOY"]
rep("The new schedule attains 9,352.53 (Q-med 15,237.92), passes the audit",
    f"The new schedule attains {a['new_r_min']:,.2f} (Q-med {a['new_Qmed']:,.2f}, the highest Q-med among all schedules that attain r*′), passes the audit")

# Section 7.1 provenance
rep("(code version 3bd3a071f2d1, instance hash 5cb2c5f369c5; Python 3.11, PySAT 1.9 with RC2 [9, 14], OR-Tools CP-SAT 9.15 [15], drat-trim [5]; 2 CPU cores, 7.5 minutes)",
    f"(code version {R['meta']['code_hash']}, instance hash {R['instance']['hash']}; Python 3.13, PySAT 1.9 with RC2 [9, 14], "
    f"OR-Tools CP-SAT 9.15 [15], drat-trim [5]; 2 CPU cores, under 2 GB of memory, {R['meta']['seconds'] / 60:.1f} minutes)")
rep("Validation is at L2: real TCP honeypot sockets, Bernoulli-governed attacker connection trials, and STIX bundles generated from observed connections.",
    "Validation is at L2: real TCP honeypot sockets, Bernoulli-governed attacker connection trials, and STIX bundles generated from observed "
    "connections. The attacker's random stream depends only on the instance, the profile and the episode, so every schedule faces the same "
    "attacker episodes (common random numbers) and schedules can be compared pairwise.")

# Section 7.5: emulation sentence
mm = M["RC2 max-min (r*)"]
sds = [v["Q_sd"] for v in mm["L2_stochastic"].values()]
rep("over 100 stochastic episodes per profile, the max–min schedule has the highest lowest-profile mean score (2,038), with a wide spread between episodes (standard deviation 931–1,153).",
    f"over 100 stochastic episodes per profile, the max–min schedule has the highest lowest-profile mean score "
    f"({mm['L2_emulated_worst_mean']:,.0f}), with a wide spread between episodes (standard deviation {min(sds):,.0f}–{max(sds):,.0f}); "
    f"Section 7.6 reports which differences are statistically significant.")
rep("on 64 random schedules, the score read from the encoding matched the independent evaluator for every profile;",
    "the encoding, the rule checker and the evaluator agree on every schedule tested (Section 7.6);")

# ---------------- new Section 7.6 ----------------
def run(text, bold=False, italic=False):
    rpr = ("<w:b/><w:bCs/>" if bold else "") + ("<w:i/><w:iCs/>" if italic else "")
    rpr = f"<w:rPr>{rpr}</w:rPr>" if rpr else ""
    return f'<w:r>{rpr}<w:t xml:space="preserve">{escape(text)}</w:t></w:r>'


def para(style, *runs, keep=False):
    kn = "<w:keepNext/>" if keep else ""
    return f'<w:p><w:pPr><w:pStyle w:val="{style}"/>{kn}</w:pPr>{"".join(runs)}</w:p>'


def cell(text, bold=False, w=0):
    tcw = f'<w:tcW w:w="{w}" w:type="dxa"/>' if w else '<w:tcW w:w="0" w:type="auto"/>'
    return (f'<w:tc><w:tcPr>{tcw}</w:tcPr>'
            f'<w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr>{run(text, bold)}</w:p></w:tc>')


def table(header, rows, widths):
    grid = "".join(f'<w:gridCol w:w="{w}"/>' for w in widths)
    hdr = ('<w:tr><w:trPr><w:cnfStyle w:val="100000000000" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" '
           'w:oddVBand="0" w:evenVBand="0" w:oddHBand="0" w:evenHBand="0" w:firstRowFirstColumn="0" w:firstRowLastColumn="0" '
           'w:lastRowFirstColumn="0" w:lastRowLastColumn="0"/><w:tblHeader/></w:trPr>'
           + "".join(cell(h, True, w) for h, w in zip(header, widths)) + "</w:tr>")
    body = "".join("<w:tr><w:trPr><w:cantSplit/></w:trPr>" + "".join(cell(c, False, w) for c, w in zip(r, widths)) + "</w:tr>" for r in rows)
    return (f'<w:tbl><w:tblPr><w:tblStyle w:val="Table"/><w:tblW w:w="{sum(widths)}" w:type="dxa"/><w:tblLayout w:type="fixed"/>'
            '<w:tblLook w:val="0020" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="0"/>'
            f'</w:tblPr><w:tblGrid>{grid}</w:tblGrid>{hdr}{body}</w:tbl>')


mi = R["micro"]
det = [v for m in R["methods"] for v in m["L2_deterministic"].values()]
n_sched_det = len(R["methods"])
cc = R["cross_check"]
certs = [mm["solver"]["certificate"], mi["certificate"]] + [v["certificate"] for v in R["adaptive"].values()]
assert all(c["drat_check"].get("verified") for c in certs)
assert all(cc["agree"].values()) and mi["match_r_star"] and mi["match_lex"] and mi["match_weighted"]
assert all(v["match"] for v in det)
tb = M["RC2 max-min + Q-med tie-break"]
assert tb["schedule"] == mm["schedule"]

tests = [
    ["Adder pseudo-Boolean encoding", "120 random weighted sums (1–8 literals, weights up to 90,000); every input assignment × every threshold 0…max+1", "0 errors"],
    ["Encoding vs. rule checker, both directions", "1,635 schedules drawn independently of the solver (805 small-instance, 830 XLarge; 328 feasible): random subsets, one-step mutations of feasible schedules, the ten raw baselines", "0 feasibility mismatches; 0 score mismatches (4 profiles)"],
    ["Encoding vs. evaluator on solver-completed schedules", "64 feasible schedules (30 XLarge, 34 small-instance), 4 profiles", "0 mismatches"],
    ["Independent CP-SAT model", "r*, the four Q-med tier optima, weighted Q-med optimum", "all OPTIMAL and equal"],
    ["Exhaustive enumeration (small instance)", f"{mi['subsets_enumerated']:,} subsets, {mi['feasible_schedules']} feasible", f"r* = {mi['enum_r_star']:,.2f} by enumeration, SAT and CP-SAT; tier-lex and weighted optima equal"],
    ["DRAT optimality certificates (unsatisfiability proofs)", f"XLarge r* (CNF {mm['solver']['certificate']['cnf_vars']:,} variables, {mm['solver']['certificate']['cnf_clauses']:,} clauses; proof {mm['solver']['certificate']['proof_lines']:,} lines), small-instance r*, both Algorithm 1 re-solves", "4 of 4 verified by drat-trim [5]"],
    ["L2 deterministic replay", f"{n_sched_det} schedules (13 reported, 10 repaired baselines, 1 tie-break check) × 4 profiles, {sum(v['connections'] for v in det):,} connections", f"log score = evaluator score in {len(det)} of {len(det)} cases"],
    ["Hard-rule audit", "every RC2 and repaired schedule, both Algorithm 1 outcomes", "0 violations"],
    ["Uniqueness of the reported optimum", "maximize Q-med subject to Q_θ ≥ r* for every θ", "returns the reported max–min schedule"],
    ["Reproducibility", "two complete runs of the same code", "identical results apart from timing fields"],
]

order = ["RC2 tier-lex Q-med", "RC2 burst-first (V3 §5.2)", "Greedy-Diverse", "Greedy-Diverse (repaired)", "Max-PathCov", "LP-Relaxation",
         "Static-Best", "Greedy-BiDir", "Random", "Round-Robin", "ThreatIntel-Only", "Single-Zone", "Greedy-HighRho"]
Pd = {r["B"]: r for r in P}


TH4 = ["low", "med", "high", "burst"]


def l2cells(name):
    s = M[name]["L2_stochastic"]; worst = min(s, key=lambda t: s[t]["Q_mean"])
    return [f"{s[t]['Q_mean']:,.0f}" + ("*" if t == worst else "") for t in TH4]


short = lambda n: n.replace("RC2 tier-lex Q-med", "RC2 Q-med (4 passes)").replace(" (V3 §5.2)", "")
l2rows = [["★ RC2 max–min (r*)"] + l2cells("RC2 max-min (r*)") + ["—", "—"]]
for n in order:
    r = Pd[n]
    l2rows.append([short(n) + ("" if M[n]["feasible"] else " †")] + l2cells(n) +
                  [f"{r['diff']:+,.0f} [{r['ci95'][0]:+,.0f}, {r['ci95'][1]:+,.0f}]", "yes" if r["A_better_95"] else "no"])
ci_max = max(v["Q_ci95_half"] for m in R["methods"] for v in m["L2_stochastic"].values())
A_l2 = M["RC2 max-min (r*)"]["L2_stochastic"]
others = [n for n in M if n not in ("RC2 max-min (r*)", "RC2 max-min + Q-med tie-break")]
beat = {t: [n for n in others if M[n]["L2_stochastic"][t]["Q_mean"] > A_l2[t]["Q_mean"]] for t in TH4}
nm = lambda n: short(n).replace(" (repaired)", " after repair") + ("" if M[n]["feasible"] else " as produced")
n_sig = sum(1 for r in P if r["A_better_95"])
n_cmp = sum(1 for r in P if r["B"] != "RC2 max-min + Q-med tie-break")
gd, qm = Pd["Greedy-Diverse"], Pd["RC2 tier-lex Q-med"]
reps = [m for m in R["methods"] if m["state"] == "repaired"]
best_rep = max(reps, key=lambda m: m["r_min"])
chg = sorted(m["repair"]["changes"] for m in reps)

new = "".join([
    para("Heading3", run("7.6 Validation Test Suite and Statistics")),
    para("FirstParagraph", run(
        "The certificate proves optimality of the CNF, so its value depends on the CNF encoding the model correctly. Table 6 lists the tests "
        "that check this and the other claims, all run on the final code. Two tests go beyond Section 7.5. The adder encoding of Q_θ(x) ≥ T, on which "
        "the max–min search, the tier floors and every certificate rest, is checked exhaustively against arithmetic. The hard-clause layer is "
        "compared with the independent rule checker in both directions, on schedules drawn without the solver, so an encoding that wrongly "
        "excluded a valid schedule would be detected as well as one that admitted an invalid schedule.")),
    para("BodyText", run("Table 6.", bold=True), run(" Validation tests (final code, one pipeline run; scripts in the supplementary material)."), keep=True),
    table(["Test", "Scope", "Result"], tests, [2500, 4200, 2660]),
    para("BodyText", run(
        "Several schedules attain r*, so a schedule's secondary scores could depend on which optimum the solver returns. Maximizing Q-med "
        "subject to Q_θ ≥ r* for every θ returns exactly the reported max–min schedule, so its scores in Tables 4 and 5 are those of the "
        "best-Q-med optimum. The same tie-break is applied to the Algorithm 1 re-solves (Section 6.2).")),
    para("BodyText", run(
        f"Table 7 reports the L2 stochastic emulation with paired statistics. Each profile column is the mean emulated score over 100 "
        f"episodes (95% confidence half-width at most {ci_max:,.0f}); an asterisk marks the schedule's lowest profile. The difference column "
        f"compares these lowest-profile means: the max–min schedule's value minus the schedule's value, with a 95% paired-bootstrap interval "
        f"(10,000 replicates, episodes resampled jointly). The max–min schedule is "
        f"significantly higher than {n_sig} of the {n_cmp} other schedules, including every feasible baseline after repair. Two differences are "
        f"not significant: Greedy-Diverse as produced ({gd['diff']:+,.0f}, interval {gd['ci95'][0]:+,.0f} to {gd['ci95'][1]:+,.0f}), which "
        f"breaks C12 and C14, and the RC2 Q-med schedule ({qm['diff']:+,.0f}, interval {qm['ci95'][0]:+,.0f} to {qm['ci95'][1]:+,.0f}). "
        f"Under the Bernoulli attacker the max–min schedule's weakest profile is θ_low rather than θ_high, because a low-rate attacker "
        f"probes few honeypots per episode; the emulation therefore complements the model rather than reproducing its worst case.")),
    para("BodyText", run(
        f"Profile by profile the picture is mixed, as expected of a max–min objective, which protects the weakest profile rather than "
        f"each profile. Under θ_high only {', '.join(nm(n) for n in beat['high']) or 'no schedule'} and under θ_burst only "
        f"{', '.join(nm(n) for n in beat['burst']) or 'no schedule'} have a higher emulated mean than the max–min schedule, but under θ_low "
        f"{len(beat['low'])} and under θ_med {len(beat['med'])} of the {len(others)} other schedules do. In the model scores of Table 4 the "
        f"max–min schedule leads every baseline under all four profiles; the emulation, in which a probe or attack happens only with the "
        f"profile's probability, does not reproduce that per-profile lead under the low-rate profiles.")),
    para("BodyText", run("Table 7.", bold=True), run(
        " L2 stochastic emulation: mean emulated score under θ_low, θ_med, θ_high and θ_burst over 100 episodes (common random numbers; * = lowest profile), "
        "and the paired difference of lowest-profile means from the max–min schedule. † = breaks at least one hard rule as produced."), keep=True),
    table(["Schedule", "Low", "Med", "High", "Burst", "Max–min minus schedule [95% CI]", "Max–min higher (95%)"],
          l2rows, [2200, 960, 960, 960, 960, 2280, 1040]),
    para("BodyText", run(
        f"Baselines repaired to the nearest feasible schedule (RC2 minimizing the number of changed deployments; {chg[0]}–{chg[-1]} changes) "
        f"follow every hard rule, and their worst-case scores range from {min(m['r_min'] for m in reps):,.2f} to {best_rep['r_min']:,.2f} "
        f"({best_rep['method'].replace(' (repaired)', '')}); r* is {mm['r_min'] / best_rep['r_min']:.2f}× the best of them, against "
        f"1.46× the best baseline as produced.")),
])

# insert before the Conclusion heading
k = x.find(">8. Conclusion<")
assert k > 0
ps = x.rfind("<w:p ", 0, k)
x = x[:ps] + new + x[ps:]

# conclusion: mention the validation suite
rep("Three architectural refinements — the persona decomposition P ⊆ R̂ × F, the C10a/C10b path-constraint split, and the four-pass tier-lexicographic strategy — enable this result",
    "A validation suite finds no disagreement between the encoding, the independent rule checker, the evaluator and an independent CP-SAT "
    "model, and the emulated advantage is significant against every feasible baseline. Three architectural refinements — the persona "
    "decomposition P ⊆ R̂ × F, the C10a/C10b path-constraint split, and the four-pass tier-lexicographic strategy — enable this result")
rep("several instance values (attack-path steps, technique maps, plausibility tables, path emphasis) are documented defaults whose change alters the optimum.",
    "several instance values (attack-path steps, technique maps, plausibility tables, path emphasis) are documented defaults whose change "
    "alters the optimum. The evaluation uses one instance, and with one fingerprint per role it does not exercise fingerprint rotation "
    "within a role; an instance family with several fingerprints per role would test both scale and the persona decomposition.")


# =================== round 2: reader-friendly comparison, figures, validity ===================
import os, shutil, struct

def insert_before_para(anchor, xml):
    """Insert xml before the paragraph containing anchor text."""
    global x
    k = x.find(escape(anchor)); assert k > 0, anchor
    ps = x.rfind("<w:p ", 0, k); x = x[:ps] + xml + x[ps:]

def insert_after_para(anchor, xml):
    global x
    k = x.find(escape(anchor)); assert k > 0, anchor
    pe = x.find("</w:p>", k) + len("</w:p>"); x = x[:pe] + xml + x[pe:]

# ---- figures
os.makedirs("u/word/media", exist_ok=True)
rels = open("u/word/_rels/document.xml.rels", encoding="utf-8").read()
ct = open("u/[Content_Types].xml", encoding="utf-8").read()
if 'Extension="png"' not in ct:
    ct = ct.replace("<Default Extension=\"xml\"", '<Default Extension="png" ContentType="image/png"/><Default Extension="xml"', 1)
    open("u/[Content_Types].xml", "w", encoding="utf-8").write(ct)

def figure(src, rid, fid, width_in):
    shutil.copy(src, f"u/word/media/{os.path.basename(src)}")
    global rels
    rels = rels.replace("</Relationships>", f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/{os.path.basename(src)}"/></Relationships>')
    w, h = struct.unpack(">II", open(src, "rb").read()[16:24])
    cx = int(width_in * 914400); cy = int(cx * h / w)
    A = "http://schemas.openxmlformats.org/drawingml/2006/main"; PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture"
    return (f'<w:p><w:pPr><w:pStyle w:val="CaptionedFigure"/><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
            f'<wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="{fid}" name="Figure {fid}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="{A}" noChangeAspect="1"/></wp:cNvGraphicFramePr>'
            f'<a:graphic xmlns:a="{A}"><a:graphicData uri="{PIC}"><pic:pic xmlns:pic="{PIC}"><pic:nvPicPr><pic:cNvPr id="0" name="{os.path.basename(src)}"/><pic:cNvPicPr/></pic:nvPicPr>'
            f'<pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>')

fig1 = figure("/home/claude/zstp/out/fig1_worstcase.png", "rIdFig1", 9001, 6.0)
fig2 = figure("/home/claude/zstp/out/fig3_tradeoff.png", "rIdFig2", 9002, 6.0)
open("u/word/_rels/document.xml.rels", "w", encoding="utf-8").write(rels)

rep("θ_burst is the binding profile for only 3 of the 13 schedules.",
    "θ_burst is the binding profile for only 3 of the 13 schedules. Figure 1 shows the worst case of every schedule, with each baseline "
    "both as produced and after repair to the nearest feasible schedule, and Table 8 (Section 7.6) summarizes each baseline in one row.")
insert_after_para("θ_burst is the binding profile for only 3 of the 13 schedules.",
    fig1 + para("ImageCaption", run("Figure 1.", bold=True), run(
        " Worst-case score min_θ Q_θ of every schedule (common evaluator). Hollow: baseline as produced (breaks at least one hard rule); "
        "filled orange: the same baseline after minimum-change repair; blue: RC2 procedures. Every repaired baseline stays below r*.")))
insert_after_para("which is the price of protecting the worst case.",
    fig2 + para("ImageCaption", run("Figure 2.", bold=True), run(
        " Q at θ_med against the worst-case score for every schedule. The Q-med objective and the robust objective pick different "
        "schedules; no baseline, as produced or repaired, is better than the max–min schedule on either axis.")))

# ---- Table 8: baselines at a glance
glance = []
for b in [n for n in M if not n.startswith("RC2") and M[n]["state"] != "repaired"]:
    raw_, rp = M[b], M.get(b + " (repaired)", M[b])
    pr = Pd[rp["method"]]
    glance.append([b, ", ".join(f"{k}×{len(v)}" for k, v in sorted(raw_["violations"].items())) or "none",
                   f"{raw_['r_min']:,.2f}", f"{rp['r_min']:,.2f} ({rp.get('repair', {}).get('changes', 0)})",
                   f"{mm['r_min'] / rp['r_min']:.2f}×", f"{pr['diff']:+,.0f} [{pr['ci95'][0]:+,.0f}, {pr['ci95'][1]:+,.0f}]"])
glance.sort(key=lambda r: -float(r[3].split(" ")[0].replace(",", "")))
glance.insert(0, ["★ RC2 max–min (r*)", "none", f"{mm['r_min']:,.2f}", "— (feasible)", "1.00×", "—"])
best_raw_q = max(M[n]["r_min"] for n in M if not n.startswith("RC2") and M[n]["state"] != "repaired")
insert_after_para("1.46× the best baseline as produced.",
    para("BodyText", run("Table 8.", bold=True), run(
        " Baselines at a glance: rules broken as produced, worst-case score as produced and after minimum-change repair (number of changed "
        "deployments), r* divided by the repaired worst case, and the paired L2 difference (max–min minus the repaired schedule, lowest-profile "
        "means, 95% CI). Sorted by repaired worst case."), keep=True) +
    table(["Baseline", "Rules broken (as produced)", "Worst case as produced", "Worst case repaired (changes)", "r* ÷ repaired", "L2: max–min minus repaired [95% CI]"],
          glance, [1650, 1650, 1250, 1550, 1250, 2010]))

# ---- 7.7 Threats to validity (before the Conclusion heading)
sens = R["sensitivity"]["runs"]
reg = sorted(r["base_schedule_regret_pct"] for r in sens if r["param"] != "q_Finance")
validity = "".join([
    para("Heading3", run("7.7 Threats to Validity")),
    para("FirstParagraph", run("Internal validity. ", bold=True), run(
        "A certificate is only as sound as the encoding it certifies. The encoding is checked against an independently written rule checker "
        "and evaluator in both directions, against an independent CP-SAT model, against exhaustive enumeration, and its adder arithmetic is "
        "tested exhaustively (Table 6); none of these checks found a disagreement.")),
    para("BodyText", run("Construct validity. ", bold=True), run(
        "The score is a model: the technique map, attack-path steps, plausibility tables, path emphasis ω and the layer weights are documented "
        "defaults rather than measured values, and coefficients are rounded to 0.01. Under ±25% changes to path frequencies, interception "
        f"values, technique weights and the L4 weight, the original max–min schedule stays within {reg[-2]:.2f}% of the re-solved optimum in "
        f"{len(reg) - 1} of {len(reg)} cases and within {reg[-1]:.2f}% in the remaining one (Section 7.4).")),
    para("BodyText", run("Baseline fairness. ", bold=True), run(
        "The heuristic baselines optimize a single, burn-blind profile and are not given every hard rule, which is how such heuristics are "
        "normally used; this favours the certified method. We therefore report every baseline both as produced and after minimum-change "
        f"repair by the same solver, and the max–min schedule keeps a {mm['r_min'] / best_rep['r_min']:.2f}× worst-case advantage over the best "
        "repaired baseline. A burn-aware, rule-aware heuristic was not evaluated.")),
    para("BodyText", run("External validity. ", bold=True), run(
        "Results come from one instance (640 decisions, four slots, four personas) and four discrete attacker profiles. Validation is at L2: the "
        "attacker is a Bernoulli process on loopback sockets, not real attacker tooling, and with one fingerprint per role the evaluation does "
        "not exercise fingerprint rotation within a role.")),
    para("BodyText", run("Statistical validity. ", bold=True), run(
        "Emulation comparisons use common random numbers and paired bootstrap intervals over 100 episodes per profile; two of the 22 "
        "comparisons (Greedy-Diverse as produced and the RC2 Q-med schedule) are not significant at 95% and are reported as such. Model "
        "scores, the certificate and all rule checks are deterministic, and two complete runs give identical results.")),
])
insert_before_para("8. Conclusion", validity)

# ---- data and code availability (before References)
insert_before_para("References", para("Heading2", run("Data and Code Availability")) + para("FirstParagraph", run(
    f"The implementation (instance construction, encoder, solvers, CP-SAT cross-check, baselines, evaluator, L2 emulator and the validation "
    f"tests), the results file, the DRAT certificates and the STIX bundles are provided as supplementary material. A single command "
    f"regenerates every number, table and figure in this paper (code version {R['meta']['code_hash']}, instance hash {R['instance']['hash']}).")))

# ---- claim qualifier in the abstract
rep("which scores higher than every baseline under all four profiles (1.46× the best baseline's worst case).",
    f"which in the model scores higher than every baseline under all four profiles (1.46× the best baseline's worst case as produced and "
    f"{mm['r_min'] / best_rep['r_min']:.2f}× after the baselines are repaired to follow every rule).")


# =================== round 3: DRAT / drat-trim only in Table 6 ===================
for old, new in [
    ("which emits a machine-checkable optimality certificate (a DRAT proof verified independently by drat-trim).",
     "which emits a machine-checkable optimality certificate that is verified independently (Table 6)."),
    ("and four drat-trim-verified certificates — finds no disagreement.",
     "and independent verification of four optimality certificates — finds no disagreement."),
    ("an optimality certificate: an unsatisfiability proof in DRAT format, checked by the independent tool drat-trim [5], showing that",
     "an optimality certificate: an unsatisfiability proof, checked by an independent proof checker (Table 6), showing that"),
    ("with an optimality certificate verified by drat-trim [5]; on the test instance",
     "with an independently verified optimality certificate; on the test instance"),
    ("and certifies it with a DRAT proof, verified by drat-trim [5], that no feasible schedule reaches r* + 0.01.",
     "and certifies it with an independently verified unsatisfiability proof that no feasible schedule reaches r* + 0.01."),
    ("The optimality certificate is the exported CNF with the claim Q_θ(x) ≥ r* + 0.01 for every θ (52,386 variables, 277,714 clauses) together with its DRAT refutation (75,708 lines), verified by drat-trim.",
     "The optimality certificate is the exported CNF with the claim Q_θ(x) ≥ r* + 0.01 for every θ together with its refutation proof; its size and verification are reported in Table 6."),
    ("the audit of every hard rule by the independent rule checker and drat-trim verification of the new certificate",
     "the audit of every hard rule by the independent rule checker and independent verification of the new certificate"),
    ("and verify its certificate with drat-trim before pushing it to the deployment controller.",
     "and verify its certificate with an independent proof checker before pushing it to the deployment controller."),
    ("passes the audit of every hard rule, and its certificate is verified by drat-trim.",
     "passes the audit of every hard rule, and its certificate is verified (Table 6)."),
    ("OR-Tools CP-SAT 9.15 [15], drat-trim [5];", "OR-Tools CP-SAT 9.15 [15];"),
    ("reaches min_θ Q_θ(x) ≥ 7,052.63, and it was verified by drat-trim.",
     "reaches min_θ Q_θ(x) ≥ 7,052.63, and it was verified independently (Table 6)."),
    ("for four modeled attacker profiles, with a certificate verified by drat-trim, while following every hard rule.",
     "for four modeled attacker profiles, with an independently verified certificate, while following every hard rule."),
    ("the results file, the DRAT certificates and the STIX bundles", "the results file, the optimality certificates (CNF and proof files) and the STIX bundles"),
]:
    rep(old, new)

open(DOC, "w", encoding="utf-8").write(x)
print("ok")
