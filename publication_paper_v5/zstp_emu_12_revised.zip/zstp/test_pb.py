"""Exhaustive test of the adder-based PB encoding (encoder.PB) used by the max-min search,
the tier floors and the DRAT certificate.

For random weighted sums over n <= 8 literals, every assignment of the literals and every
threshold T in [0, maxsum+1] is checked: the literal returned by geq(T) must be true exactly
when sum(w_i * l_i) >= T. Because the PB definitions are full equivalences, the check is done
by fixing the inputs with assumptions and asking the SAT solver for both values of geq(T).
"""
import itertools, random
from pysat.solvers import Solver
import encoder
from encoder import PB, TRUE, FALSE


class _Stub:
    """Minimal stand-in for encoder.Enc: a variable pool and a clause list."""
    def __init__(self, n):
        from pysat.formula import IDPool
        self.pool = IDPool(start_from=n + 1)
        self.hard = []
    fresh = encoder.Enc.fresh
    v = encoder.Enc.v
    OR = encoder.Enc.OR
    AND = encoder.Enc.AND


def check_case(weights, rnd):
    n = len(weights)
    lits = list(range(1, n + 1))
    enc = _Stub(n)
    pb = PB(enc, list(zip(weights, lits)), "t")
    maxsum = sum(weights)
    Ts = list(range(0, maxsum + 2)) if maxsum <= 60 else sorted({0, 1, maxsum, maxsum + 1, *rnd.sample(range(maxsum), 40)})
    g = {T: pb.geq(T) for T in Ts}
    errors = 0
    with Solver(name="g4", bootstrap_with=enc.hard) as s:
        for bits in itertools.product([0, 1], repeat=n):
            assum = [l if b else -l for l, b in zip(lits, bits)]
            total = sum(w for w, b in zip(weights, bits) if b)
            for T, lit in g.items():
                want = total >= T
                if lit is TRUE or lit is FALSE:
                    ok = (lit is TRUE) == want
                else:
                    # the definition must force lit to the correct value
                    ok = s.solve(assumptions=assum + [lit if want else -lit]) and \
                         not s.solve(assumptions=assum + [-lit if want else lit])
                if not ok:
                    errors += 1
                    print("PB MISMATCH", weights, bits, T, total)
    return errors


def main(cases=120, seed=11):
    import testlog
    rnd = random.Random(seed)
    errs = 0; max_n = max_w = 0
    for _ in range(cases):
        n = rnd.randint(1, 8)
        hi = rnd.choice([3, 20, 400, 90000])          # small and coefficient-sized weights
        weights = [rnd.randint(1, hi) for _ in range(n)]
        max_n = max(max_n, n); max_w = max(max_w, hi)
        errs += check_case(weights, rnd)
    print(f"PB adder: {cases} random sums, exhaustive over inputs and thresholds, errors = {errs}")
    testlog.record("pb_adder", {"cases": cases, "max_literals": max_n, "max_weight_bound": max_w, "errors": errs})
    return errs


if __name__ == "__main__":
    raise SystemExit(1 if main() else 0)
