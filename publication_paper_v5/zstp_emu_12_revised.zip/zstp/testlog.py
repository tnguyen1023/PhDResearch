"""Shared helper: tests record their results in out/tests.json so the paper reads them from a file."""
import json, os, time


def record(name, result):
    os.makedirs("out", exist_ok=True)
    path = "out/tests.json"
    data = json.load(open(path)) if os.path.exists(path) else {}
    data[name] = {**result, "recorded": time.strftime("%Y-%m-%d %H:%M:%S")}
    json.dump(data, open(path, "w"), indent=1)
