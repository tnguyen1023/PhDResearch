# ZSTP rerun — independent reimplementation

Reimplements the ZSTP honeypot-scheduling model from the paper's equations and produces every
reported number from results files written by one command (reproduce.py).

    pip install python-sat ortools scipy matplotlib python-docx
    git clone https://github.com/marijnheule/drat-trim /tmp/drat-trim && make -C /tmp/drat-trim

    python3 reproduce.py    # ONE command: every number, table and figure in the paper (~42 min on 2 cores)
                            # (--quick skips the H-scaling study and the second compared run, ~15 min)

reproduce.py runs, in order (each step reads only files written by earlier steps):
    python3 run_all.py      # ~7 min on 2 cores, < 2 GB RAM -> out/results.json (+ certificates, STIX bundles)
    python3 tables.py       # every table -> out/tables.md, out/table_*.csv, out/tables.json
    python3 l2_stats.py     # paired bootstrap comparison of the L2 emulation (Table R3b)
    python3 charts.py       # comparison table C1 + figures out/fig1..fig7 (from results.json only)
    python3 vals.py         # named values quoted in the paper text -> out/vals.json
    python3 validate_contributions.py   # emulation vs reference simulator, STIX, paper values, 4 passes, NP reduction -> out/validation.json
    EXTRA_OUT=out/extra_e13.json python3 extra_experiments.py e1 e3   # robust heuristics, persona rotation
    EXTRA_OUT=out/extra_e2.json  python3 extra_experiments.py e2      # horizon scaling H = 4, 5, 6, 8
    python3 make_paper_docx.py  # (run from a folder with the unpacked paper) applies every paper revision from the results

    python3 test_pb.py / test_encoding_vs_checker.py / test_consistency.py   -> out/tests.json
    python3 check_reproducible.py   # second run_all.py in a scratch folder, compared -> out/repro.json

Every number in the paper is read from out/*.json by make_paper_docx.py; audit/ re-checks the finished
.docx against those files (every table cell, every number in the text, every cross-reference).

Tests (each exits non-zero on failure):

    python3 test_pb.py                  # adder PB encoding exact on every input and threshold (random sums)
    python3 test_encoding_vs_checker.py # hard layer == rule checker in BOTH directions, scores == evaluator
    python3 test_consistency.py         # encoder vs evaluator on solver-completed feasible schedules
    drat-trim out/maxmin_xlarge.cnf out/maxmin_xlarge.drat   # optimality certificate check

| File | Role |
|---|---|
| instance.py | XLarge and micro instances; U11 thresholds; integer coefficients. Values the paper does not state are marked DEFAULT. |
| evaluator.py | Common evaluator (burn, coverage, scores, metrics) and independent hard-constraint checker |
| encoder.py | WCNF encoding with per-profile burn states; adder-based PB encoding |
| solvers.py | RC2 weighted pass, four-pass tier-lexicographic with PB floors, burst-first with floors, exact max-min (SAT binary search + DRAT), optional Q-med tie-break among r* optima |
| cross_check.py | Independent CP-SAT model: max-min, lexicographic passes with floors, weighted, zero-burn feasibility |
| baselines.py | Ten baselines + nearest-feasible repair |
| micro.py | Exhaustive micro-instance validation |
| adaptive.py | Algorithm 1 exactly as in the paper: deployed max-min schedule, robust re-solve, KEEP iff it still attains r*′, checker + drat-trim gate; earlier Q-med rule reported for comparison |
| emulation_l2.py | L2 process emulation: asyncio TCP honeypots, Bernoulli attackers, STIX 2.1 bundles |
| validate_contributions.py | Independent reference simulator for the emulation (9,600 episodes), draw-frequency tests, STIX checks, paper-stated values, four-pass floors, NP-hardness reduction on random max-k-coverage |
| extra_experiments.py | Robust greedy and robust local search (worst-case objective), horizon scaling with certificates, two fingerprints per role |
| run_all.py | Single entry point; run IDs = hash(instance, method, code). L2 seeds = hash(instance, profile, episode) only (common random numbers) |

Two complete runs of the same code produce identical results.json apart from timing fields.
