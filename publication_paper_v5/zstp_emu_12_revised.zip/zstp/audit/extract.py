import docx, json
d = docx.Document("/home/claude/pap/ZSTP_V4_verified.docx")
paras = [p.text for p in d.paragraphs]
tables = [[[c.text for c in r.cells] for r in t.rows] for t in d.tables]
json.dump({"paras": paras, "tables": tables}, open("doc.json", "w"), ensure_ascii=False, indent=0)
print(len(paras), "paragraphs,", len(tables), "tables")
for i, t in enumerate(tables): print(i, t[0][:4], len(t), "rows")
