import json, re
D = json.load(open("doc.json")); T = D["tables"]
R = json.load(open("/home/claude/zstp/out/results.json")); M = {m["method"]: m for m in R["methods"]}
raw = [m for m in R["methods"] if m["state"] == "infeasible"]
issues = []
f2 = lambda v: f"{v:,.2f}"
def chk(where, got, want):
    if got.strip() != want:
        issues.append(f"{where}: paper '{got}' vs results '{want}'")
# ---- Table 4
name = {"★ RC2 max–min (r*)": "RC2 max-min (r*)", "RC2 Q-med (4 passes)": "RC2 tier-lex Q-med", "RC2 burst-first": "RC2 burst-first (V3 §5.2)"}
for row in T[3][1:]:
    n = name.get(row[0], row[0]); m = M[n]
    for k, th in enumerate(["low", "med", "high", "burst"]):
        chk(f"T4 {row[0]} {th}", row[1 + k], f2(m["scores"][th]["Q"]))
    chk(f"T4 {row[0]} worst", row[5], f"{f2(m['r_min'])} ({m['worst_profile']})")
    want = "all pass" if not m["violations"] else ", ".join(f"{c}×{len(v)}" for c, v in m["violations"].items())
    got_set = set(x.strip() for x in row[7].split(",")); want_set = set(x.strip() for x in want.split(","))
    if got_set != want_set: issues.append(f"T4 {row[0]} rules: '{row[7]}' vs '{want}'")
    chk(f"T4 {row[0]} certificate", row[6], "YES" if n == "RC2 max-min (r*)" else "NO")
# ---- Table 5
short = {"RC2": "RC2 max-min (r*)", "G-BiDir": "Greedy-BiDir", "R-Robin": "Round-Robin", "S-Best": "Static-Best", "LP": "LP-Relaxation",
         "Rnd": "Random", "S-Zone": "Single-Zone", "G-Div": "Greedy-Diverse", "ThrI": "ThreatIntel-Only", "MaxPC": "Max-PathCov", "G-HiRho": "Greedy-HighRho"}
hdr = T[4][0]
for row in T[4][1:]:
    metric = row[0]
    for col, cell in zip(hdr[1:], row[1:]):
        m = M[short[col]]; s, st = m["scores"], m["static"]
        want = {"Worst-case": f2(m["r_min"]), "Q-med": f2(s["med"]["Q"]), "ATT&CK Tech": f"{s['med']['techniques']}/18",
                "Tactic Families": f"{s['med']['families']}/8", "Path Persist C10%": f"{st['path_persistence_pct']:.0f}%",
                "Hop Coverage%": f"{s['med']['hop_coverage_pct']:.1f}%", "Early-Intercept%": f"{s['med']['early_intercept_pct']:.1f}%",
                "Rule violations": str(sum(len(v) for v in m["violations"].values())), "Zone Spread%": f"{st['zone_spread_pct']:.0f}%",
                "Persona Div%": f"{st['persona_diversity_pct']:.0f}%", "PBurn% (lower↓)": f"{s['burst']['PBurn_pct']:.1f}%",
                "TBurn% (lower↓)": f"{s['burst']['TBurn_pct']:.1f}%", "C14 X-Zone Leaks": str(st["C14_leaks"]),
                "FM-avg": f"{s['burst']['FM_avg']:.2f}", "Optimality certificate": "YES" if col == "RC2" else "NO",
                "Worst profile": m["worst_profile"]}.get(metric)
        if want is None: issues.append(f"T5 unknown metric {metric}"); break
        chk(f"T5 {metric} {col}", cell, want)
# ---- Table 2 baseline failure counts
for row in T[1][1:]:
    rid, fail = row[0], row[3]
    mm = re.match(r"(\d+) of 10 baselines", fail)
    if mm:
        n = sum(1 for m in raw if rid in m["violations"])
        if int(mm.group(1)) != n: issues.append(f"T2 {rid}: paper {mm.group(1)} of 10 vs results {n}")
br = [m["scores"]["burst"] for m in raw]
rng = lambda k: f"{min(b[k] for b in br):.0f}–{max(b[k] for b in br):.0f}%"
print("T2 ranges in results: any", rng("Burn_any_pct"), "TBurn", rng("TBurn_pct"), "PBurn", rng("PBurn_pct"))
for row in T[1][1:]:
    if row[0] in ("C1", "C9", "C13"): print("  paper", row[0], "->", row[3])
print("ISSUES:", len(issues)); [print(" ", i) for i in issues]
