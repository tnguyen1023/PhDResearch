import json, re
D = json.load(open("doc.json")); P = D["paras"]; T = D["tables"]
R = json.load(open("/home/claude/zstp/out/results.json")); M = {m["method"]: m for m in R["methods"]}
text = "\n".join(P)
out = []
# 1. "best or tied for best on 10 of the 14 measured metrics" (Table 5; RC2 column, excluding certificate & worst-profile rows)
lower = {"Rule violations", "PBurn% (lower↓)", "TBurn% (lower↓)", "C14 X-Zone Leaks"}
num = lambda s: float(s.replace(",", "").replace("%", "").split("/")[0])
best = 0; rows = [r for r in T[4][1:] if r[0] not in ("Optimality certificate", "Worst profile")]
for r in rows:
    v = [num(c) for c in r[1:]]
    best += (v[0] == (min(v) if r[0] in lower else max(v)))
qmed_row = next(r for r in rows if r[0] == "Q-med"); qbest = num(qmed_row[1]) == max(num(c) for c in qmed_row[1:])
out.append(f"Table 5: RC2 best/tied on {best} of {len(rows)} metrics (paper: 10 of 14; Q-med best among baselines: {qbest})")
# 2. binding profile counts
b = sum(1 for m in R["methods"] if m["state"] != "repaired" and "tie-break" not in m["method"] and m["worst_profile"] == "burst")
out.append(f"θ_burst binding in {b} of 13 schedules (paper: 3 of 13)")
# 3. Figure 2 caption: no baseline exceeds max-min on any axis
mm = M["RC2 max-min (r*)"]; bases = [m for n, m in M.items() if not n.startswith("RC2")]
ax = {th: max(m["scores"][th]["Q"] for m in bases) for th in ("med", "burst")}
out.append(f"Fig 2: best baseline Q_med {ax['med']:,.2f} vs max-min {mm['scores']['med']['Q']:,.2f}; Q_burst {ax['burst']:,.2f} vs {mm['scores']['burst']['Q']:,.2f}; worst {max(m['r_min'] for m in bases):,.2f} vs {mm['r_min']:,.2f}")
# 4. Figure 1 caption: every repaired baseline below r*
out.append(f"Fig 1: max repaired worst case {max(m['r_min'] for m in R['methods'] if m['state']=='repaired'):,.2f} < r* {mm['r_min']:,.2f}")
# 5. Related work counts
out.append("Related-work sentence: " + re.search(r"most often[^.]*\.", text).group(0))
raw = [m for m in R["methods"] if m["state"] == "infeasible"]
out.append(f"   results: C10b {sum('C10b' in m['violations'] for m in raw)}, C10a {sum('C10a' in m['violations'] for m in raw)}, C14 {sum('C14' in m['violations'] for m in raw)} of 10")
# 6. model leads every baseline under all four profiles
lead = all(mm["scores"][th]["Q"] > m["scores"][th]["Q"] for m in bases for th in ("low", "med", "high", "burst"))
out.append(f"max-min above every baseline (raw and repaired) under all 4 profiles in the model: {lead}")
# 7. cross-references
heads = [p for p in P if re.match(r"^\d+(\.\d+)? [A-Z]", p)]
secs = {re.match(r"^(\d+(\.\d+)?)", h).group(1) for h in heads}
refs = set(re.findall(r"Section (\d+(?:\.\d+)?)", text))
out.append(f"Section refs missing a heading: {sorted(refs - secs)}")
tcap = [int(x) for x in re.findall(r"^Table (\d+)\.", "\n".join(P), flags=re.M)]
fcap = [int(x) for x in re.findall(r"^Figure (\d+)\.", "\n".join(P), flags=re.M)]
trefs = {int(x) for x in re.findall(r"Tables? (\d+)", text)} | {int(y) for x in re.findall(r"Tables (\d+) and (\d+)", text) for y in x}
frefs = {int(x) for x in re.findall(r"Figure (\d+)", text)}
out.append(f"table captions in order: {tcap}; referenced: {sorted(trefs)}; unreferenced: {sorted(set(tcap) - trefs)}; missing: {sorted(trefs - set(tcap))}")
out.append(f"figure captions: {fcap}; referenced: {sorted(frefs)}")
out.append(f"Appendix mentions: {re.findall(r'Appendi[a-z]+ [A-Z–\-]+', text)}; appendix headings: {[h for h in P if h.lower().startswith('appendix')]}")
out.append(f"headings: {heads}")
print("\n".join(out))
