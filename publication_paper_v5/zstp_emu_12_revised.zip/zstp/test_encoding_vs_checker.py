"""Two-directional agreement between the WCNF hard layer and the independent checker, plus
objective agreement, on schedules that are NOT produced by the solver.

test_consistency.py only takes schedules the SAT solver completes, so it can show
"encoder-feasible => checker-feasible" but never the reverse, and its schedules are sparse.
Here schedules are drawn independently of the encoding:
  * random subsets of the plausible deployments (sizes 0..|budget|+4), most of them infeasible;
  * one-step mutations (add / remove / move one deployment) of feasible schedules, which
    probe the constraint boundaries;
  * every baseline schedule as produced.
For each schedule every x is fixed by assumptions. Required:
  encoding SAT  <=>  checker returns no violation          (hard layer = rule checker)
  and, when SAT, the value of every soft term set equals the evaluator's Q_theta (all profiles).
"""
import random, sys
from pysat.solvers import Solver
import instance, encoder, evaluator, baselines


def fix(enc, sched):
    S = set(map(tuple, sched))
    return [x if k in S else -x for k, x in enc.X.items()]


def run(inst, n_random=400, n_mut=400, seed=3):
    rnd = random.Random(seed)
    enc = encoder.Enc(inst)
    cand = [(i, z, t, r) for t in range(inst["H"]) for (i, z, r) in baselines.candidates(inst)]
    pool = []
    for _ in range(n_random):
        pool.append(rnd.sample(cand, rnd.randint(0, min(len(cand), inst["B_t"] * inst["H"] + 4))))
    if inst["name"] == "XLarge":
        pool += [fn(inst) for fn in baselines.BASELINES.values()]
    stats = {"tested": 0, "feasible": 0, "hard_mismatch": 0, "obj_mismatch": 0}
    feas_seen = []
    with Solver(name="g4", bootstrap_with=enc.hard) as s:
        def test(sched):
            sched = evaluator.norm(sched)
            ok_chk = not evaluator.check(inst, sched)
            ok_enc = s.solve(assumptions=fix(enc, sched))
            stats["tested"] += 1
            if ok_chk != ok_enc:
                stats["hard_mismatch"] += 1
                print("HARD MISMATCH checker", ok_chk, "encoder", ok_enc, evaluator.check(inst, sched), sched)
                return
            if ok_enc:
                stats["feasible"] += 1
                feas_seen.append(sched)
                m = set(l for l in s.get_model() if l > 0)
                for th, terms in enc.terms.items():
                    ev = evaluator.evaluate(inst, sched, th)["Q_int"]
                    en = sum(w for (_, w, l) in terms if l is True or l in m)
                    if ev != en:
                        stats["obj_mismatch"] += 1
                        print("OBJ MISMATCH", th, en, ev)
        for sch in pool:
            test(sch)
        # seed feasible set with solver-found schedules if random sampling found few
        xs = list(enc.X.values())
        for _ in range(500):
            if len(feas_seen) >= 20:
                break
            if s.solve(assumptions=[rnd.choice(xs) for _ in range(rnd.randint(0, 3))]):
                test(enc.decode(s.get_model()))
        for _ in range(n_mut):
            base = list(rnd.choice(feas_seen))
            op = rnd.random()
            if op < 0.34 and base:
                base.pop(rnd.randrange(len(base)))
            elif op < 0.67:
                base.append(rnd.choice(cand))
            elif base:
                base[rnd.randrange(len(base))] = rnd.choice(cand)
            test(base)
    return stats


if __name__ == "__main__":
    import testlog
    bad = 0; res = {}
    for inst in (instance.build_micro(), instance.build_xlarge()):
        st = run(inst)
        print(inst["name"], st)
        res[inst["name"]] = st
        bad += st["hard_mismatch"] + st["obj_mismatch"]
    testlog.record("encoding_vs_checker", {"per_instance": res,
        "tested": sum(v["tested"] for v in res.values()), "feasible": sum(v["feasible"] for v in res.values()),
        "hard_mismatch": sum(v["hard_mismatch"] for v in res.values()), "obj_mismatch": sum(v["obj_mismatch"] for v in res.values())})
    sys.exit(1 if bad else 0)
