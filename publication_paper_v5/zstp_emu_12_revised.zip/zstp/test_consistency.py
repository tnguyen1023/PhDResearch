"""Encoder <-> evaluator agreement on random schedules (every aux forced by x)."""
import random, sys
import instance, encoder, evaluator
from pysat.solvers import Solver

def run(inst, n=60, seed=7):
    rnd = random.Random(seed)
    e = encoder.Enc(inst)
    keys = list(e.X)
    # drop hard constraints: test objective definitions only -> use definitional clauses only.
    # Simplest: build solver on all hard clauses and use feasible random schedules found by random assumptions.
    bad = 0; tested = 0
    with Solver(name="g4", bootstrap_with=e.hard) as s:
        for k in range(n):
            # random partial assignment of x, let solver complete to a feasible schedule
            assum = [(e.X[q] if rnd.random() < 0.08 else -e.X[q]) for q in rnd.sample(keys, min(40, len(keys)))]
            if not s.solve(assumptions=assum):
                if not s.solve(assumptions=assum[:10]):
                    continue
            m = set(l for l in s.get_model() if l > 0)
            sched = e.decode(s.get_model())
            tested += 1
            assert evaluator.check(inst, sched) == {}, evaluator.check(inst, sched)
            for th, terms in e.terms.items():
                enc_val = sum(w for (_, w, l) in terms if l is True or l in m)
                ev = evaluator.evaluate(inst, sched, th)["Q_int"]
                if enc_val != ev:
                    bad += 1; print("MISMATCH", th, enc_val, ev)
    return tested, bad

if __name__ == "__main__":
    import testlog
    res = {}
    for inst in (instance.build_xlarge(), instance.build_micro()):
        tested, bad = run(inst); res[inst["name"]] = {"tested": tested, "mismatches": bad}
        print(inst["name"], (tested, bad))
    testlog.record("encoder_vs_evaluator", {"per_instance": res, "tested": sum(v["tested"] for v in res.values()),
                                            "mismatches": sum(v["mismatches"] for v in res.values())})
    sys.exit(1 if any(v["mismatches"] for v in res.values()) else 0)
