"""Run run_all.py a second time in a scratch copy and compare its results.json with out/results.json,
ignoring timing fields. Writes out/repro.json (read by the paper's Table 6)."""
import json, os, shutil, subprocess, sys, tempfile, time

TIMING = ("seconds", "started", "tail")


def strip(o):
    if isinstance(o, dict):
        return {k: strip(v) for k, v in o.items() if k not in TIMING and "time" not in k}
    if isinstance(o, list):
        return [strip(v) for v in o]
    return o


def diffs(a, b, p="", out=None):
    out = [] if out is None else out
    if type(a) != type(b):
        out.append(p)
    elif isinstance(a, dict):
        for k in set(a) | set(b):
            if k not in a or k not in b:
                out.append(f"{p}/{k}")
            else:
                diffs(a[k], b[k], f"{p}/{k}", out)
    elif isinstance(a, list):
        if len(a) != len(b):
            out.append(p)
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                diffs(x, y, f"{p}[{i}]", out)
    elif a != b:
        out.append(p)
    return out


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    tmp = tempfile.mkdtemp(prefix="zstp_repro_")
    for f in os.listdir(here):
        if f.endswith(".py"):
            shutil.copy(os.path.join(here, f), tmp)
    t0 = time.time()
    subprocess.run([sys.executable, "run_all.py"], cwd=tmp, check=True, stdout=subprocess.DEVNULL)
    a = strip(json.load(open(os.path.join(tmp, "out/results.json"))))
    b = strip(json.load(open(os.path.join(here, "out/results.json"))))
    d = diffs(a, b)
    res = {"runs_compared": 2, "identical_apart_from_timing": not d, "differences": d[:20],
           "code_hash": b["meta"]["code_hash"], "second_run_seconds": round(time.time() - t0, 1)}
    json.dump(res, open(os.path.join(here, "out/repro.json"), "w"), indent=1)
    shutil.rmtree(tmp, ignore_errors=True)
    print("identical apart from timing:", not d)
    return 0 if not d else 1


if __name__ == "__main__":
    raise SystemExit(main())
